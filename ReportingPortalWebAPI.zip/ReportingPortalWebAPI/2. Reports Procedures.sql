-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

USE `siprasoft` ;

-- -----------------------------------------------------
-- procedure PRC_BreakInService_ReportData
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_BreakInService_ReportData`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_BreakInService_ReportData`( IN workYear VARCHAR(100),
          IN controlGroup VARCHAR(200),IN weekStarting VARCHAR(10),IN weekEnding VARCHAR(10))
BEGIN
SELECT FIRST_NAME,LAST_NAME,SOC_SEC_NUMBER,SERVICE_STATUS,
WEEK_STARTING,WEEK_ENDING,WEEK_COUNT,CONTROL_GROUP,WORK_YEAR
FROM tbl_breakinservicereport WHERE  (1=1) 
  -- AND (workYear IS NULL OR WORK_YEAR=workYear)
  AND (workYear IS NULL OR  FIND_IN_SET(replace(WORK_YEAR,',',''), replace(replace(workYear,',',''),':',',')))
        -- AND (controlGroup IS NULL OR  CONTROL_GROUP=controlGroup)
		AND (controlGroup IS NULL OR  FIND_IN_SET(replace(CONTROL_GROUP,',',''), replace(replace(controlGroup,',',''),':',',')))
         AND (weekStarting IS NULL OR WEEK_STARTING=weekStarting)
        AND (weekEnding IS NULL OR WEEK_ENDING=weekEnding);
 
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_Eligibility_Generate_ReferenceData
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_Eligibility_Generate_ReferenceData`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_Eligibility_Generate_ReferenceData`()
BEGIN


	delete from tbl_reportsreferencedata where ReportName='Eligibility';
    
    INSERT INTO  tbl_reportsreferencedata 
	SELECT 'Eligibility','ControlGroup',   ControlGroup, 1, 'Reporting',NOW(),'Reporting',NOW() FROM 
	(SELECT DISTINCT CONTROL_GROUP  AS ControlGroup FROM tbl_eligibilityreport) AS Result;
    
    INSERT INTO  tbl_reportsreferencedata 
	SELECT 'Eligibility','WorkYear',   WorkYear, 1, 'Reporting',NOW(),'Reporting',NOW() FROM 
	(SELECT DISTINCT WORK_YEAR  AS WorkYear FROM tbl_eligibilityreport) AS Result;

	
END$$

DELIMITER ;
-- -----------------------------------------------------
-- procedure PRC_BreakIn_ReferenceData_ControlGroup
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_BreakIn_ReferenceData_ControlGroup`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_BreakIn_ReferenceData_ControlGroup`()
BEGIN
  SELECT FieldValue FROM tbl_reportsreferencedata WHERE ReportName='BreakIn' AND FieldName='ControlGroup';
   END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_BreakIn_ReferenceData_Week_Ending
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_BreakIn_ReferenceData_Week_Ending`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_BreakIn_ReferenceData_Week_Ending`()
BEGIN
  SELECT FieldValue FROM tbl_reportsreferencedata WHERE ReportName='BreakIn' AND FieldName='WeekEnding';
   END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_BreakIn_ReferenceData_Week_Starting
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_BreakIn_ReferenceData_Week_Starting`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_BreakIn_ReferenceData_Week_Starting`()
BEGIN
  SELECT FieldValue FROM tbl_reportsreferencedata WHERE ReportName='BreakIn' AND FieldName='WeekStarting';
   END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_BreakIn_ReferenceData_WorkYear
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_BreakIn_ReferenceData_WorkYear`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_BreakIn_ReferenceData_WorkYear`()
BEGIN
  SELECT FieldValue FROM tbl_reportsreferencedata WHERE ReportName='BreakIn' AND FieldName='WorkYear';
   END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_Demographics_ReferenceData_ControlGroup
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_Demographics_ReferenceData_ControlGroup`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_Demographics_ReferenceData_ControlGroup`()
BEGIN
  SELECT FieldValue FROM tbl_reportsreferencedata WHERE ReportName='DemoGraphics' AND FieldName='ControlGroup';
   END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_Demographics_ReferenceData_Parent_Company
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_Demographics_ReferenceData_Parent_Company`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_Demographics_ReferenceData_Parent_Company`()
BEGIN
  SELECT FieldValue FROM tbl_reportsreferencedata WHERE ReportName='DemoGraphics' AND FieldName='ParentCompany';
   END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_Demographics_ReferenceData_Payroll_Company
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_Demographics_ReferenceData_Payroll_Company`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_Demographics_ReferenceData_Payroll_Company`()
BEGIN
  SELECT FieldValue FROM tbl_reportsreferencedata WHERE ReportName='DemoGraphics' AND FieldName='PayrollCompany';
   END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_Demographics_ReferenceData_Production_Company
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_Demographics_ReferenceData_Production_Company`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_Demographics_ReferenceData_Production_Company`()
BEGIN
  SELECT FieldValue FROM tbl_reportsreferencedata WHERE ReportName='DemoGraphics' AND FieldName='ProductionCompany';
   END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_Demographics_ReferenceData_WorkYear
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_Demographics_ReferenceData_WorkYear`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_Demographics_ReferenceData_WorkYear`()
BEGIN
  SELECT FieldValue FROM tbl_reportsreferencedata WHERE ReportName='DemoGraphics' AND FieldName='WorkYear';
   END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_Demographics_ReportData
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_Demographics_ReportData`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_Demographics_ReportData`( IN workYear VARCHAR(4),
          IN controlGroup VARCHAR(100),IN parentCompnay VARCHAR(100),IN proudctioncompany VARCHAR(100),IN payrollCompany VARCHAR(100))
BEGIN
SELECT PARENT_COMPANY,PRODUCTION_COMPANY,SHOW_NAME,PAYROLL_COMPANY,FIRST_NAME,LAST_NAME,
UNION_TYPE,SOC_SEC_NUMBER,ACA_EMPLOYMENT_STATUS,SCHEDULE_CODE,PAY_RATE,
JOB_DESCRIPTION,GENDER,DATE_OF_BIRTH,EMAIL,ADDRESS,CITY,STATE,ZIP,CONTROL_GROUP,WORK_YEAR
FROM tbl_demographicsreport WHERE  (1=1) 
  AND (workYear IS NULL OR WORK_YEAR=workYear)
        AND (controlGroup IS NULL OR  CONTROL_GROUP=controlGroup)
        AND (parentCompnay IS NULL OR PARENT_COMPANY=parentCompnay)
        AND (proudctioncompany IS NULL OR PRODUCTION_COMPANY=proudctioncompany)
        AND (payrollCompany IS NULL OR PAYROLL_COMPANY=payrollCompany);
 
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_ERCoverage_AnnualizedMonthlyCount
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_ERCoverage_AnnualizedMonthlyCount`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_ERCoverage_AnnualizedMonthlyCount`(
    IN workYear VARCHAR(4),
          IN controlGroup VARCHAR(100)
         )
BEGIN
SELECT COUNT(*) AS COUNT FROM tbl_ercoverage 
WHERE  (1=1) 
  	AND (workYear IS NULL OR WORK_YEAR=workYear)
        -- AND (controlGroup IS NULL OR  CONTROL_GROUP=controlGroup);
        -- AND (controlGroup IS NULL OR  FIND_IN_SET(CONTROL_GROUP,controlGroup));
		 AND (controlGroup IS NULL OR  FIND_IN_SET(replace(CONTROL_GROUP,',',''), replace(replace(controlGroup,',',''),':',',')));

    END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_ERCoverage_ReferenceData_ControlGroup
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_ERCoverage_ReferenceData_ControlGroup`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_ERCoverage_ReferenceData_ControlGroup`()
BEGIN
  SELECT FieldValue FROM tbl_reportsreferencedata WHERE ReportName='ERCoverage' AND FieldName='ControlGroup';
   END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_ERCoverage_ReferenceData_WorkYear
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_ERCoverage_ReferenceData_WorkYear`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_ERCoverage_ReferenceData_WorkYear`()
BEGIN
  SELECT FieldValue FROM tbl_reportsreferencedata WHERE ReportName='ERCoverage' AND FieldName='WorkYear';
   END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_ERCoverage_Report_Generate_ReferenceData
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_ERCoverage_Report_Generate_ReferenceData`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_ERCoverage_Report_Generate_ReferenceData`()
BEGIN



      
	delete from tbl_reportsreferencedata where ReportName='ERCoverage';


  



  INSERT INTO  tbl_reportsreferencedata 

  SELECT 'ERCoverage','WorkYear',   WorkYear, 1, 'Reporting',NOW(),'Reporting',NOW() FROM 

  (SELECT DISTINCT WORK_YEAR  AS WorkYear FROM tbl_ercoverage) AS Result;



  INSERT INTO  tbl_reportsreferencedata 

  SELECT 'ERCoverage','ControlGroup',   ControlGroup, 1, 'Reporting',NOW(),'Reporting',NOW() FROM 

  (SELECT DISTINCT CONTROL_GROUP  AS ControlGroup FROM tbl_ercoverage) AS Result;



END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_ERCoverage_ReportsByAnnualizedMonthlyCount
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_ERCoverage_ReportsByAnnualizedMonthlyCount`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_ERCoverage_ReportsByAnnualizedMonthlyCount`(
    IN workYear VARCHAR(4),
          IN controlGroup VARCHAR(100),
          IN annualizedMonthlyCount VARCHAR(10)
         )
BEGIN
SELECT CONTROL_GROUP,WORK_YEAR,WORK_MONTH,WORKED_POOL_FTE_STATUS,
   FIRST_NAME,LAST_NAME,HOURS_WORKED,WORKED_POOL_FTE_COUNT
   FROM tbl_ercoverage 
WHERE  (1=1) 
  AND (workYear IS NULL OR WORK_YEAR=workYear)
          -- AND (controlGroup IS NULL OR  CONTROL_GROUP=controlGroup)
        -- AND (controlGroup IS NULL OR  FIND_IN_SET(CONTROL_GROUP,controlGroup));
		 AND (controlGroup IS NULL OR  FIND_IN_SET(replace(CONTROL_GROUP,',',''), replace(replace(controlGroup,',',''),':',',')));
 
    END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_Eligibility_ReferenceData_ControlGroup
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_Eligibility_ReferenceData_ControlGroup`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_Eligibility_ReferenceData_ControlGroup`()
BEGIN
  SELECT FieldValue FROM tbl_reportsreferencedata WHERE ReportName='Eligibility' AND FieldName='ControlGroup';
   END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_Eligibility_ReferenceData_Type_Of_Hours
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_Eligibility_ReferenceData_Type_Of_Hours`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_Eligibility_ReferenceData_Type_Of_Hours`()
BEGIN
  SELECT FieldValue FROM tbl_reportsreferencedata WHERE ReportName='Eligibility' AND FieldName='TypeOfHours';
   END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_Eligibility_ReferenceData_Union_Status
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_Eligibility_ReferenceData_Union_Status`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_Eligibility_ReferenceData_Union_Status`()
BEGIN
  SELECT FieldValue FROM tbl_reportsreferencedata WHERE ReportName='Eligibility' AND FieldName='UnionStatus';
   END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_Eligibility_ReferenceData_WorkYear
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_Eligibility_ReferenceData_WorkYear`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_Eligibility_ReferenceData_WorkYear`()
BEGIN
  SELECT FieldValue FROM tbl_reportsreferencedata WHERE ReportName='Eligibility' AND FieldName='WorkYear';
   END$$

DELIMITER ;


-- -----------------------------------------------------
-- procedure PRC_Eligibility_ReportData
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_Eligibility_ReportData`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_Eligibility_ReportData`(IN workYear VARCHAR(100),
          IN controlGroup VARCHAR(200),IN unionStatus VARCHAR(10),IN typeOfHours VARCHAR(10) )
BEGIN
SELECT FIRST_NAME,LAST_NAME,UNION_TYPE,SOC_SEC_NUMBER,MOST_RECENT_SHOW,MOST_RECENT_JOB_TITLE,
AVEAGE_WEEKLY_HOURS,TOTAL_HOURS,STANDARD_MEASURE_ELIGIBILITY,BENEFITS_EFFECTIVE,CONTROL_GROUP,WORK_YEAR
FROM tbl_eligibilityreport WHERE  (1=1) 
  -- AND (workYear IS NULL OR WORK_YEAR=workYear)
  AND (workYear IS NULL OR  FIND_IN_SET(replace(WORK_YEAR,',',''), replace(replace(workYear,',',''),':',',')))
        -- AND (controlGroup IS NULL OR  CONTROL_GROUP=controlGroup)
		AND (controlGroup IS NULL OR  FIND_IN_SET(replace(CONTROL_GROUP,',',''), replace(replace(controlGroup,',',''),':',',')))
        AND (unionStatus IS NULL OR UNION_TYPE=unionStatus)
        AND (typeOfHours IS NULL OR TOTAL_HOURS=typeOfHours);
 
END$$

DELIMITER ;
-- -----------------------------------------------------
-- procedure PRC_NewHiresFullTime_ACAEligibleCount
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_NewHiresFullTime_ACAEligibleCount`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_NewHiresFullTime_ACAEligibleCount`(
    IN workYear VARCHAR(100),
          IN workMonth VARCHAR(200),
          IN controlGroup VARCHAR(100)
         )
BEGIN
SELECT COUNT(*) AS COUNT FROM tbl_newhiresfulltimereport 
WHERE  (1=1) 
   -- AND (workYear IS NULL OR WORK_YEAR=workYear)
	AND (workYear IS NULL OR  FIND_IN_SET(WORK_YEAR,workYear))
	-- AND (workMonth IS NULL OR  WORK_MONTH=workMonth)
	AND (workMonth IS NULL OR  FIND_IN_SET(WORK_MONTH,workMonth))
        -- AND (controlGroup IS NULL OR  CONTROL_GROUP=controlGroup);
        -- AND (controlGroup IS NULL OR  FIND_IN_SET(CONTROL_GROUP,controlGroup));
		 AND (controlGroup IS NULL OR  FIND_IN_SET(replace(CONTROL_GROUP,',',''), replace(replace(controlGroup,',',''),':',',')));

    END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_NewHiresFullTime_Generate_ReferenceData
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_NewHiresFullTime_Generate_ReferenceData`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_NewHiresFullTime_Generate_ReferenceData`()
BEGIN
      
	delete from tbl_reportsreferencedata where ReportName='EligibilityNewHiresFullTime';
			
	INSERT INTO  tbl_reportsreferencedata 
	SELECT 'EligibilityNewHiresFullTime','WorkYear',   WorkYear, 1, 'Reporting',NOW(),'Reporting',NOW() FROM 
	(SELECT DISTINCT WORK_YEAR  AS WorkYear FROM tbl_newhiresfulltimereport) AS Result;
	INSERT INTO  tbl_reportsreferencedata 
	SELECT 'EligibilityNewHiresFullTime','WorkMonth',   WorkMonth, 1, 'Reporting',NOW(),'Reporting',NOW() FROM 
	(SELECT DISTINCT WORK_MONTH  AS WorkMonth FROM tbl_newhiresfulltimereport) AS Result;
	INSERT INTO  tbl_reportsreferencedata 
	SELECT 'EligibilityNewHiresFullTime','ControlGroup',   ControlGroup, 1, 'Reporting',NOW(),'Reporting',NOW() FROM 
	(SELECT DISTINCT CONTROL_GROUP  AS ControlGroup FROM tbl_newhiresfulltimereport) AS Result;
  
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_DemoGraphics_Generate_ReferenceData
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_DemoGraphics_Generate_ReferenceData`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_DemoGraphics_Generate_ReferenceData`()
BEGIN
      
	delete from tbl_reportsreferencedata where ReportName='DemoGraphics';
    
    INSERT INTO  tbl_reportsreferencedata 
	SELECT 'DemoGraphics','ControlGroup',   ControlGroup, 1, 'Reporting',NOW(),'Reporting',NOW() FROM 
	(SELECT DISTINCT CONTROL_GROUP  AS ControlGroup FROM tbl_demographicsreport) AS Result;
    
    INSERT INTO  tbl_reportsreferencedata 
	SELECT 'DemoGraphics','WorkYear',   WorkYear, 1, 'Reporting',NOW(),'Reporting',NOW() FROM 
	(SELECT DISTINCT WORK_YEAR  AS WorkYear FROM tbl_demographicsreport) AS Result;

END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_NewHiresFullTime_ReferenceData_ControlGroup
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_NewHiresFullTime_ReferenceData_ControlGroup`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_NewHiresFullTime_ReferenceData_ControlGroup`()
BEGIN
  SELECT FieldValue FROM tbl_reportsreferencedata WHERE ReportName='EligibilityNewHiresFullTime' AND FieldName='ControlGroup';
   END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_NewHiresFullTime_ReferenceData_WorkMonth
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_NewHiresFullTime_ReferenceData_WorkMonth`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_NewHiresFullTime_ReferenceData_WorkMonth`()
BEGIN
  SELECT FieldValue FROM tbl_reportsreferencedata WHERE ReportName='EligibilityNewHiresFullTime' AND FieldName='WorkMonth'
  ORDER BY FIELD(FieldValue,'January','February','March','April','May','June','July','August','September','October','November','December');
   END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_NewHiresFullTime_ReferenceData_WorkYear
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_NewHiresFullTime_ReferenceData_WorkYear`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_NewHiresFullTime_ReferenceData_WorkYear`()
BEGIN
  SELECT FieldValue FROM tbl_reportsreferencedata WHERE ReportName='EligibilityNewHiresFullTime' AND FieldName='WorkYear';
   END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_NewHiresFullTime_ReportByACAEligibleCount
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_NewHiresFullTime_ReportByACAEligibleCount`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_NewHiresFullTime_ReportByACAEligibleCount`(
    IN workYear VARCHAR(100),
          IN workMonth VARCHAR(200),
          IN controlGroup VARCHAR(100),
          IN acaEligibleCount VARCHAR(20)
         )
BEGIN
   
   SELECT CONTROL_GROUP,LATEST_PRODUCTION_COMPANY,
   MOST_RECENT_SHOW,SOC_SEC_NUMBER,FIRST_NAME,
   LAST_NAME,LAST_WORK_DATE,HIRE_DATE,UNION_TYPE,PAYROLL_SOURCE,
   AVEAGE_HOURS,TOTAL_HOURS
   FROM tbl_newhiresfulltimereport 
WHERE  (1=1) 
  -- AND (workYear IS NULL OR WORK_YEAR=workYear)
	AND (workYear IS NULL OR  FIND_IN_SET(WORK_YEAR,workYear))
	-- AND (workMonth IS NULL OR  WORK_MONTH=workMonth)
	AND (workMonth IS NULL OR  FIND_IN_SET(WORK_MONTH,workMonth))
        -- AND (controlGroup IS NULL OR  CONTROL_GROUP=controlGroup)
        -- AND (controlGroup IS NULL OR  FIND_IN_SET(CONTROL_GROUP,controlGroup));
		 AND (controlGroup IS NULL OR  FIND_IN_SET(replace(CONTROL_GROUP,',',''), replace(replace(controlGroup,',',''),':',',')));

    END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_NewHiresNonFullTime_Generate_ReferenceData
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_NewHiresNonFullTime_Generate_ReferenceData`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_NewHiresNonFullTime_Generate_ReferenceData`()
BEGIN

    delete from tbl_reportsreferencedata where ReportName='EligibilityNewHiresNonFullTime';
		
	INSERT INTO  tbl_reportsreferencedata 
	SELECT 'EligibilityNewHiresNonFullTime','WorkYear',   WorkYear, 1, 'Reporting',NOW(),'Reporting',NOW() FROM 
	(SELECT DISTINCT WORK_YEAR  AS WorkYear FROM tbl_newhiresnonfulltimereport) AS Result;
	INSERT INTO  tbl_reportsreferencedata 
	SELECT 'EligibilityNewHiresNonFullTime','WorkMonth',   WorkMonth, 1, 'Reporting',NOW(),'Reporting',NOW() FROM 
	(SELECT DISTINCT WORK_MONTH  AS WorkMonth FROM tbl_newhiresnonfulltimereport) AS Result;
	INSERT INTO  tbl_reportsreferencedata 
	SELECT 'EligibilityNewHiresNonFullTime','ControlGroup',   ControlGroup, 1, 'Reporting',NOW(),'Reporting',NOW() FROM 
	(SELECT DISTINCT CONTROL_GROUP  AS ControlGroup FROM tbl_newhiresnonfulltimereport) AS Result;
	INSERT INTO  tbl_reportsreferencedata 
	SELECT 'EligibilityNewHiresNonFullTime','EmployeeType',   EmployeeType, 1, 'Reporting',NOW(),'Reporting',NOW() FROM 
	(SELECT DISTINCT EMPOYEE_TYPE  AS EmployeeType FROM tbl_newhiresnonfulltimereport) AS Result;
	INSERT INTO  tbl_reportsreferencedata 
    SELECT 'EligibilityNewHiresNonFullTime','UnionType',   UnionType, 1, 'Reporting',NOW(),'Reporting',NOW() FROM 
	(SELECT DISTINCT UNION_TYPE  AS UnionType FROM tbl_newhiresnonfulltimereport) AS Result;

END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_NewHiresNonFullTime_ReferenceData_ControlGroup
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_NewHiresNonFullTime_ReferenceData_ControlGroup`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_NewHiresNonFullTime_ReferenceData_ControlGroup`()
BEGIN
  SELECT FieldValue FROM tbl_reportsreferencedata WHERE ReportName='EligibilityNewHiresNonFullTime' AND FieldName='ControlGroup';
   END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_NewHiresNonFullTime_ReferenceData_EmployeeType
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_NewHiresNonFullTime_ReferenceData_EmployeeType`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_NewHiresNonFullTime_ReferenceData_EmployeeType`()
BEGIN
  SELECT FieldValue FROM tbl_reportsreferencedata WHERE ReportName='EligibilityNewHiresNonFullTime' AND FieldName='EmployeeType';
   END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_NewHiresNonFullTime_ReferenceData_UnionType
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_NewHiresNonFullTime_ReferenceData_UnionType`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_NewHiresNonFullTime_ReferenceData_UnionType`()
BEGIN
  SELECT FieldValue FROM tbl_reportsreferencedata WHERE ReportName='EligibilityNewHiresNonFullTime' AND FieldName='UnionType';
   END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_NewHiresNonFullTime_ReferenceData_WorkMonth
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_NewHiresNonFullTime_ReferenceData_WorkMonth`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_NewHiresNonFullTime_ReferenceData_WorkMonth`()
BEGIN
  	SELECT FieldValue FROM tbl_reportsreferencedata WHERE ReportName='EligibilityNewHiresNonFullTime' AND FieldName='WorkMonth'
    ORDER BY FIELD(FieldValue,'January','February','March','April','May','June','July','August','September','October','November','December');
   END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_NewHiresNonFullTime_ReferenceData_WorkYear
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_NewHiresNonFullTime_ReferenceData_WorkYear`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_NewHiresNonFullTime_ReferenceData_WorkYear`()
BEGIN
  SELECT FieldValue FROM tbl_reportsreferencedata WHERE ReportName='EligibilityNewHiresNonFullTime' AND FieldName='WorkYear';
   END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_NewHiresNonFullTime_ReportByWeeksCount
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_NewHiresNonFullTime_ReportByWeeksCount`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_NewHiresNonFullTime_ReportByWeeksCount`(IN workYear VARCHAR(100),
          IN workMonth VARCHAR(200),
          IN controlGroup VARCHAR(100),
          IN unionType VARCHAR(10),
          IN employeeType VARCHAR(200),
          IN reportOfWeek VARCHAR(20),
		  IN avgWeeklyThreshold VARCHAR(10)
         )
BEGIN
   
   SELECT CONTROL_GROUP,WORK_YEAR,WORK_MONTH,LATEST_PRODUCTION_COMPANY,
   MOST_RECENT_SHOW,SOC_SEC_NUMBER,FIRST_NAME,
   LAST_NAME,LAST_WORK_DATE,HIRE_DATE,UNION_TYPE,PAYROLL_SOURCE,
   AVEAGE_HOURS,TOTAL_HOURS,EMPOYEE_TYPE,AVEAGRE_WEEKLY_THRESHOLD
   FROM tbl_newhiresnonfulltimereport 
WHERE  (1=1) 
	-- AND (workYear IS NULL OR WORK_YEAR=workYear)
	AND (workYear IS NULL OR  FIND_IN_SET(WORK_YEAR,workYear))
	-- AND (workMonth IS NULL OR  WORK_MONTH=workMonth)
	AND (workMonth IS NULL OR  FIND_IN_SET(WORK_MONTH,workMonth))
        -- AND (controlGroup IS NULL OR  CONTROL_GROUP=controlGroup)
        -- AND (controlGroup IS NULL OR  FIND_IN_SET(CONTROL_GROUP,controlGroup))
		AND (controlGroup IS NULL OR  FIND_IN_SET(replace(CONTROL_GROUP,',',''), replace(replace(controlGroup,',',''),':',',')))
	AND (unionType IS NULL OR  UNION_TYPE=unionType)
		-- AND (employeeType IS NULL OR  EMPOYEE_TYPE=employeeType)
    AND (employeeType IS NULL OR  FIND_IN_SET(EMPOYEE_TYPE,employeeType))
	AND (reportOfWeek IS NULL OR  WEEKS_WORKED=reportOfWeek)
	AND (avgWeeklyThreshold IS NULL OR  AVEAGRE_WEEKLY_THRESHOLD=avgWeeklyThreshold);
       END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_NewHiresNonFullTime_ReportCountByWeek
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_NewHiresNonFullTime_ReportCountByWeek`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_NewHiresNonFullTime_ReportCountByWeek`(IN workYear VARCHAR(100),
          IN workMonth VARCHAR(200),
          IN controlGroup VARCHAR(100),
          IN unionType VARCHAR(10),
          IN employeeType VARCHAR(200),
		  IN avgWeeklyThreshold VARCHAR(10)
         )
BEGIN
SELECT WEEKS_WORKED,COUNT(1) AS COUNT FROM ( 
SELECT * FROM tbl_newhiresnonfulltimereport 
WHERE  (1=1) 
 -- AND (workYear IS NULL OR WORK_YEAR=workYear)
	AND (workYear IS NULL OR  FIND_IN_SET(WORK_YEAR,workYear))
	-- AND (workMonth IS NULL OR  WORK_MONTH=workMonth)
	AND (workMonth IS NULL OR  FIND_IN_SET(WORK_MONTH,workMonth))
        -- AND (controlGroup IS NULL OR  CONTROL_GROUP=controlGroup)
        -- AND (controlGroup IS NULL OR  FIND_IN_SET(CONTROL_GROUP,controlGroup))
		AND (controlGroup IS NULL OR  FIND_IN_SET(replace(CONTROL_GROUP,',',''), replace(replace(controlGroup,',',''),':',',')))
	AND (unionType IS NULL OR  UNION_TYPE=unionType)
	-- AND (employeeType IS NULL OR  EMPOYEE_TYPE=employeeType)
    AND (employeeType IS NULL OR  FIND_IN_SET(EMPOYEE_TYPE,employeeType))
	AND (avgWeeklyThreshold IS NULL OR  AVEAGRE_WEEKLY_THRESHOLD=avgWeeklyThreshold)
) AS Result
GROUP BY WEEKS_WORKED;
/* SELECT WEEKS_WORKED AS weeksWorked,COUNT(1) AS weeksWorkedCount FROM tbl_newhiresnonfulltimereport 
GROUP BY WEEKS_WORKED ;
HAVING (1=1) ;
/*AND (WORK_YEAR IS NULL OR WORK_YEAR=workYear);*/
 
    END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_OnGoing_MeasurementDatesByControlGroup
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_OnGoing_MeasurementDatesByControlGroup`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_OnGoing_MeasurementDatesByControlGroup`(
          IN controlGroup VARCHAR(100)
         )
BEGIN

SELECT distinct MEASUREMENT_END_DATE 
   FROM tbl_ongoingreport 
WHERE  (1=1) 
 		AND (controlGroup IS NULL OR  FIND_IN_SET(replace(CONTROL_GROUP,',',''), replace(replace(controlGroup,',',''),':',',')));
 
END$$

DELIMITER ;



-- -----------------------------------------------------
-- procedure PRC_OnGoing_MeasurementEndDatesByControlGroup
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_OnGoing_MeasurementEndDatesByControlGroup`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_OnGoing_MeasurementEndDatesByControlGroup`(
          IN controlGroup VARCHAR(100)
         )
BEGIN

SELECT DISTINCT MEASUREMENT_END_DATE 
   FROM tbl_ongoingreport 
WHERE  (1=1) 
 		AND (controlGroup IS NULL OR  FIND_IN_SET(REPLACE(CONTROL_GROUP,',',''), REPLACE(REPLACE(controlGroup,',',''),':',',')));
 
END$$

DELIMITER ;




-- -----------------------------------------------------
-- procedure PRC_OnGoing_MeasurementStartDatesByControlGroup
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_OnGoing_MeasurementStartDatesByControlGroup`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_OnGoing_MeasurementStartDatesByControlGroup`(
          IN controlGroup VARCHAR(100)
         )
BEGIN


SELECT DISTINCT MEASUREMENT_START_DATE 
   FROM tbl_ongoingreport 
WHERE  (1=1) 
 		AND (controlGroup IS NULL OR  FIND_IN_SET(REPLACE(CONTROL_GROUP,',',''), REPLACE(REPLACE(controlGroup,',',''),':',',')));
 

END$$

DELIMITER ;



-- -----------------------------------------------------
-- procedure PRC_OnGoingReport_Generate_ReferenceData
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_OnGoingReport_Generate_ReferenceData`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_OnGoingReport_Generate_ReferenceData`()
BEGIN

	delete from tbl_reportsreferencedata where ReportName='OnGoingReport';
      
  INSERT INTO  tbl_reportsreferencedata 
  SELECT 'OnGoingReport','UnionType',   UnionType, 1, 'Reporting',NOW(),'Reporting',NOW() FROM 
  (SELECT DISTINCT UNION_TYPE  AS UnionType FROM tbl_ongoingreport) AS Result;
  INSERT INTO  tbl_reportsreferencedata 
  SELECT 'OnGoingReport','MeasurementEndDate',   MeasurementEndDate, 1, 'Reporting',NOW(),'Reporting',NOW() FROM 
  (SELECT DISTINCT MEASUREMENT_END_DATE  AS MeasurementEndDate FROM tbl_ongoingreport) AS Result;
  INSERT INTO  tbl_reportsreferencedata 
  SELECT 'OnGoingReport','ControlGroup',   ControlGroup, 1, 'Reporting',NOW(),'Reporting',NOW() FROM 
  (SELECT DISTINCT CONTROL_GROUP  AS ControlGroup FROM tbl_ongoingreport) AS Result;
END$$

DELIMITER ;


-- -----------------------------------------------------
-- procedure PRC_OnGoing_CountByWeek
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_OnGoing_CountByWeek`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_OnGoing_CountByWeek`(
          IN controlGroup VARCHAR(200),
          IN measurementStartDate VARCHAR(20),
          IN measurementEndDate VARCHAR(20),
          IN avgWeeklyThreshold VARCHAR(3),
          IN unionType VARCHAR(10)
         )
BEGIN


SELECT '52',count(1) FROM tbl_ongoingreport 
WHERE  (1=1) 
        AND (controlGroup IS NULL OR  CONTROL_GROUP=controlGroup)
        AND (measurementStartDate IS NULL OR  MEASUREMENT_START_DATE=measurementStartDate)
        AND (measurementEndDate IS NULL OR  MEASUREMENT_END_DATE=measurementEndDate)
        AND (avgWeeklyThreshold IS NULL OR  AVEAGRE_WEEKLY_THRESHOLD=avgWeeklyThreshold)
  AND (unionType IS NULL OR  UNION_TYPE=unionType);

 
    END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_OnGoing_ReferenceData_ControlGroup
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_OnGoing_ReferenceData_ControlGroup`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_OnGoing_ReferenceData_ControlGroup`()
BEGIN
  SELECT FieldValue FROM tbl_reportsreferencedata WHERE ReportName='OnGoingReport' AND FieldName='ControlGroup';
   END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_OnGoing_ReferenceData_MeasurementEndDate
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_OnGoing_ReferenceData_MeasurementEndDate`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_OnGoing_ReferenceData_MeasurementEndDate`()
BEGIN
  SELECT FieldValue FROM tbl_reportsreferencedata WHERE ReportName='OnGoingReport' AND FieldName='MeasurementEndDate';
   END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_OnGoing_ReferenceData_UnionType
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_OnGoing_ReferenceData_UnionType`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_OnGoing_ReferenceData_UnionType`()
BEGIN
  SELECT FieldValue FROM tbl_reportsreferencedata WHERE ReportName='OnGoingReport' AND FieldName='UnionType';
   END$$

DELIMITER ;


-- -----------------------------------------------------
-- procedure PRC_OnGoing_ReportsForCountByWeek
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_OnGoing_ReportsForCountByWeek`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_OnGoing_ReportsForCountByWeek`(
          IN controlGroup VARCHAR(100),
          IN measurementStartDate VARCHAR(20),
          IN measurementEndDate VARCHAR(20),
          IN avgWeeklyThreshold VARCHAR(3),
          IN unionType VARCHAR(10),
          IN reportForWeek VARCHAR(10)
         )
BEGIN
SELECT CONTROL_GROUP,LATEST_PRODUCTION_COMPANY,
   MOST_RECENT_SHOW,SOC_SEC_NUMBER,FIRST_NAME,
   LAST_NAME,LAST_WORK_DATE,HIRE_DATE,UNION_TYPE,WEEKS_SINCE_LAST_WORKED,
   AVEAGE_HOURS_SMP,TOTAL_HOURS,EMPOYEE_TYPE
   FROM tbl_ongoingreport 
WHERE  (1=1) 
  AND (controlGroup IS NULL OR CONTROL_GROUP=controlGroup)
  AND (measurementEndDate IS NULL OR  MEASUREMENT_END_DATE=measurementEndDate)
        AND (avgWeeklyThreshold IS NULL OR  AVEAGRE_WEEKLY_THRESHOLD=avgWeeklyThreshold)
  AND (unionType IS NULL OR  UNION_TYPE=unionType)
  AND (reportForWeek IS NULL OR  WEEKS_WORKED=reportForWeek);
 
    END$$

DELIMITER ;


-- -----------------------------------------------------
-- procedure PRC_PayrollDataActivity_ReferenceData_ControlGroup
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_PayrollDataActivity_ReferenceData_ControlGroup`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_PayrollDataActivity_ReferenceData_ControlGroup`()
BEGIN
  SELECT FieldValue FROM tbl_reportsreferencedata WHERE ReportName='PayrollDataActivity' AND FieldName='ControlGroup';
   END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_PayrollDataActivity_ReferenceData_WorkYear
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_PayrollDataActivity_ReferenceData_WorkYear`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_PayrollDataActivity_ReferenceData_WorkYear`()
BEGIN
  SELECT FieldValue FROM tbl_reportsreferencedata WHERE ReportName='PayrollDataActivity' AND FieldName='WorkYear';
   END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_PayrollDataActivity_Report_Generate_ReferenceData
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_PayrollDataActivity_Report_Generate_ReferenceData`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_PayrollDataActivity_Report_Generate_ReferenceData`()
BEGIN



	delete from tbl_reportsreferencedata where ReportName='PayrollDataActivity';



  INSERT INTO  tbl_reportsreferencedata 

  SELECT 'PayrollDataActivity','WorkYear',   WorkYear, 1, 'Reporting',NOW(),'Reporting',NOW() FROM 

  (SELECT DISTINCT WORK_YEAR  AS WorkYear FROM tbl_payroll_data_activity) AS Result;



  INSERT INTO  tbl_reportsreferencedata 

  SELECT 'PayrollDataActivity','ControlGroup',   ControlGroup, 1, 'Reporting',NOW(),'Reporting',NOW() FROM 

  (SELECT DISTINCT CONTROL_GROUP  AS ControlGroup FROM tbl_payroll_data_activity) AS Result;

      







END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_BreakIn_Generate_ReferenceData
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_BreakIn_Generate_ReferenceData`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_BreakIn_Generate_ReferenceData`()
BEGIN
      
	      
	delete from tbl_reportsreferencedata where ReportName='BreakIn';
    
    INSERT INTO  tbl_reportsreferencedata 
	SELECT 'BreakIn','ControlGroup',   ControlGroup, 1, 'Reporting',NOW(),'Reporting',NOW() FROM 
	(SELECT DISTINCT CONTROL_GROUP  AS ControlGroup FROM tbl_breakinservicereport) AS Result;
    
    INSERT INTO  tbl_reportsreferencedata 
	SELECT 'BreakIn','WorkYear',   WorkYear, 1, 'Reporting',NOW(),'Reporting',NOW() FROM 
	(SELECT DISTINCT WORK_YEAR  AS WorkYear FROM tbl_breakinservicereport) AS Result;

	
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_PayrollDataActivity_ReportsForPayrollDataActivity
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_PayrollDataActivity_ReportsForPayrollDataActivity`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_PayrollDataActivity_ReportsForPayrollDataActivity`(
   IN workYear VARCHAR(100),
          IN controlGroup VARCHAR(200)
         )
BEGIN
SELECT SOC_SEC_NUMBER,FIRST_NAME,LAST_NAME,EIN,PRODUCTION_COMPANY,
   HIRE_DATE,LAST_DATE_WORKED,PROJECT,CLIENT_ID,SOURCE,EMPLOYMENT_STATUS,
   UNION_TYPE,JANUARY,FEBRUARY,MARCH,APRIL,MAY,JUNE,JULY,AUGUST,SEPTEMBER,OCTOBER,NOVEMBER,DECEMBER,CONTROL_GROUP 
   FROM tbl_payroll_data_activity 
WHERE  (1=1) 
  -- AND (workYear IS NULL OR WORK_YEAR=workYear)
  AND (workYear IS NULL OR  FIND_IN_SET(replace(WORK_YEAR,',',''), replace(replace(workYear,',',''),':',',')))
        -- AND (controlGroup IS NULL OR  CONTROL_GROUP=controlGroup)
		AND (controlGroup IS NULL OR  FIND_IN_SET(replace(CONTROL_GROUP,',',''), replace(replace(controlGroup,',',''),':',',')));
 
    END$$

DELIMITER ;



-- -----------------------------------------------------
-- procedure PRC_ERCoverage_FTECountByWorkMonth
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_ERCoverage_FTECountByWorkMonth`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_ERCoverage_FTECountByWorkMonth`( IN workMonth VARCHAR(100))
BEGIN

	

select * from (	SELECT
	CASE WHEN WORK_MONTH IS NULL THEN 'Total'
	ELSE WORK_MONTH END AS 'Calendar_Month',
	COUNT(
	CASE WHEN WORKED_POOL_FTE_STATUS='Full Time' THEN 'FT'
	ELSE NULL END
	) AS 'Full Time Employee Count',
	COUNT(
	CASE WHEN WORKED_POOL_FTE_STATUS='Non Full Time' THEN 'NFT'
	ELSE NULL END
	) AS 'Full Time Equivalent Count',
	COUNT(1) AS Total FROM tbl_ercoverage
	WHERE (1=1)
-- AND (workMonth IS NULL OR  ER.WORK_YEAR=workMonth)
AND (workMonth IS NULL OR  FIND_IN_SET(replace(WORK_YEAR,',',''), replace(replace(workMonth,',',''),':',',')))
GROUP BY WORK_MONTH WITH ROLLUP) a
ORDER BY FIELD(Calendar_Month,-- 'January','February','March','April','May','June','July','August','September','October','November','December',
'JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC','Total');
	
	


END$$

DELIMITER ;


USE `siprasoft` ;

-- -----------------------------------------------------
-- procedure PRC_ERCoverage_FTECountByWorkMonth
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_ERCoverage_FTECountByWorkMonth`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_ERCoverage_FTECountByWorkMonth`( IN workMonth VARCHAR(100))
BEGIN
SELECT DISTINCT WORK_MONTH 
,(SELECT COUNT(1) FROM tbl_ercoverage ERF WHERE ERF.WORK_MONTH= ER.WORK_MONTH AND ERF.WORKED_POOL_FTE_STATUS='Full Time' ) AS 'Full Time'
,(SELECT COUNT(1) FROM tbl_ercoverage ERF WHERE ERF.WORK_MONTH= ER.WORK_MONTH AND ERF.WORKED_POOL_FTE_STATUS='Non Full Time' ) AS 'Non Full Time'
FROM tbl_ercoverage ER where (1=1) 
AND (workMonth IS NULL OR  ER.WORK_MONTH=workMonth)
ORDER BY FIELD(ER.WORK_MONTH,'January','February','March','April','May','June','July','August','September','October','November','December');
  
END$$

DELIMITER ;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;





-- -----------------------------------------------------
-- procedure PRC_DataAcaPayroll_ReportData
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_DataAcaPayroll_ReportData`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_DataAcaPayroll_ReportData`( 
		IN taxYear VARCHAR(4),
        IN controlGroup VARCHAR(100),
        IN sourceName VARCHAR(50),
        IN prodCoName VARCHAR(50),
        IN prodShowName VARCHAR(50)
          )
BEGIN


SELECT SOC_SEC_NUMBER,FIRST_NAME,LAST_NAME,ADDRESS_1,RESIDNT_CITY,RESIDNT_STATE,BIRTH_DATE,
	FIRST_WORKED_DATE,LAST_WORKED_DATE,TERMINATION_DATE,PERIOD_ENDING_DATE,HOURS_WORKED,IS_UNION,EMPLOYMENT_STATUS, CONTROL_GROUP_NAME	
FROM data_aca_payroll 
WHERE  (1=1) 
        AND (taxYear IS NULL OR  FIND_IN_SET(REPLACE(TAX_YEAR,',',''), REPLACE(REPLACE(taxYear,',',''),':',',')))
        AND (controlGroup IS NULL OR  FIND_IN_SET(REPLACE(CONTROL_GROUP_NAME,',',''), REPLACE(REPLACE(controlGroup,',',''),':',',')))
        AND (sourceName IS NULL OR  FIND_IN_SET(REPLACE(SOURCE_NAME,',',''), REPLACE(REPLACE(sourceName,',',''),':',',')))
        AND (prodCoName IS NULL OR  FIND_IN_SET(REPLACE(PROD_CO_NAME,',',''), REPLACE(REPLACE(prodCoName,',',''),':',',')))
        AND (prodShowName IS NULL OR  FIND_IN_SET(REPLACE(PROD_SHOW_NAME,',',''), REPLACE(REPLACE(prodShowName,',',''),':',',')));

 
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_DataAcaPayroll_GetTaxYear
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_DataAcaPayroll_GetTaxYear`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_DataAcaPayroll_GetTaxYear`()
BEGIN

SELECT distinct TAX_YEAR FROM data_aca_payroll;

 
END$$

DELIMITER ;



-- -----------------------------------------------------
-- procedure PRC_DataAcaPayroll_GetSourceName
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_DataAcaPayroll_GetSourceName`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_DataAcaPayroll_GetSourceName`()
BEGIN

	SELECT DISTINCT SOURCE_NAME FROM data_aca_payroll;

 
END$$

DELIMITER ;


-- -----------------------------------------------------
-- procedure PRC_DataAcaPayroll_GetProdShowName
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_DataAcaPayroll_GetProdShowName`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_DataAcaPayroll_GetProdShowName`()
BEGIN

	SELECT DISTINCT PROD_SHOW_NAME FROM data_aca_payroll;

 
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_DataAcaPayroll_GetProdCoName
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_DataAcaPayroll_GetProdCoName`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_DataAcaPayroll_GetProdCoName`()
BEGIN

	SELECT DISTINCT PROD_CO_NAME FROM data_aca_payroll;

 
END$$

DELIMITER ;


-- -----------------------------------------------------
-- procedure PRC_DataAcaPayroll_GetControlGroup
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_DataAcaPayroll_GetControlGroup`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_DataAcaPayroll_GetControlGroup`()
BEGIN

	SELECT DISTINCT CONTROL_GROUP_NAME FROM data_aca_payroll;

 
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_DataAcaPayroll_DataCount
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_DataAcaPayroll_DataCount`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_DataAcaPayroll_DataCount`(
IN taxYear VARCHAR(100),
        IN controlGroup VARCHAR(200),
        IN sourceName VARCHAR(500),
        IN prodCoName VARCHAR(500),
        IN prodShowName VARCHAR(500)
)
BEGIN

	SELECT COUNT(*) AS COUNT FROM data_aca_payroll 
WHERE  (1=1) 
    AND (taxYear IS NULL OR  FIND_IN_SET(REPLACE(TAX_YEAR,',',''), REPLACE(REPLACE(taxYear,',',''),':',',')))
        AND (controlGroup IS NULL OR  FIND_IN_SET(REPLACE(CONTROL_GROUP_NAME,',',''), REPLACE(REPLACE(controlGroup,',',''),':',',')))
        AND (sourceName IS NULL OR  FIND_IN_SET(REPLACE(SOURCE_NAME,',',''), REPLACE(REPLACE(sourceName,',',''),':',',')))
        AND (prodCoName IS NULL OR  FIND_IN_SET(REPLACE(PROD_CO_NAME,',',''), REPLACE(REPLACE(prodCoName,',',''),':',',')))
        AND (prodShowName IS NULL OR  FIND_IN_SET(REPLACE(PROD_SHOW_NAME,',',''), REPLACE(REPLACE(prodShowName,',',''),':',',')));

 
END$$

DELIMITER ;



-- -----------------------------------------------------
-- procedure PRC_LegalEntities_ReportData
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_LegalEntities_ReportData`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_LegalEntities_ReportData`( IN taxYear VARCHAR(100),
          IN controlGroup VARCHAR(200))
BEGIN
SELECT CONTROL_GROUP,TAX_YEAR,EMPLOYER_EIN,EMPLOYER_NAME,ADDRESS_LINE_1,ADDRESS_LINE_2,CITY,STATE,ZIPCODE,CONTACT_FIRST_NAME,CONTACT_LAST_NAME,CONTACT_PHONE,TRANSITION_RELIEF,IS_AUTHORITATIVE,UNION_RULE_TYPE,NON_UNION_RULE_TYPE
FROM tbl_legal_entities WHERE  (1=1) 
  AND (taxYear IS NULL OR  FIND_IN_SET(replace(TAX_YEAR,',',''), replace(replace(taxYear,',',''),':',',')))
		AND (controlGroup IS NULL OR  FIND_IN_SET(replace(CONTROL_GROUP,',',''), replace(replace(controlGroup,',',''),':',',')));
 
END$$

DELIMITER ;


-- -----------------------------------------------------
-- procedure PRC_LegalEntities_ReferenceData_ControlGroup
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_LegalEntities_ReferenceData_ControlGroup`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_LegalEntities_ReferenceData_ControlGroup`()
BEGIN
  SELECT FieldValue FROM tbl_reportsreferencedata WHERE ReportName='LegalEntities' AND FieldName='ControlGroup';
   END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_LegalEntities_ReferenceData_TaxYear
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_LegalEntities_ReferenceData_TaxYear`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_LegalEntities_ReferenceData_TaxYear`()
BEGIN
  SELECT FieldValue FROM tbl_reportsreferencedata WHERE ReportName='LegalEntities' AND FieldName='TaxYear';
   END$$

DELIMITER ;



-- -----------------------------------------------------
-- procedure PRC_LegalEntities_Generate_ReferenceData
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_LegalEntities_Generate_ReferenceData`;

DELIMITER $$
USE `siprasoft`$$
CREATE  PROCEDURE `PRC_LegalEntities_Generate_ReferenceData`()
BEGIN


	delete from tbl_reportsreferencedata where ReportName='LegalEntities';
    
    INSERT INTO  tbl_reportsreferencedata 
	SELECT 'LegalEntities','ControlGroup',   ControlGroup, 1, 'Reporting',NOW(),'Reporting',NOW() FROM 
	(SELECT DISTINCT CONTROL_GROUP  AS ControlGroup FROM tbl_legal_entities) AS Result;
    
    
    INSERT INTO  tbl_reportsreferencedata 
	SELECT 'LegalEntities','TaxYear',   TAX_YEAR, 1, 'Reporting',NOW(),'Reporting',NOW() FROM 
	(SELECT DISTINCT TAX_YEAR  AS TAX_YEAR FROM tbl_legal_entities) AS Result;

	
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_AcaDataSet_ReportData
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_AcaDataSet_ReportData`;

DELIMITER $$
USE `siprasoft`$$


CREATE  PROCEDURE `PRC_AcaDataSet_ReportData`(
        IN controlGroup VARCHAR(100),
        IN employerName VARCHAR(100),
        IN sourceCode VARCHAR(50),
        IN employeeName VARCHAR(100),
        IN hoursPaid VARCHAR(50)
     )
BEGIN
SELECT CONTROL_GROUP_NAME, EMPLOYER_NAME, EMPLOYER_FEDERAL_TAX_ID, EMPLOYEE_SSN, EMPLOYEE_FIRST_NAME, EMPLOYEE_LAST_NAME,
	HRS_SOURCE_CODE,HOURS_PAID,FIRST_PAYPERIOD_START_DATE,EMPLOYMENT_STATUS,ACA_EMPLOYMENT_STATUS,BENEFITS_ENROLLMENT_STATUS,
	UNION_STATUS,HRS_FILENAME,INS_FILENAME	
FROM tbl_aca_dataset 
WHERE  (1=1) 
         AND (controlGroup IS NULL OR  FIND_IN_SET(REPLACE(CONTROL_GROUP_NAME,',',''), REPLACE(REPLACE(controlGroup,',',''),':',',')))
		AND (employerName IS NULL OR  FIND_IN_SET(REPLACE(EMPLOYER_NAME,',',''), REPLACE(REPLACE(employerName,',',''),':',',')))
        AND (sourceCode IS NULL OR  FIND_IN_SET(REPLACE(HRS_SOURCE_CODE,',',''), REPLACE(REPLACE(sourceCode,',',''),':',',')))
        AND (employeeName IS NULL OR (EMPLOYEE_FIRST_NAME LIKE CONCAT('%',employeeName ,'%') AND EMPLOYEE_FIRST_NAME LIKE CONCAT('%',employeeName,'%')))
        AND (hoursPaid IS NULL OR HOURS_PAID=hoursPaid);
	
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_AcaDataSet_GetSourceCode
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_AcaDataSet_GetSourceCode`;

DELIMITER $$
USE `siprasoft`$$


CREATE PROCEDURE `PRC_AcaDataSet_GetSourceCode`()
BEGIN
	SELECT DISTINCT HRS_SOURCE_CODE FROM tbl_aca_dataset;
   
	
END$$

DELIMITER ;



-- -----------------------------------------------------
-- procedure PRC_AcaDataSet_GetEmployerName
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_AcaDataSet_GetEmployerName`;

DELIMITER $$
USE `siprasoft`$$


CREATE PROCEDURE `PRC_AcaDataSet_GetEmployerName`()
BEGIN
	SELECT DISTINCT EMPLOYER_NAME FROM tbl_aca_dataset;
END$$

DELIMITER ;



-- -----------------------------------------------------
-- procedure PRC_AcaDataSet_GetControlGroup
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_AcaDataSet_GetControlGroup`;

DELIMITER $$
USE `siprasoft`$$

CREATE PROCEDURE `PRC_AcaDataSet_GetControlGroup`()
BEGIN
	SELECT DISTINCT CONTROL_GROUP_NAME FROM tbl_aca_dataset;
END$$

DELIMITER ;





-- -----------------------------------------------------
-- procedure PRC_AcaDataSet_DataCount
-- -----------------------------------------------------

USE `siprasoft`;
DROP procedure IF EXISTS `siprasoft`.`PRC_AcaDataSet_DataCount`;

DELIMITER $$
USE `siprasoft`$$


CREATE PROCEDURE `PRC_AcaDataSet_DataCount`(
        IN controlGroup VARCHAR(100),
        IN employerName VARCHAR(100),
        IN sourceCode VARCHAR(50),
        IN employeeName VARCHAR(100),
        IN hoursPaid VARCHAR(50)
     )
BEGIN
SELECT COUNT(*) AS COUNT FROM tbl_aca_dataset 
WHERE  (1=1) 
        AND (controlGroup IS NULL OR  FIND_IN_SET(REPLACE(CONTROL_GROUP_NAME,',',''), REPLACE(REPLACE(controlGroup,',',''),':',',')))
        AND (employerName IS NULL OR EMPLOYER_NAME=employerName)
        AND (sourceCode IS NULL OR HRS_SOURCE_CODE=sourceCode)
        AND (employeeName IS NULL OR (employeeName LIKE CONCAT('%',EMPLOYEE_FIRST_NAME,'%') AND employeeName LIKE CONCAT('%',EMPLOYEE_LAST_NAME,'%')))
        AND (hoursPaid IS NULL OR HOURS_PAID=hoursPaid);
END$$

DELIMITER ;



-- -----------------------------------------------------
-- procedure PRC_Original1095Report_GetControlGroup
-- -----------------------------------------------------

USE `siprasoft`;
DROP PROCEDURE IF EXISTS  `PRC_Original1095Report_GetControlGroup`;

DELIMITER $$
USE `siprasoft`$$

CREATE PROCEDURE `PRC_Original1095Report_GetControlGroup`()
BEGIN
	SELECT DISTINCT CONTROL_GROUP FROM tbl_original_1095;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure PRC_Original1095Report_GetTaxYear
-- -----------------------------------------------------

USE `siprasoft`;
DROP PROCEDURE IF EXISTS  `PRC_Original1095Report_GetTaxYear`;

DELIMITER $$
USE `siprasoft`$$

CREATE PROCEDURE `PRC_Original1095Report_GetTaxYear`()
BEGIN
	SELECT DISTINCT TAX_YEAR FROM tbl_original_1095;
END$$

DELIMITER ;


-- -----------------------------------------------------
-- procedure PRC_Original1095Report_ReportData
-- -----------------------------------------------------

USE `siprasoft`;
DROP PROCEDURE IF EXISTS  `PRC_Original1095Report_ReportData`;

DELIMITER $$
USE `siprasoft`$$

CREATE PROCEDURE `PRC_Original1095Report_ReportData`(
        IN controlGroup VARCHAR(100),
        IN taxYear VARCHAR(100)
     )
BEGIN
SELECT EMPLOYEE_FIRST_NAME,EMPLOYEE_MIDDLE_NAME,EMPLOYEE_LAST_NAME,EMPLOYEE_SSN,EMPLOYEE_ADDRESSLINE1,
EMPLOYEE_ADDRESSLINE2,EMPLOYEE_CITY,EMPLOYEE_STATE,EMPLOYEE_COUNTRY,EMPLOYEE_ZIP,EMPLOYER_NAME,
EMPLOYER_FEIN,EMPLOYER_ADDRESSLINE1,EMPLOYER_ADDRESSLINE2,EMPLOYER_ADDRESSLINE3,EMPLOYER_PHONE,
EMPLOYER_CITY,EMPLOYER_STATE,EMPLOYER_COUNTRY,EMPLOYER_ZIP,SELF_INSURANCE_COVERAGE,CONTROL_GROUP,
TAX_YEAR,LINE14_ALLMONTHS,LINE14_JAN,LINE14_FEB,LINE14_MAR,LINE14_APR,LINE14_MAY,LINE14_JUNE,
LINE14_JULY,LINE14_AUG,LINE14_SEPT,LINE14_OCT,LINE14_NOV,LINE14_DEC,LINE15_ALLMONTHS,LINE15_JAN,
LINE15_FEB,LINE15_MAR,LINE15_APR,LINE15_MAY,LINE15_JUNE,LINE15_JULY,LINE15_AUG,LINE15_SEPT,
LINE15_OCT,LINE15_NOV,LINE15_DEC,LINE16_ALLMONTHS,LINE16_JAN,LINE16_FEB,LINE16_MAR,LINE16_APR,
LINE16_MAY,LINE16_JUNE,LINE16_JULY,LINE16_AUG,LINE16_SEPT,LINE16_OCT,LINE16_NOV,LINE16_DEC,
LINE17_FIRSTNAME,LINE17_LASTNAME,LINE17_SSN,LINE17_DATEOFBIRTH,LINE17_ALLMONTHS,LINE17_JAN,
LINE17_FEB,LINE17_MAR,LINE17_APR,LINE17_MAY,LINE17_JUNE,LINE17_JULY,LINE17_AUG,LINE17_SEPT,
LINE17_OCT,LINE17_NOV,LINE17_DEC,LINE18_FIRSTNAME,LINE18_LASTNAME,LINE18_SSN,LINE18_DATEOFBIRTH,
LINE18_ALLMONTHS,LINE18_JAN,LINE18_FEB,LINE18_MAR,LINE18_APR,LINE18_MAY,LINE18_JUNE,LINE18_JULY,
LINE18_AUG,LINE18_SEPT,LINE18_OCT,LINE18_NOV,LINE18_DEC,LINE19_FIRSTNAME,LINE19_LASTNAME,
LINE19_SSN,LINE19_DATEOFBIRTH,LINE19_ALLMONTHS,LINE19_JAN,LINE19_FEB,LINE19_MAR,LINE19_APR,
LINE19_MAY,LINE19_JUNE,LINE19_JULY,LINE19_AUG,LINE19_SEPT,LINE19_OCT,LINE19_NOV,LINE19_DEC,
LINE20_FIRSTNAME,LINE20_LASTNAME,LINE20_SSN,LINE20_DATEOFBIRTH,LINE20_ALLMONTHS,LINE20_JAN,
LINE20_FEB,LINE20_MAR,LINE20_APR,LINE20_MAY,LINE20_JUNE,LINE20_JULY,LINE20_AUG,LINE20_SEPT,
LINE20_OCT,LINE20_NOV,LINE20_DEC,LINE21_FIRSTNAME,LINE21_LASTNAME,LINE21_SSN,LINE21_DATEOFBIRTH,
LINE21_ALLMONTHS,LINE21_JAN,LINE21_FEB,LINE21_MAR,LINE21_APR,LINE21_MAY,LINE21_JUNE,LINE21_JULY,
LINE21_AUG,LINE21_SEPT,LINE21_OCT,LINE21_NOV,LINE21_DEC,LINE22_FIRSTNAME,LINE22_LASTNAME,
LINE22_SSN,LINE22_DATEOFBIRTH,LINE22_ALLMONTHS,LINE22_JAN,LINE22_FEB,LINE22_MAR,LINE22_APR,
LINE22_MAY,LINE22_JUNE,LINE22_JULY,LINE22_AUG,LINE22_SEPT,LINE22_OCT,LINE22_NOV,LINE22_DEC
FROM tbl_original_1095
WHERE  (1=1) 
        AND (controlGroup IS NULL OR  FIND_IN_SET(REPLACE(CONTROL_GROUP,',',''), REPLACE(REPLACE(controlGroup,',',''),':',',')))
        AND (taxYear IS NULL OR TAX_YEAR=taxYear);
END$$

DELIMITER ;







call PRC_NewHiresFullTime_Generate_ReferenceData;
call PRC_NewHiresNonFullTime_Generate_ReferenceData;
call PRC_OnGoingReport_Generate_ReferenceData;
call PRC_PayrollDataActivity_Report_Generate_ReferenceData;
call PRC_ERCoverage_Report_Generate_ReferenceData;
call PRC_Eligibility_Generate_ReferenceData;
call PRC_DemoGraphics_Generate_ReferenceData;
call PRC_BreakIn_Generate_ReferenceData;
call PRC_LegalEntities_Generate_ReferenceData;