package com.reporting.webapi.response.vo;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "dataAcaPayrollReferenceData")
public class DataAcaPayrollReferenceDataVO {

	@XmlElementWrapper(name = "TaxYear")
	@XmlElement(name = "TaxYear")
	private List<String> taxYears;
	
	@XmlElementWrapper(name = "ControlGroup")
	@XmlElement(name = "ControlGroup")
	private List<String> controlgroups;
	
	@XmlElementWrapper(name = "SourceName")
	@XmlElement(name = "SourceName")
	private List<String> sourceNames;
	
	@XmlElementWrapper(name = "ProdCoName")
	@XmlElement(name = "ProdCoName")
	private List<String> prodCoNames;
	
	@XmlElementWrapper(name = "ProdShowName")
	@XmlElement(name = "ProdShowName")
	private List<String> prodShowNames;

	public List<String> getTaxYears() {
		return taxYears;
	}

	public void setTaxYears(List<String> taxYears) {
		this.taxYears = taxYears;
	}

	public List<String> getControlgroups() {
		return controlgroups;
	}

	public void setControlgroups(List<String> controlgroups) {
		this.controlgroups = controlgroups;
	}

	public List<String> getSourceNames() {
		return sourceNames;
	}

	public void setSourceNames(List<String> sourceNames) {
		this.sourceNames = sourceNames;
	}

	public List<String> getProdCoNames() {
		return prodCoNames;
	}

	public void setProdCoNames(List<String> prodCoNames) {
		this.prodCoNames = prodCoNames;
	}

	public List<String> getProdShowNames() {
		return prodShowNames;
	}

	public void setProdShowNames(List<String> prodShowNames) {
		this.prodShowNames = prodShowNames;
	}
	
	
}
