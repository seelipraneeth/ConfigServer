package com.reporting.webapi.responsewrapper.vo;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.reporting.webapi.response.vo.AcaDataSetServiceDataCountVO;

@XmlRootElement(name = "customtAcaDataSetServiceCountVO")
@XmlAccessorType(XmlAccessType.FIELD)
public class CustomtAcaDataSetServiceCountVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private List<AcaDataSetServiceDataCountVO> acaDataSetServiceCount;

	public List<AcaDataSetServiceDataCountVO> getAcaDataSetServiceCount() {
		return acaDataSetServiceCount;
	}

	public void setAcaDataSetServiceCount(List<AcaDataSetServiceDataCountVO> acaDataSetServiceCount) {
		this.acaDataSetServiceCount = acaDataSetServiceCount;
	}
	
}
