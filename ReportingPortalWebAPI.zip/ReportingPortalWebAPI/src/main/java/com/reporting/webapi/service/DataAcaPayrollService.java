package com.reporting.webapi.service;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.reporting.webapi.adapter.IDataAcaPayrollServiceAdapter;
import com.reporting.webapi.bean.DataAcaPayrollReferenceData;
import com.reporting.webapi.bean.NewHireFullTimeReferanceDataBean;
import com.reporting.webapi.response.vo.DataAcaPayrollReferenceDataVO;
import com.reporting.webapi.response.vo.DataAcaPayrollServiceDataCountVO;
import com.reporting.webapi.response.vo.DataAcaPayrollServiceReportDataVO;
import com.reporting.webapi.responsewrapper.vo.CustomDataAcaPayrollReferenceDataVO;
import com.reporting.webapi.responsewrapper.vo.CustomtDataAcaPayrollServiceDataCountVO;
import com.reporting.webapi.responsewrapper.vo.CustomtDataAcaPayrollServiceReportDataVO;
import com.reporting.webapi.util.CommonConstants;
import com.reporting.webapi.util.ReportsExcelBuilderUtil;

@Component
@Path(value=CommonConstants.DATA_ACA_PAYROLL_SERVICE)
public class DataAcaPayrollService {
	
	private final Logger logger = Logger.getLogger(DataAcaPayrollService.class);
	
	@Autowired
	private IDataAcaPayrollServiceAdapter dataAcaPayrollServiceAdapter;
	
	@Autowired
	private ReportsExcelBuilderUtil reportsExcelBuilderUtil;

	@Path(CommonConstants.DATA_ACA_PAYROLL_SERVICE_REFERENCE_DATA)
	@GET
	@Produces( { MediaType.APPLICATION_JSON})
	public Response getDataAcaPayrollServiceReferenceData() {
		
		if(logger.isDebugEnabled()){
			logger.debug("START :: DataAcaPayrollService : getDataAcaPayrollServiceReferenceData : Method to getDataAcaPayrollServiceReferenceData");
		}
		
		CustomDataAcaPayrollReferenceDataVO customDataAcaPayrollReferenceDataVO = new CustomDataAcaPayrollReferenceDataVO();
		try{
			DataAcaPayrollReferenceData dataAcaPayrollReferenceData = dataAcaPayrollServiceAdapter.getDataAcaPayrollServiceReferenceData();
			
			DataAcaPayrollReferenceDataVO dataAcaPayrollReferenceDataVO =  new DataAcaPayrollReferenceDataVO();
			dataAcaPayrollReferenceDataVO.setTaxYears(dataAcaPayrollReferenceData.getTaxYearList());
			dataAcaPayrollReferenceDataVO.setControlgroups(dataAcaPayrollReferenceData.getControlGroupList());
			dataAcaPayrollReferenceDataVO.setSourceNames(dataAcaPayrollReferenceData.getSourceNameList());
			dataAcaPayrollReferenceDataVO.setProdCoNames(dataAcaPayrollReferenceData.getProdCoNameList());
			dataAcaPayrollReferenceDataVO.setProdShowNames(dataAcaPayrollReferenceData.getProdShowNameList());
			
			customDataAcaPayrollReferenceDataVO.setDataAcaPayrollReferenceData(dataAcaPayrollReferenceDataVO);
			
		} catch (Exception e) {
			logger.error("Error while invoking getDataAcaPayrollServiceReferenceData : " + e.getMessage());
		}	
		if(logger.isDebugEnabled()){
			logger.debug("END :: DataAcaPayrollService : getDataAcaPayrollServiceReferenceData : Method to getDataAcaPayrollServiceReferenceData");
		}
		
		return Response.ok(customDataAcaPayrollReferenceDataVO).build();
	}
	
	@Path(CommonConstants.DATA_ACA_PAYROLL_SERVICE_COUNT)
	@GET
	@Produces( { MediaType.APPLICATION_JSON})
	public Response getDataAcaPayrollServiceDataCount(@QueryParam(CommonConstants.TAX_YEAR) String taxYear, @QueryParam(CommonConstants.CONTROL_GROUP) String controlGroup,
			@QueryParam(CommonConstants.SOURCE_NAME) String sourceName, @QueryParam(CommonConstants.PROD_CO_NAME) String prodCoName, @QueryParam(CommonConstants.PROD_SHOW_NAME) String prodShowName) {
		
		if(logger.isDebugEnabled()){
			logger.debug("START :: DataAcaPayrollService : getDataAcaPayrollServiceDataCount : Method to getDataAcaPayrollServiceDataCount");
		}
		
		CustomtDataAcaPayrollServiceDataCountVO customtDataAcaPayrollServiceDataCountVO = new CustomtDataAcaPayrollServiceDataCountVO();
		List<DataAcaPayrollServiceDataCountVO> dataAcaPayrollServiceDataCount = null;
		try{
			if(null != taxYear && taxYear.contains("''") &&  taxYear.length() == 2) {
				taxYear = null;
			}
			if(null != controlGroup && controlGroup.contains("''") &&  controlGroup.length() == 2) {
				controlGroup = null;
			}
			if(null != sourceName && sourceName.contains("''") &&  sourceName.length() == 2) {
				sourceName = null;
			}
			if(null != prodCoName && prodCoName.contains("''") &&  prodCoName.length() == 2) {
				prodCoName = null;
			}
			if(null != prodShowName && prodShowName.contains("''") &&  prodShowName.length() == 2) {
				prodShowName = null;
			}
			
			dataAcaPayrollServiceDataCount =  dataAcaPayrollServiceAdapter.getDataAcaPayrollServiceDataCount(taxYear,controlGroup,sourceName,prodCoName,prodShowName);
			customtDataAcaPayrollServiceDataCountVO.setDataAcaPayrollServiceDataCount(dataAcaPayrollServiceDataCount);
		} catch (Exception e) {
			logger.error("Error while invoking getDataAcaPayrollServiceDataCount : " + e.getMessage());
		}
		
		if(logger.isDebugEnabled()){
			logger.debug("END :: DataAcaPayrollService : getDataAcaPayrollServiceDataCount : Method to getDataAcaPayrollServiceDataCount");
		}
		
		return Response.ok(customtDataAcaPayrollServiceDataCountVO).build();
	}
	
	@Path(CommonConstants.DATA_ACA_PAYROLL_SERVICE_REPORT_DATA)
	@GET
	@Produces( { MediaType.APPLICATION_JSON})
	public Response getDataAcaPayrollServiceReportData(@QueryParam(CommonConstants.TAX_YEAR) String taxYear, @QueryParam(CommonConstants.CONTROL_GROUP) String controlGroup,
			@QueryParam(CommonConstants.SOURCE_NAME) String sourceName, @QueryParam(CommonConstants.PROD_CO_NAME) String prodCoName, @QueryParam(CommonConstants.PROD_SHOW_NAME) String prodShowName) {
		
		if(logger.isDebugEnabled()){
			logger.debug("START :: DataAcaPayrollService : getDataAcaPayrollServiceReportData : Method to getDataAcaPayrollServiceReportData");
		}
		CustomtDataAcaPayrollServiceReportDataVO customtDataAcaPayrollServiceReportDataVO = new CustomtDataAcaPayrollServiceReportDataVO();
		List<DataAcaPayrollServiceReportDataVO> dataAcaPayrollServiceReportData = null;
		try {
			if(null != taxYear && taxYear.contains("''") &&  taxYear.length() == 2) {
				taxYear = null;
			}
			if(null != controlGroup && controlGroup.contains("''") &&  controlGroup.length() == 2) {
				controlGroup = null;
			}
			if(null != sourceName && sourceName.contains("''") &&  sourceName.length() == 2) {
				sourceName = null;
			}
			if(null != prodCoName && prodCoName.contains("''") &&  prodCoName.length() == 2) {
				prodCoName = null;
			}
			if(null != prodShowName && prodShowName.contains("''") &&  prodShowName.length() == 2) {
				prodShowName = null;
			}
			dataAcaPayrollServiceReportData =  dataAcaPayrollServiceAdapter.getDataAcaPayrollServiceReportData(taxYear,controlGroup,sourceName,prodCoName,prodShowName);
			customtDataAcaPayrollServiceReportDataVO.setDataAcaPayrollServiceReportData(dataAcaPayrollServiceReportData);
		} catch(Exception e) {
			logger.error("Error while invoking getDataAcaPayrollServiceReportData : " + e.getMessage());
		}
		if(logger.isDebugEnabled()){
			logger.debug("START :: DataAcaPayrollService : getDataAcaPayrollServiceReportData : Method to getDataAcaPayrollServiceReportData");
		}
		return Response.ok(customtDataAcaPayrollServiceReportDataVO).build();
	}
	
	@Path(CommonConstants.DATA_ACA_PAYROLL_SERVICE_PROCESS_EXCEL_ZIP_DOWNLOAD)
	@GET
	@Produces(CommonConstants.APPLICATION_ZIP)
	public Response processDataAcaPayrollServiceReportExcelUpload(@QueryParam(CommonConstants.TAX_YEAR) String taxYear, @QueryParam(CommonConstants.CONTROL_GROUP) String controlGroup,
			@QueryParam(CommonConstants.SOURCE_NAME) String sourceName, @QueryParam(CommonConstants.PROD_CO_NAME) String prodCoName, @QueryParam(CommonConstants.PROD_SHOW_NAME) String prodShowName) {
		
		if(logger.isDebugEnabled()){
			logger.debug("START :: DataAcaPayrollService : processDataAcaPayrollServiceReportExcelUpload : Method to processDataAcaPayrollServiceReportExcelUpload");
		}
		List<DataAcaPayrollServiceReportDataVO> dataAcaPayrollServiceReportData = null;
		String generatedReportsPath = "";
		try {
			if(null != taxYear && taxYear.contains("''") &&  taxYear.length() == 2) {
				taxYear = null;
			}
			if(null != controlGroup && controlGroup.contains("''") &&  controlGroup.length() == 2) {
				controlGroup = null;
			}
			if(null != sourceName && sourceName.contains("''") &&  sourceName.length() == 2) {
				sourceName = null;
			}
			if(null != prodCoName && prodCoName.contains("''") &&  prodCoName.length() == 2) {
				prodCoName = null;
			}
			if(null != prodShowName && prodShowName.contains("''") &&  prodShowName.length() == 2) {
				prodShowName = null;
			}
			dataAcaPayrollServiceReportData =  dataAcaPayrollServiceAdapter.getDataAcaPayrollServiceReportData(taxYear,controlGroup,sourceName,prodCoName,prodShowName);
			
			// Code To Invoke Excel Builder 
			Map<String, List<?>> reportsDataMap = new HashMap<>();
			reportsDataMap.put(CommonConstants.DATA_ACA_PAYROLL_REPORT, dataAcaPayrollServiceReportData);
						
			DataAcaPayrollReferenceData dataAcaPayrollReferenceData = dataAcaPayrollServiceAdapter.getDataAcaPayrollServiceReferenceData();
			List<String> controlGroupList = dataAcaPayrollReferenceData.getControlGroupList();
			
			generatedReportsPath = reportsExcelBuilderUtil.buildExcelDocument(reportsDataMap, controlGroupList, taxYear, controlGroup, sourceName, prodCoName, prodShowName);
			
		} catch(Exception e) {
			logger.error("Error while invoking processDataAcaPayrollServiceReportExcelUpload : " + e.getMessage());
		}
		if(logger.isDebugEnabled()){
			logger.debug("START :: DataAcaPayrollService : processDataAcaPayrollServiceReportExcelUpload : Method to processDataAcaPayrollServiceReportExcelUpload");
		}
		
		File downloadDocumentFile = new File(generatedReportsPath + ".zip");
		String buildZipFilename = "DataAcaPayrollServiceReports_" + generatedReportsPath.substring(generatedReportsPath.lastIndexOf("/")+1, generatedReportsPath.length()) + ".zip";
		ResponseBuilder responseBuilder = Response.ok((Object) downloadDocumentFile);
        responseBuilder.header("Content-Disposition", "attachment; filename=" + buildZipFilename );
		return responseBuilder.build();
	}
}
