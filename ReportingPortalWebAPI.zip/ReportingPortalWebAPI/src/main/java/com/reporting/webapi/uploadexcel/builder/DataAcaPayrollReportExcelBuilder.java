package com.reporting.webapi.uploadexcel.builder;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.reporting.webapi.response.vo.DataAcaPayrollServiceReportDataVO;
import com.reporting.webapi.util.CommonUtil;
import com.reporting.webapi.util.FolderZipUtil;

@Component
public class DataAcaPayrollReportExcelBuilder {

	private final Logger logger = Logger.getLogger(DataAcaPayrollReportExcelBuilder.class);

	@Autowired
	private CommonUtil commonUtil;
	
	@Autowired
	private FolderZipUtil folderZipUtil;
	
	public String processExcelContent(Map<String, List<DataAcaPayrollServiceReportDataVO>> reportsMapByControlGroup, String[] argParams) throws UnsupportedEncodingException {
		
		XSSFWorkbook workbook = null;
		XSSFSheet sheet = null;
		XSSFCellStyle style = null;
		Set<String> keySetValues = reportsMapByControlGroup.keySet();
		
		String folderNameTimeStampString = new SimpleDateFormat("yyyyMMddHHmmsss").format(new Date());
		String path = this.getClass().getClassLoader().getResource("").getPath();
		String fullPath = URLDecoder.decode(path, "UTF-8");
		
		String pathArr[] = fullPath.split("/WEB-INF/classes/");
		String reportsPath = pathArr[0]+"/reportsData/DataAcaPayrollReports/"+folderNameTimeStampString;
		
		File reportsDirectory = new File(reportsPath);
		if(!reportsDirectory.exists()){
			try{
				reportsDirectory.mkdirs();
			} 
			catch(SecurityException se){
				logger.error(" processExcelContent :: Error while creating the required Directory : ", se);
			}      
		}
		
		for(String reportMapKey : keySetValues) {
			
			// Retrieving the ReportList specific to the ControlGroup matching reportMapKey
			List<DataAcaPayrollServiceReportDataVO> reportsList = reportsMapByControlGroup.get(reportMapKey);

			// Set the Control Group Name to controlGroup param in argParams
			argParams[1] = reportMapKey;

			// Initializing workbook, sheet and style
			// initialize work book
			workbook = new XSSFWorkbook();

			// initialize sheet
			sheet = workbook.createSheet("Sheet1");

			sheet.setDefaultColumnWidth(30);

			XSSFCellStyle headerCellStyle = workbook.createCellStyle();
			XSSFFont boldFont = workbook.createFont();
			boldFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
			headerCellStyle.setFont(boldFont);

			style = workbook.createCellStyle();
			XSSFFont font = workbook.createFont();

			font.setFontName("Arial");
			style.setFillForegroundColor(IndexedColors.BLUE.getIndex());
			style.setFillPattern(CellStyle.SOLID_FOREGROUND);
			font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
			font.setColor(IndexedColors.WHITE.getIndex());
			style.setFont(font);

			logger.info(" processExcelContent :: 'workbook', 'sheet' and 'style' have been initialized ");
			
			Row header = sheet.createRow(0);
	        header.createCell(0).setCellValue("SSN");
	        header.getCell(0).setCellStyle(style);
	        header.createCell(1).setCellValue("First Name");
	        header.getCell(1).setCellStyle(style);
	        header.createCell(2).setCellValue("Last Name");
	        header.getCell(2).setCellStyle(style);
	        header.createCell(3).setCellValue("Address");
	        header.getCell(3).setCellStyle(style);
	        header.createCell(4).setCellValue("City");
	        header.getCell(4).setCellStyle(style);
	        header.createCell(5).setCellValue("State");
	        header.getCell(5).setCellStyle(style);
	        header.createCell(6).setCellValue("Birth Date");
	        header.getCell(6).setCellStyle(style);
	        header.createCell(7).setCellValue("First Worked Date");
	        header.getCell(7).setCellStyle(style);
	        header.createCell(8).setCellValue("Last Worked Date");
	        header.getCell(8).setCellStyle(style);
	        header.createCell(9).setCellValue("Termination Date");
	        header.getCell(9).setCellStyle(style);
	        header.createCell(10).setCellValue("Period Ending Date");
	        header.getCell(10).setCellStyle(style);
	        header.createCell(11).setCellValue("Hours Worked");
	        header.getCell(11).setCellStyle(style);
	        header.createCell(12).setCellValue("Is Union");
	        header.getCell(12).setCellStyle(style);
	        header.createCell(13).setCellValue("Employment Status");
	        header.getCell(13).setCellStyle(style);
	        header.createCell(14).setCellValue("Control Group");
	        header.getCell(14).setCellStyle(style);
	        
	        int rowCount = 1;
	        for(Object reportObj : reportsList) {
	        	DataAcaPayrollServiceReportDataVO reportRowBean = (DataAcaPayrollServiceReportDataVO)reportObj;
	        	
	        	Row newRow = sheet.createRow(rowCount++);
	        	
	        	newRow.createCell(0).setCellValue(reportRowBean.getSsn());
	        	newRow.createCell(1).setCellValue(reportRowBean.getFirstName());
	        	newRow.createCell(2).setCellValue(reportRowBean.getLastName());
	        	newRow.createCell(3).setCellValue(reportRowBean.getAddress());
	        	newRow.createCell(4).setCellValue(reportRowBean.getCity());
	        	newRow.createCell(5).setCellValue(reportRowBean.getState());
	        	newRow.createCell(6).setCellValue(reportRowBean.getBirthDate());
	        	newRow.createCell(7).setCellValue(reportRowBean.getFirstWorkedDate());
	        	newRow.createCell(8).setCellValue(reportRowBean.getLastWorkedDate());
	        	newRow.createCell(9).setCellValue(reportRowBean.getTerminationDate());
	        	newRow.createCell(10).setCellValue(reportRowBean.getPeriodEndingDate());
	        	newRow.createCell(11).setCellValue(reportRowBean.getHoursWorked());
	        	newRow.createCell(12).setCellValue(reportRowBean.getUnion());
	        	newRow.createCell(13).setCellValue(reportRowBean.getEmploymentStatus());
	        	newRow.createCell(14).setCellValue(reportRowBean.getControlGroup());
	        }
	        
	        try{
	        	String fileName = commonUtil.buildUploadExcelFileName(argParams);
	        	System.out.println("FileName Built with argument params : " + fileName);
	        	logger.info("DataAcaPayrollReportExcelBuilder :: FileName Built with argument params : " + fileName);
	        	
	        	FileOutputStream outputStream = new FileOutputStream(reportsPath+"/"+fileName);
	        	
	        	workbook.write(outputStream);
	            workbook.close();
	            
	        } catch(FileNotFoundException fe) {
	        	logger.error(" DataAcaPayrollReportExcelBuilder :: Error while Building the Excel Report file : ", fe);
	        } catch(Exception e) {
	        	logger.error(" DataAcaPayrollReportExcelBuilder :: Error while Building the Excel Report file : ", e);
	        }finally {
		       	workbook = null;
		       	sheet = null;
		       	style = null;
		    }
		}
		
		// Process ZIP the generated reports - with the Directory Name generated for Reports
		List<String> fileList = new ArrayList<String>(); 
		String sourceFolderPath = pathArr[0]+"/reportsData/DataAcaPayrollReports/"+folderNameTimeStampString;
		String outputZipFileName = sourceFolderPath + ".zip";
				
		fileList = commonUtil.generateFileList(reportsDirectory, fileList, sourceFolderPath);
		folderZipUtil.zipIt(outputZipFileName, sourceFolderPath, fileList,folderNameTimeStampString);
		
		return reportsPath;
	}
	
	
	public Map<String, List<DataAcaPayrollServiceReportDataVO>> processReportsMapByControlGroup(List<?> reportsList, List<String> controlGroupList) {
		Map<String, List<DataAcaPayrollServiceReportDataVO>> reportsMapByControlGroup = new HashMap<String, List<DataAcaPayrollServiceReportDataVO>>();
		for(String controlGroupName : controlGroupList) {
			List<DataAcaPayrollServiceReportDataVO> reportList = new ArrayList<DataAcaPayrollServiceReportDataVO>();
			for(Object objRef : reportsList) {
				DataAcaPayrollServiceReportDataVO dataAcaPayrollReportObj = (DataAcaPayrollServiceReportDataVO)objRef;
				if(controlGroupName.equalsIgnoreCase(dataAcaPayrollReportObj.getControlGroup())) {
					reportList.add(dataAcaPayrollReportObj);
				}
			}
			reportsMapByControlGroup.put(controlGroupName, reportList);
		}
		return reportsMapByControlGroup;
	}
	
}
