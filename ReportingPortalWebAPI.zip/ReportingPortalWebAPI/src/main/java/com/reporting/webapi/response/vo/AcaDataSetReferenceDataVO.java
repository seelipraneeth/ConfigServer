package com.reporting.webapi.response.vo;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "acaDataSetReferenceData")
public class AcaDataSetReferenceDataVO {

	@XmlElementWrapper(name = "ControlGroup")
	@XmlElement(name = "ControlGroup")
	private List<String> controlgroups;
	
	@XmlElementWrapper(name = "EmployerNames")
	@XmlElement(name = "EmployerNames")
	private List<String> employerNames;
	
	@XmlElementWrapper(name = "SourceCodes")
	@XmlElement(name = "SourceCodes")
	private List<String> sourceCodes;

	public List<String> getControlgroups() {
		return controlgroups;
	}

	public void setControlgroups(List<String> controlgroups) {
		this.controlgroups = controlgroups;
	}

	public List<String> getEmployerNames() {
		return employerNames;
	}

	public void setEmployerNames(List<String> employerNames) {
		this.employerNames = employerNames;
	}

	public List<String> getSourceCodes() {
		return sourceCodes;
	}

	public void setSourceCodes(List<String> sourceCodes) {
		this.sourceCodes = sourceCodes;
	}
	
	
	
}
