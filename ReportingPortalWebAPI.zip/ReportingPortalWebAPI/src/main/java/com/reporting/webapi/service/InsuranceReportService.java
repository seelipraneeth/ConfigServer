

package com.reporting.webapi.service;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.reporting.webapi.adapter.IInsuranceReportAdapter;
import com.reporting.webapi.bean.InsuranceServiceReferanceDataBean;
import com.reporting.webapi.response.vo.InsuranceReferanceDataVO;
import com.reporting.webapi.response.vo.InsuranceReportDataVO;
import com.reporting.webapi.responsewrapper.vo.CustomInsuranceReferenceDataVO;
import com.reporting.webapi.responsewrapper.vo.CustomInsuranceReportVO;
import com.reporting.webapi.util.CommonConstants;
import com.reporting.webapi.util.ReportsExcelBuilderUtil;

@Component
@Path(value=CommonConstants.INSURANCE_SERVICE)
public class InsuranceReportService {
	
	private final Logger logger = Logger.getLogger(InsuranceReportService.class);
	
	@Autowired
	private IInsuranceReportAdapter insuranceReportAdapter;
	
	@Autowired
	private ReportsExcelBuilderUtil reportsExcelBuilderUtil;
	
	@Path(CommonConstants.INSURANCE_SERVICE_REFERENCE_DATA)
	@GET
	@Produces( { MediaType.APPLICATION_JSON})
	public Response getInsuranceServiceReferenceData() {
		
		if(logger.isDebugEnabled()){
			logger.debug("START :: InsuranceReportService : getInsuranceServiceReferenceData : Method to getInsuranceServiceReferenceData");
		}
		
		CustomInsuranceReferenceDataVO customInsuranceReferenceDataVO = new CustomInsuranceReferenceDataVO();
		try{
			InsuranceServiceReferanceDataBean insuranceServiceReferanceDataBean = insuranceReportAdapter.getInsuranceServiceReferenceData();
			
			InsuranceReferanceDataVO insuranceReferanceDataVO =  new InsuranceReferanceDataVO();
			insuranceReferanceDataVO.setTaxYear(insuranceServiceReferanceDataBean.getTaxYearList());
			insuranceReferanceDataVO.setControlGroup(insuranceServiceReferanceDataBean.getControlGroupList());
						
			customInsuranceReferenceDataVO.setInsuranceReferanceData(insuranceReferanceDataVO);
			
		} catch (Exception e) {
			logger.error("Error while invoking getInsuranceServiceReferenceData : " + e.getMessage());
		}	
		if(logger.isDebugEnabled()){
			logger.debug("END :: InsuranceReportService : getInsuranceServiceReferenceData : Method to getInsuranceServiceReferenceData");
		}
		
		return Response.ok(customInsuranceReferenceDataVO).build();
	}
	
	
	@Path(CommonConstants.INSURANCE_SERVICE_REPORT_DATA)
	@GET
	@Produces( { MediaType.APPLICATION_JSON})
	public Response getInsuranceReportData(@QueryParam(CommonConstants.TAX_YEAR) String taxYear,
			@QueryParam(CommonConstants.CONTROL_GROUP) String controlGroup) {
		
		if(logger.isDebugEnabled()){
			logger.debug("START :: InsurnaceReportService : getInsuranceReportData");
		}
		
		CustomInsuranceReportVO customInsuranceReportVO = new CustomInsuranceReportVO();
		try{
			if(null != taxYear && taxYear.contains("''") &&  taxYear.length() == 2) {
				taxYear = null;
			}
			if(null != controlGroup && controlGroup.contains("''") &&  controlGroup.length() == 2) {
				controlGroup = null;
			}
			List<InsuranceReportDataVO> insuranceReportDataVO = insuranceReportAdapter.getInsuranceReportData(taxYear,controlGroup);
			
			customInsuranceReportVO.setInsuranceReportData(insuranceReportDataVO);
			
		} catch (Exception e) {
			logger.error("Error while invoking getInsuranceReportData : " + e.getMessage());
		}
		
		
		if(logger.isDebugEnabled()){
			logger.debug("END :: LegalEntitiesReportService : getLegalEntitiesReportData");
		}
		
		return Response.ok(customInsuranceReportVO).build();
	}
	
	
	@Path(CommonConstants.INSURANCE_SERVICE_PROCESS_EXCEL_ZIP_DOWNLOAD)
	@GET
	@Produces(CommonConstants.APPLICATION_ZIP)
	public Response processBreakInReportExcelUpload(@QueryParam(CommonConstants.TAX_YEAR) String taxYear,
			@QueryParam(CommonConstants.CONTROL_GROUP) String controlGroup) {
		List<InsuranceReportDataVO> insuranceReportDataVO = null;
		String generatedReportsPath = "";
		try{
			if(null != taxYear && taxYear.contains("''") &&  taxYear.length() == 2) {
				taxYear = null;
			}
			if(null != controlGroup && controlGroup.contains("''") &&  controlGroup.length() == 2) {
				controlGroup = null;
			}
			
			insuranceReportDataVO = insuranceReportAdapter.getInsuranceReportData(taxYear,controlGroup);
			
			// Code To Invoke Excel Builder 
			Map<String, List<?>> reportsDataMap = new HashMap<>();
			reportsDataMap.put(CommonConstants.INSURANCE_REPORT, insuranceReportDataVO);
			
			InsuranceServiceReferanceDataBean insuranceServiceReferanceDataBean = insuranceReportAdapter.getInsuranceServiceReferenceData();
			List<String> controlGroupList = insuranceServiceReferanceDataBean.getControlGroupList();
			
			generatedReportsPath = reportsExcelBuilderUtil.buildExcelDocument(reportsDataMap, controlGroupList, taxYear,controlGroup);
						
		} catch (Exception e) {
			//logger.error("Error while invoking getHireWorkYears : " + e.getMessage());
		}
		
		File downloadDocumentFile = new File(generatedReportsPath + ".zip");
		String buildZipFilename = "InsuranceReport_" + generatedReportsPath.substring(generatedReportsPath.lastIndexOf("/")+1, generatedReportsPath.length()) + ".zip";
		ResponseBuilder responseBuilder = Response.ok((Object) downloadDocumentFile);
        responseBuilder.header("Content-Disposition", "attachment; filename=" + buildZipFilename );
		return responseBuilder.build();
	}
	
}
