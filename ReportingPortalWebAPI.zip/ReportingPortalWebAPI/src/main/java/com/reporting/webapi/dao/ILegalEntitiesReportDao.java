package com.reporting.webapi.dao;

import java.util.List;

import com.reporting.webapi.bean.LegalEntitiesServiceReferanceDataBean;
import com.reporting.webapi.response.vo.LegalEntitiesReportDataVO;

public interface ILegalEntitiesReportDao {
	public LegalEntitiesServiceReferanceDataBean getLegalEntitiesServiceReferenceData()throws Exception;
	public List<LegalEntitiesReportDataVO> getLegalEntitiesReportData(String taxYear,String controlGroup) throws Exception;
}
