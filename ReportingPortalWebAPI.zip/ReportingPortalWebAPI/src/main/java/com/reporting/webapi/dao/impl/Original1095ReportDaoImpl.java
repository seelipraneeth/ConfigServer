package com.reporting.webapi.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import com.reporting.webapi.bean.Original1095ReportReferenceData;
import com.reporting.webapi.dao.IOriginal1095ReportDao;
import com.reporting.webapi.response.vo.Original1095ReportDataVO;

@Repository
public class Original1095ReportDaoImpl implements IOriginal1095ReportDao {

	private final Logger logger = Logger.getLogger(AcaDataSetServiceDaoImpl.class);
	
	@Resource(name = "sessionFactory")
	private SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	@Override
	public Original1095ReportReferenceData getOriginal1095ReportReferenceData() {
		if (logger.isDebugEnabled()) {
			logger.debug(
					"START :: Original1095ReportDaoImpl : getOriginal1095ReportReferenceData : Method to getOriginal1095ReportReferenceData");
		}
		Session session = sessionFactory.openSession();
		Original1095ReportReferenceData original1095ReportReferenceData = new Original1095ReportReferenceData();
		try {
			Query controlGroupQuery = session.getNamedQuery("PRC_Original1095Report_GetControlGroup");
			original1095ReportReferenceData.setControlGroupList(controlGroupQuery.list());
			
			Query taxYearQuery = session.getNamedQuery("PRC_Original1095Report_GetTaxYear");
			original1095ReportReferenceData.setTaxYearList(taxYearQuery.list());
		} catch(Exception e) {
			logger.error("Error while fetching data getOriginal1095ReportReferenceData : " + e.getMessage());
		}
		if (logger.isDebugEnabled()) {
			logger.debug(
					"END :: Original1095ReportDaoImpl : getOriginal1095ReportReferenceData : Method to getOriginal1095ReportReferenceData");
		}
		return original1095ReportReferenceData;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Original1095ReportDataVO> getOriginal1095ReportData(String controlGroup, String taxYear) {
		if (logger.isDebugEnabled()) {
			logger.debug(
					"START :: Original1095ReportDaoImpl : getOriginal1095ReportData : Method to getOriginal1095ReportData");
		}
		Session session = sessionFactory.openSession();
		List<Original1095ReportDataVO> listVO = null;
		List<Original1095ReportDataVO> list = null;
		Original1095ReportDataVO original1095ReportDataVO = null;
		
		try{
			Query query = session.getNamedQuery("PRC_Original1095Report_ReportData");
			query.setParameter("controlGroup", controlGroup);
			query.setParameter("taxYear", taxYear);
			list = query.list();
			
			if (list != null && list.size() > 0) {
				listVO = new ArrayList<>();
				for (Object obj : list) {

					original1095ReportDataVO = new Original1095ReportDataVO();

					Object[] column = (Object[]) obj;

					if (null != column[0]) {
						original1095ReportDataVO.setEmployeeFirstName((column[0].toString()));
						original1095ReportDataVO.setEmployeeName((column[0].toString()) + " ");
					}
					if (null != column[1]) {
						original1095ReportDataVO.setEmployeeMiddleName((column[1].toString()));
						if (StringUtils.isNotBlank(original1095ReportDataVO.getEmployeeName())) {
							original1095ReportDataVO.setEmployeeName(
									original1095ReportDataVO.getEmployeeName() + (column[1].toString()));
						} else {
							original1095ReportDataVO.setEmployeeName((column[1].toString()));
						}
					}
					if (null != column[2]) {
						original1095ReportDataVO.setEmployeeLastName((column[2].toString()));
						if (StringUtils.isNotBlank(original1095ReportDataVO.getEmployeeName())) {
							original1095ReportDataVO.setEmployeeName(
									original1095ReportDataVO.getEmployeeName() + (column[2].toString()));
						} else {
							original1095ReportDataVO.setEmployeeName((column[2].toString()));
						}
					}
					if (null != column[3]) {
						original1095ReportDataVO.setEmployeeSSN((column[3].toString()));
					}
					if (null != column[4]) {
						original1095ReportDataVO.setEmployeeAddressLine1((column[4].toString()));
					}
					if (null != column[5]) {
						original1095ReportDataVO.setEmployeeAddressLine2((column[5].toString()));
					}
					if (null != column[6]) {
						original1095ReportDataVO.setEmployeeCity((column[6].toString()));
					}
					if (null != column[7]) {
						original1095ReportDataVO.setEmployeeState((column[7].toString()));
					}
					if (null != column[8]) {
						original1095ReportDataVO.setEmployeeCountry((column[8].toString()));
					}
					if (null != column[9]) {
						original1095ReportDataVO.setEmployeeZip((column[9].toString()));
					}

					if (null != column[10]) {
						original1095ReportDataVO.setEmployerName((column[10].toString()));
					}
					if (null != column[11]) {
						original1095ReportDataVO.setEmployerFEIN((column[11].toString()));
					}
					if (null != column[12]) {
						original1095ReportDataVO.setEmployerAddressLine1((column[12].toString()));
					}
					if (null != column[13]) {
						original1095ReportDataVO.setEmployerAddressLine2((column[13].toString()));
					}
					if (null != column[14]) {
						original1095ReportDataVO.setEmployerAddressLine3((column[14].toString()));
					}
					if (null != column[15]) {
						original1095ReportDataVO.setEmployerContactPhone((column[15].toString()));
					}
					if (null != column[16]) {
						original1095ReportDataVO.setEmployerCity((column[16].toString()));
					}
					if (null != column[17]) {
						original1095ReportDataVO.setEmployerState((column[17].toString()));
					}
					if (null != column[18]) {
						original1095ReportDataVO.setEmployerCountry((column[18].toString()));
					}
					if (null != column[19]) {
						original1095ReportDataVO.setEmployerZip((column[19].toString()));
					}

					if (null != column[20]) {
						original1095ReportDataVO.setSelfInsuranceCoverage((column[20].toString()));
					}
					if (null != column[21]) {
						original1095ReportDataVO.setControlGroup((column[21].toString()));
					}
					if (null != column[22]) {
						original1095ReportDataVO.setTaxYear((column[22].toString()));
					}

					if (null != column[23]) {
						original1095ReportDataVO.setLine14AllMonths((column[23].toString()));
					}
					if (null != column[24]) {
						original1095ReportDataVO.setLine14Jan((column[24].toString()));
					}
					if (null != column[25]) {
						original1095ReportDataVO.setLine14Feb((column[25].toString()));
					}
					if (null != column[26]) {
						original1095ReportDataVO.setLine14Mar((column[26].toString()));
					}
					if (null != column[27]) {
						original1095ReportDataVO.setLine14Apr((column[27].toString()));
					}
					if (null != column[28]) {
						original1095ReportDataVO.setLine14May((column[28].toString()));
					}
					if (null != column[29]) {
						original1095ReportDataVO.setLine14June((column[29].toString()));
					}
					if (null != column[30]) {
						original1095ReportDataVO.setLine14July((column[30].toString()));
					}
					if (null != column[31]) {
						original1095ReportDataVO.setLine14Aug((column[31].toString()));
					}
					if (null != column[32]) {
						original1095ReportDataVO.setLine14Sept((column[32].toString()));
					}
					if (null != column[33]) {
						original1095ReportDataVO.setLine14Oct((column[33].toString()));
					}
					if (null != column[34]) {
						original1095ReportDataVO.setLine14Nov((column[34].toString()));
					}
					if (null != column[35]) {
						original1095ReportDataVO.setLine14Dec((column[35].toString()));
					}

					if (null != column[36]) {
						original1095ReportDataVO.setLine15AllMonths((column[36].toString()));
					}
					if (null != column[37]) {
						original1095ReportDataVO.setLine15Jan((column[37].toString()));
					}
					if (null != column[38]) {
						original1095ReportDataVO.setLine15Feb((column[38].toString()));
					}
					if (null != column[39]) {
						original1095ReportDataVO.setLine15Mar((column[39].toString()));
					}
					if (null != column[40]) {
						original1095ReportDataVO.setLine15Apr((column[40].toString()));
					}
					if (null != column[41]) {
						original1095ReportDataVO.setLine15May((column[41].toString()));
					}
					if (null != column[42]) {
						original1095ReportDataVO.setLine15June((column[42].toString()));
					}
					if (null != column[43]) {
						original1095ReportDataVO.setLine15July((column[43].toString()));
					}
					if (null != column[44]) {
						original1095ReportDataVO.setLine15Aug((column[44].toString()));
					}
					if (null != column[45]) {
						original1095ReportDataVO.setLine15Sept((column[45].toString()));
					}
					if (null != column[46]) {
						original1095ReportDataVO.setLine15Oct((column[46].toString()));
					}
					if (null != column[47]) {
						original1095ReportDataVO.setLine15Nov((column[47].toString()));
					}
					if (null != column[48]) {
						original1095ReportDataVO.setLine15Dec((column[48].toString()));
					}

					if (null != column[49]) {
						original1095ReportDataVO.setLine16AllMonths((column[49].toString()));
					}
					if (null != column[50]) {
						original1095ReportDataVO.setLine16Jan((column[50].toString()));
					}
					if (null != column[51]) {
						original1095ReportDataVO.setLine16Feb((column[51].toString()));
					}
					if (null != column[52]) {
						original1095ReportDataVO.setLine16Mar((column[52].toString()));
					}
					if (null != column[53]) {
						original1095ReportDataVO.setLine16Apr((column[53].toString()));
					}
					if (null != column[54]) {
						original1095ReportDataVO.setLine16May((column[54].toString()));
					}
					if (null != column[55]) {
						original1095ReportDataVO.setLine16June((column[55].toString()));
					}
					if (null != column[56]) {
						original1095ReportDataVO.setLine16July((column[56].toString()));
					}
					if (null != column[57]) {
						original1095ReportDataVO.setLine16Aug((column[57].toString()));
					}
					if (null != column[58]) {
						original1095ReportDataVO.setLine16Sept((column[58].toString()));
					}
					if (null != column[59]) {
						original1095ReportDataVO.setLine16Oct((column[59].toString()));
					}
					if (null != column[60]) {
						original1095ReportDataVO.setLine16Nov((column[60].toString()));
					}
					if (null != column[61]) {
						original1095ReportDataVO.setLine16Dec((column[61].toString()));
					}

					if (null != column[62]) {
						original1095ReportDataVO.setLine17FirstName((column[62].toString()));
					}
					if (null != column[63]) {
						original1095ReportDataVO.setLine17LastName((column[63].toString()));
					}
					if (null != column[64]) {
						original1095ReportDataVO.setLine17SSN((column[64].toString()));
					}
					if (null != column[65]) {
						original1095ReportDataVO.setLine17DateOfBirth((column[65].toString()));
					}
					if (null != column[66]) {
						original1095ReportDataVO.setLine17AllMonths((column[66].toString()));
					}
					if (null != column[67]) {
						original1095ReportDataVO.setLine17Jan((column[67].toString()));
					}
					if (null != column[68]) {
						original1095ReportDataVO.setLine17Feb((column[68].toString()));
					}
					if (null != column[69]) {
						original1095ReportDataVO.setLine17Mar((column[69].toString()));
					}
					if (null != column[70]) {
						original1095ReportDataVO.setLine17Apr((column[70].toString()));
					}
					if (null != column[71]) {
						original1095ReportDataVO.setLine17May((column[71].toString()));
					}
					if (null != column[72]) {
						original1095ReportDataVO.setLine17June((column[72].toString()));
					}
					if (null != column[73]) {
						original1095ReportDataVO.setLine17July((column[73].toString()));
					}
					if (null != column[74]) {
						original1095ReportDataVO.setLine17Aug((column[74].toString()));
					}
					if (null != column[75]) {
						original1095ReportDataVO.setLine17Sept((column[75].toString()));
					}
					if (null != column[76]) {
						original1095ReportDataVO.setLine17Oct((column[76].toString()));
					}
					if (null != column[77]) {
						original1095ReportDataVO.setLine17Nov((column[77].toString()));
					}
					if (null != column[78]) {
						original1095ReportDataVO.setLine17Dec((column[78].toString()));
					}

					if (null != column[79]) {
						original1095ReportDataVO.setLine18FirstName((column[79].toString()));
					}
					if (null != column[80]) {
						original1095ReportDataVO.setLine18LastName((column[80].toString()));
					}
					if (null != column[81]) {
						original1095ReportDataVO.setLine18SSN((column[81].toString()));
					}
					if (null != column[82]) {
						original1095ReportDataVO.setLine18DateOfBirth((column[82].toString()));
					}
					if (null != column[83]) {
						original1095ReportDataVO.setLine18AllMonths((column[83].toString()));
					}
					if (null != column[84]) {
						original1095ReportDataVO.setLine18Jan((column[84].toString()));
					}
					if (null != column[85]) {
						original1095ReportDataVO.setLine18Feb((column[85].toString()));
					}
					if (null != column[86]) {
						original1095ReportDataVO.setLine18Mar((column[86].toString()));
					}
					if (null != column[87]) {
						original1095ReportDataVO.setLine18Apr((column[87].toString()));
					}
					if (null != column[88]) {
						original1095ReportDataVO.setLine18May((column[88].toString()));
					}
					if (null != column[89]) {
						original1095ReportDataVO.setLine18June((column[89].toString()));
					}
					if (null != column[90]) {
						original1095ReportDataVO.setLine18July((column[90].toString()));
					}
					if (null != column[91]) {
						original1095ReportDataVO.setLine18Aug((column[91].toString()));
					}
					if (null != column[92]) {
						original1095ReportDataVO.setLine18Sept((column[92].toString()));
					}
					if (null != column[93]) {
						original1095ReportDataVO.setLine18Oct((column[93].toString()));
					}
					if (null != column[94]) {
						original1095ReportDataVO.setLine18Nov((column[94].toString()));
					}
					if (null != column[95]) {
						original1095ReportDataVO.setLine18Dec((column[95].toString()));
					}

					if (null != column[96]) {
						original1095ReportDataVO.setLine19FirstName((column[96].toString()));
					}
					if (null != column[97]) {
						original1095ReportDataVO.setLine19LastName((column[97].toString()));
					}
					if (null != column[98]) {
						original1095ReportDataVO.setLine19SSN((column[98].toString()));
					}
					if (null != column[99]) {
						original1095ReportDataVO.setLine19DateOfBirth((column[99].toString()));
					}
					if (null != column[100]) {
						original1095ReportDataVO.setLine19AllMonths((column[100].toString()));
					}
					if (null != column[101]) {
						original1095ReportDataVO.setLine19Jan((column[101].toString()));
					}
					if (null != column[102]) {
						original1095ReportDataVO.setLine19Feb((column[102].toString()));
					}
					if (null != column[103]) {
						original1095ReportDataVO.setLine19Mar((column[103].toString()));
					}
					if (null != column[104]) {
						original1095ReportDataVO.setLine19Apr((column[104].toString()));
					}
					if (null != column[105]) {
						original1095ReportDataVO.setLine19May((column[105].toString()));
					}
					if (null != column[106]) {
						original1095ReportDataVO.setLine19June((column[106].toString()));
					}
					if (null != column[107]) {
						original1095ReportDataVO.setLine19July((column[107].toString()));
					}
					if (null != column[108]) {
						original1095ReportDataVO.setLine19Aug((column[108].toString()));
					}
					if (null != column[109]) {
						original1095ReportDataVO.setLine19Sept((column[109].toString()));
					}
					if (null != column[110]) {
						original1095ReportDataVO.setLine19Oct((column[110].toString()));
					}
					if (null != column[111]) {
						original1095ReportDataVO.setLine19Nov((column[111].toString()));
					}
					if (null != column[112]) {
						original1095ReportDataVO.setLine19Dec((column[112].toString()));
					}

					if (null != column[113]) {
						original1095ReportDataVO.setLine20FirstName((column[113].toString()));
					}
					if (null != column[114]) {
						original1095ReportDataVO.setLine20LastName((column[114].toString()));
					}
					if (null != column[115]) {
						original1095ReportDataVO.setLine20SSN((column[115].toString()));
					}
					if (null != column[116]) {
						original1095ReportDataVO.setLine20DateOfBirth((column[116].toString()));
					}
					if (null != column[117]) {
						original1095ReportDataVO.setLine20AllMonths((column[117].toString()));
					}
					if (null != column[118]) {
						original1095ReportDataVO.setLine20Jan((column[118].toString()));
					}
					if (null != column[119]) {
						original1095ReportDataVO.setLine20Feb((column[119].toString()));
					}
					if (null != column[120]) {
						original1095ReportDataVO.setLine20Mar((column[120].toString()));
					}
					if (null != column[121]) {
						original1095ReportDataVO.setLine20Apr((column[121].toString()));
					}
					if (null != column[122]) {
						original1095ReportDataVO.setLine20May((column[122].toString()));
					}
					if (null != column[123]) {
						original1095ReportDataVO.setLine20June((column[123].toString()));
					}
					if (null != column[124]) {
						original1095ReportDataVO.setLine20July((column[124].toString()));
					}
					if (null != column[125]) {
						original1095ReportDataVO.setLine20Aug((column[125].toString()));
					}
					if (null != column[126]) {
						original1095ReportDataVO.setLine20Sept((column[126].toString()));
					}
					if (null != column[127]) {
						original1095ReportDataVO.setLine20Oct((column[127].toString()));
					}
					if (null != column[128]) {
						original1095ReportDataVO.setLine20Nov((column[128].toString()));
					}
					if (null != column[129]) {
						original1095ReportDataVO.setLine20Dec((column[129].toString()));
					}

					if (null != column[130]) {
						original1095ReportDataVO.setLine21FirstName((column[130].toString()));
					}
					if (null != column[131]) {
						original1095ReportDataVO.setLine21LastName((column[131].toString()));
					}
					if (null != column[132]) {
						original1095ReportDataVO.setLine21SSN((column[132].toString()));
					}
					if (null != column[133]) {
						original1095ReportDataVO.setLine21DateOfBirth((column[133].toString()));
					}
					if (null != column[134]) {
						original1095ReportDataVO.setLine21AllMonths((column[134].toString()));
					}
					if (null != column[135]) {
						original1095ReportDataVO.setLine21Jan((column[135].toString()));
					}
					if (null != column[136]) {
						original1095ReportDataVO.setLine21Feb((column[136].toString()));
					}
					if (null != column[137]) {
						original1095ReportDataVO.setLine21Mar((column[137].toString()));
					}
					if (null != column[138]) {
						original1095ReportDataVO.setLine21Apr((column[138].toString()));
					}
					if (null != column[139]) {
						original1095ReportDataVO.setLine21May((column[139].toString()));
					}
					if (null != column[140]) {
						original1095ReportDataVO.setLine21June((column[140].toString()));
					}
					if (null != column[141]) {
						original1095ReportDataVO.setLine21July((column[141].toString()));
					}
					if (null != column[142]) {
						original1095ReportDataVO.setLine21Aug((column[142].toString()));
					}
					if (null != column[143]) {
						original1095ReportDataVO.setLine21Sept((column[143].toString()));
					}
					if (null != column[144]) {
						original1095ReportDataVO.setLine21Oct((column[144].toString()));
					}
					if (null != column[145]) {
						original1095ReportDataVO.setLine21Nov((column[145].toString()));
					}
					if (null != column[146]) {
						original1095ReportDataVO.setLine21Dec((column[146].toString()));
					}

					if (null != column[147]) {
						original1095ReportDataVO.setLine22FirstName((column[147].toString()));
					}
					if (null != column[148]) {
						original1095ReportDataVO.setLine22LastName((column[148].toString()));
					}
					if (null != column[149]) {
						original1095ReportDataVO.setLine22SSN((column[149].toString()));
					}
					if (null != column[150]) {
						original1095ReportDataVO.setLine22DateOfBirth((column[150].toString()));
					}
					if (null != column[151]) {
						original1095ReportDataVO.setLine22AllMonths((column[151].toString()));
					}
					if (null != column[152]) {
						original1095ReportDataVO.setLine22Jan((column[152].toString()));
					}
					if (null != column[153]) {
						original1095ReportDataVO.setLine22Feb((column[153].toString()));
					}
					if (null != column[154]) {
						original1095ReportDataVO.setLine22Mar((column[154].toString()));
					}
					if (null != column[155]) {
						original1095ReportDataVO.setLine22Apr((column[155].toString()));
					}
					if (null != column[156]) {
						original1095ReportDataVO.setLine22May((column[156].toString()));
					}
					if (null != column[157]) {
						original1095ReportDataVO.setLine22June((column[157].toString()));
					}
					if (null != column[158]) {
						original1095ReportDataVO.setLine22July((column[158].toString()));
					}
					if (null != column[159]) {
						original1095ReportDataVO.setLine22Aug((column[159].toString()));
					}
					if (null != column[160]) {
						original1095ReportDataVO.setLine22Sept((column[160].toString()));
					}
					if (null != column[161]) {
						original1095ReportDataVO.setLine22Oct((column[161].toString()));
					}
					if (null != column[162]) {
						original1095ReportDataVO.setLine22Nov((column[162].toString()));
					}
					if (null != column[163]) {
						original1095ReportDataVO.setLine22Dec((column[163].toString()));
					}

					listVO.add(original1095ReportDataVO);

				}
			}
			
		} catch(Exception e) {
			logger.error("Error while fetching getOriginal1095ReportData : " + e.getMessage());
		}
		
		if (logger.isDebugEnabled()) {
			logger.debug(
					"END :: Original1095ReportDaoImpl : getOriginal1095ReportData : Method to getOriginal1095ReportData");
		}
		return listVO;
	}
	
	
}
