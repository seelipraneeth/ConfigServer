package com.reporting.webapi.response.vo;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;

public class DataAcaPayrollServiceReportDataVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@XmlElement(name = "ssn")
	private String ssn;
	
	@XmlElement(name = "firstName")
	private String firstName;
	
	@XmlElement(name = "lastName")
	private String lastName;
	
	@XmlElement(name = "address")
	private String address;
	
	@XmlElement(name = "city")
	private String city;
	
	@XmlElement(name = "state")
	private String state;
	
	@XmlElement(name = "birthDate")
	private String birthDate;
	
	@XmlElement(name = "firstWorkedDate")
	private String firstWorkedDate;
	
	@XmlElement(name = "lastWorkedDate")
	private String lastWorkedDate;
	
	@XmlElement(name = "terminationDate")
	private String terminationDate;
	
	@XmlElement(name = "periodEndingDate")
	private String periodEndingDate;
	
	@XmlElement(name = "hoursWorked")
	private String hoursWorked;
	
	@XmlElement(name = "union")
	private String union;
	
	@XmlElement(name = "employmentStatus")
	private String employmentStatus;

	@XmlElement(name = "controlGroup")
	private String controlGroup;
	
	public String getSsn() {
		return ssn;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}

	public String getFirstWorkedDate() {
		return firstWorkedDate;
	}

	public void setFirstWorkedDate(String firstWorkedDate) {
		this.firstWorkedDate = firstWorkedDate;
	}

	public String getLastWorkedDate() {
		return lastWorkedDate;
	}

	public void setLastWorkedDate(String lastWorkedDate) {
		this.lastWorkedDate = lastWorkedDate;
	}

	public String getTerminationDate() {
		return terminationDate;
	}

	public void setTerminationDate(String terminationDate) {
		this.terminationDate = terminationDate;
	}

	public String getPeriodEndingDate() {
		return periodEndingDate;
	}

	public void setPeriodEndingDate(String periodEndingDate) {
		this.periodEndingDate = periodEndingDate;
	}

	public String getHoursWorked() {
		return hoursWorked;
	}

	public void setHoursWorked(String hoursWorked) {
		this.hoursWorked = hoursWorked;
	}

	public String getUnion() {
		return union;
	}

	public void setUnion(String union) {
		this.union = union;
	}

	public String getEmploymentStatus() {
		return employmentStatus;
	}

	public void setEmploymentStatus(String employmentStatus) {
		this.employmentStatus = employmentStatus;
	}

	public String getControlGroup() {
		return controlGroup;
	}

	public void setControlGroup(String controlGroup) {
		this.controlGroup = controlGroup;
	}
	
	
}
