package com.reporting.webapi.adapter.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.reporting.webapi.adapter.IAcaDataSetServiceAdapter;
import com.reporting.webapi.bean.AcaDataSetReferenceData;
import com.reporting.webapi.dao.IAcaDataSetServiceDao;
import com.reporting.webapi.response.vo.AcaDataSetServiceDataCountVO;
import com.reporting.webapi.response.vo.AcaDataSetServiceReportDataVO;

@Service
public class AcaDataSetServiceAdapterImpl implements IAcaDataSetServiceAdapter{

	private final Logger logger = Logger.getLogger(AcaDataSetServiceAdapterImpl.class);
	
	@Autowired
	private IAcaDataSetServiceDao acaDataSetServiceDao;
	
	@Override
	public AcaDataSetReferenceData getAcaDataSetServiceReferenceData() {
		if (logger.isDebugEnabled()) {
			logger.debug(
					"START :: AcaDataSetServiceAdapterImpl : getAcaDataSetServiceReferenceData : Method to getAcaDataSetServiceReferenceData");
		}
		AcaDataSetReferenceData acaDataSetReferenceData = acaDataSetServiceDao.getAcaDataSetServiceReferenceData();
		if (logger.isDebugEnabled()) {
			logger.debug(
					"END :: AcaDataSetServiceAdapterImpl : getAcaDataSetServiceReferenceData : Method to getAcaDataSetServiceReferenceData");
		}
		return acaDataSetReferenceData;
	}

	@Override
	public List<AcaDataSetServiceDataCountVO> getAcaDataSetServiceDataCount(String controlGroup, String employerName,
			String sourceCode, String employeeName, String hoursPaid) {
		if (logger.isDebugEnabled()) {
			logger.debug(
					"START :: AcaDataSetServiceAdapterImpl : getAcaDataSetServiceDataCount : Method to getAcaDataSetServiceDataCount");
		}
		List<AcaDataSetServiceDataCountVO> acaDataSetServiceDataCount = acaDataSetServiceDao
				.getAcaDataSetServiceDataCount(controlGroup, employerName, sourceCode, employeeName, hoursPaid);
		if (logger.isDebugEnabled()) {
			logger.debug(
					"END :: AcaDataSetServiceAdapterImpl : getAcaDataSetServiceDataCount : Method to getAcaDataSetServiceDataCount");
		}
		return acaDataSetServiceDataCount;
	}

	@Override
	public List<AcaDataSetServiceReportDataVO> getAcaDataSetServiceReportData(String controlGroup, String employerName,
			String sourceCode, String employeeName, String hoursPaid) {
		if (logger.isDebugEnabled()) {
			logger.debug(
					"START :: AcaDataSetServiceAdapterImpl : getAcaDataSetServiceReportData : Method to getAcaDataSetServiceReportData");
		}
		List<AcaDataSetServiceReportDataVO> acaDataSetServiceReportData = acaDataSetServiceDao
				.getAcaDataSetServiceReportData(controlGroup, employerName, sourceCode, employeeName, hoursPaid);
		if (logger.isDebugEnabled()) {
			logger.debug(
					"END :: AcaDataSetServiceAdapterImpl : getAcaDataSetServiceReportData : Method to getAcaDataSetServiceReportData");
		}
		return acaDataSetServiceReportData;
	}

}
