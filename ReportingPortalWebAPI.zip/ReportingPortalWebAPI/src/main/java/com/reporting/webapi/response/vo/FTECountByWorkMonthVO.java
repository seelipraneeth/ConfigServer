package com.reporting.webapi.response.vo;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;

public class FTECountByWorkMonthVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@XmlElement(name = "workMonth")
	private String workMonth;
	
	@XmlElement(name = "fullTimeCount")
	private String fullTimeCount;
	
	@XmlElement(name = "partTimeCount")
	private String partTimeCount;

	public String getWorkMonth() {
		return workMonth;
	}

	public void setWorkMonth(String workMonth) {
		this.workMonth = workMonth;
	}

	public String getFullTimeCount() {
		return fullTimeCount;
	}

	public void setFullTimeCount(String fullTimeCount) {
		this.fullTimeCount = fullTimeCount;
	}

	public String getPartTimeCount() {
		return partTimeCount;
	}

	public void setPartTimeCount(String partTimeCount) {
		this.partTimeCount = partTimeCount;
	}
	
	

}
