package com.reporting.webapi.uploadexcel.builder;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.reporting.webapi.response.vo.EligibilityReportDataVO;
import com.reporting.webapi.response.vo.InsuranceReportDataVO;
import com.reporting.webapi.util.CommonUtil;
import com.reporting.webapi.util.FolderZipUtil;


@Component
public class InsuranceReportExcelBuilder {

	private final Logger logger = Logger.getLogger(InsuranceReportExcelBuilder.class);

	@Autowired
	private CommonUtil commonUtil;
	
	@Autowired
	private FolderZipUtil folderZipUtil;
	
	public String processExcelContent(Map<String, List<InsuranceReportDataVO>> reportsMapByControlGroup, String[] argParams) throws UnsupportedEncodingException {
		
		XSSFWorkbook workbook = null;
		XSSFSheet sheet = null;
		XSSFCellStyle style = null;
		Set<String> keySetValues = reportsMapByControlGroup.keySet();
		
		String forderNameTimeStampString = new SimpleDateFormat("yyyyMMddHHmmsss").format(new Date());
		String path = this.getClass().getClassLoader().getResource("").getPath();
		String fullPath = URLDecoder.decode(path, "UTF-8");
		
		String pathArr[] = fullPath.split("/WEB-INF/classes/");
		String reportsPath = pathArr[0]+"/reportsData/LegalEntitiesReports/"+forderNameTimeStampString;
		
		File reportsDirectory = new File(reportsPath);
		if(!reportsDirectory.exists()){
			try{
				reportsDirectory.mkdirs();
			} 
			catch(SecurityException se){
				logger.error(" processExcelContent :: Error while creating the required Directory : ", se);
			}      
		}
		
		for(String reportMapKey : keySetValues) {

			// Retrieving the ReportList specific to the ControlGroup matching reportMapKey
			List<InsuranceReportDataVO> reportsList = reportsMapByControlGroup.get(reportMapKey);

			// Set the Control Group Name to controlGroup param in argParams
			argParams[1] = reportMapKey;

			// Initializing workbook, sheet and style
			// initialize work book
			workbook = new XSSFWorkbook();

			// initialize sheet
			sheet = workbook.createSheet("Sheet1");

			sheet.setDefaultColumnWidth(30);

			XSSFCellStyle headerCellStyle = workbook.createCellStyle();
			XSSFFont boldFont = workbook.createFont();
			boldFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
			headerCellStyle.setFont(boldFont);

			style = workbook.createCellStyle();
			XSSFFont font = workbook.createFont();

			font.setFontName("Arial");
			style.setFillForegroundColor(IndexedColors.BLUE.getIndex());
			style.setFillPattern(CellStyle.SOLID_FOREGROUND);
			font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
			font.setColor(IndexedColors.WHITE.getIndex());
			style.setFont(font);

			logger.info(" processExcelContent :: 'workbook', 'sheet' and 'style' have been initialized ");	
		
		Row header = sheet.createRow(0);
        header.createCell(0).setCellValue("Control Group");
        header.getCell(0).setCellStyle(style);
        header.createCell(1).setCellValue("Tax Year");
        header.getCell(1).setCellStyle(style);
        header.createCell(2).setCellValue("SSN");
        header.getCell(2).setCellStyle(style);
        header.createCell(3).setCellValue("Plan Provides Mec");
        header.getCell(3).setCellStyle(style);
        header.createCell(4).setCellValue("Plan Provides Min Value");
        header.getCell(4).setCellStyle(style);
        header.createCell(5).setCellValue("Plan Eligible Persons");
        header.getCell(5).setCellStyle(style);
        header.createCell(6).setCellValue("Plan Self Insured");
        header.getCell(6).setCellStyle(style);
        header.createCell(7).setCellValue("Lowest Cost Self Only Premium");
        header.getCell(7).setCellStyle(style);
        header.createCell(8).setCellValue("Benefit Coverage Start Date");
        header.getCell(8).setCellStyle(style);
        header.createCell(9).setCellValue("Benefit Coverage Change Effective Date");
        header.getCell(9).setCellStyle(style);
        header.createCell(10).setCellValue("Benefit Coverage End Date");
        header.getCell(10).setCellStyle(style);
        header.createCell(11).setCellValue("Affordability Safe Harbor");
        header.getCell(11).setCellStyle(style);        
        header.createCell(12).setCellValue("Benefit Coverage Enrolled Declined");
        header.getCell(12).setCellStyle(style);
        header.createCell(13).setCellValue("Eligibility Period Start Date");
        header.getCell(13).setCellStyle(style);
        header.createCell(14).setCellValue("Cobra Enrollment");
        header.getCell(14).setCellStyle(style);
        header.createCell(15).setCellValue("Non Employee");
        header.getCell(15).setCellStyle(style);
        header.createCell(16).setCellValue("Plan Year Start Date");
        header.getCell(16).setCellStyle(style);
        
       
        header.createCell(17).setCellValue("Plan Year End Date");
        header.getCell(17).setCellStyle(style);
        header.createCell(18).setCellValue("Non Employee First Name");
        header.getCell(18).setCellStyle(style);
        header.createCell(19).setCellValue("Non Employee Last Name");
        header.getCell(19).setCellStyle(style);
        header.createCell(20).setCellValue("Non Employee Address One");
        header.getCell(20).setCellStyle(style);
        header.createCell(21).setCellValue("Non Employee Address Two");
        header.getCell(21).setCellStyle(style);
        header.createCell(22).setCellValue("Non Employee City");
        header.getCell(22).setCellStyle(style);
        header.createCell(23).setCellValue("Non Employee State");
        header.getCell(23).setCellStyle(style);
        header.createCell(24).setCellValue("Non Employee Zip");
        header.getCell(24).setCellStyle(style);
        header.createCell(25).setCellValue("Non Employee Country Code");
        header.getCell(25).setCellStyle(style);
        header.createCell(26).setCellValue("Non Employee Employer EIN");
        header.getCell(26).setCellStyle(style);
        
        
        int rowCount = 1;
        for(Object reportObj : reportsList) {
        	InsuranceReportDataVO reportRowBean = (InsuranceReportDataVO)reportObj;
        	
        	Row newRow = sheet.createRow(rowCount++);
        		
        	newRow.createCell(0).setCellValue(reportRowBean.getControlGroup());
        	newRow.createCell(1).setCellValue(reportRowBean.getTaxYear());
        	newRow.createCell(2).setCellValue(reportRowBean.getSSN());
        	newRow.createCell(3).setCellValue(reportRowBean.getPlanProvidesMec());
        	newRow.createCell(4).setCellValue(reportRowBean.getPlanProvidesMinValue());
        	newRow.createCell(5).setCellValue(reportRowBean.getPlanEligiblePersons());
        	newRow.createCell(6).setCellValue(reportRowBean.getPlanSelfInsured());
        	newRow.createCell(7).setCellValue(reportRowBean.getLowestCostSelfOnlyPremium());
        	newRow.createCell(8).setCellValue(reportRowBean.getBenefitCoverageStartDate());
        	newRow.createCell(9).setCellValue(reportRowBean.getBenefitCoverageChangeEffectiveDate());
        	newRow.createCell(10).setCellValue(reportRowBean.getBenefitCoverageEndDate());
        	newRow.createCell(11).setCellValue(reportRowBean.getAffordabilitySafeHarbor());
        	newRow.createCell(12).setCellValue(reportRowBean.getBenefitCoverageEnrolledDeclined());
        	newRow.createCell(13).setCellValue(reportRowBean.getEligibilityPeriodStartDate());
        	newRow.createCell(14).setCellValue(reportRowBean.getCobraEnrollment());
        	newRow.createCell(15).setCellValue(reportRowBean.getNonEmployee());
        	
        	newRow.createCell(16).setCellValue(reportRowBean.getPlanYearStartDate());
        	newRow.createCell(17).setCellValue(reportRowBean.getPlanYearEndDate());
        	newRow.createCell(18).setCellValue(reportRowBean.getNonEmployeeFirstName());
        	newRow.createCell(19).setCellValue(reportRowBean.getNonEmployeeLastName());
        	
        	newRow.createCell(20).setCellValue(reportRowBean.getNonEmployeeAddress1());
        	newRow.createCell(21).setCellValue(reportRowBean.getNonEmployeeAddress2());
        	newRow.createCell(22).setCellValue(reportRowBean.getNonEmployeeCity());
        	newRow.createCell(23).setCellValue(reportRowBean.getNonEmployeeState());
        	newRow.createCell(24).setCellValue(reportRowBean.getNonEmployeeZip());
        	newRow.createCell(25).setCellValue(reportRowBean.getNonEmployeeCountryCode());
        	newRow.createCell(26).setCellValue(reportRowBean.getNonEmployeeEmployerEIN());
     
        }
        
		try{
        	String fileName = commonUtil.buildUploadExcelFileName(argParams);
        	System.out.println("FileName Built with aegument params : " + fileName);
        	logger.info("InsuranceReportExcelBuilder :: FileName Built with aegument params : " + fileName);
        	
        	FileOutputStream outputStream = new FileOutputStream(reportsPath+"/"+fileName);
        	
        	workbook.write(outputStream);
            workbook.close();
            
        } catch(FileNotFoundException fe) {
        	logger.error(" InsuranceReportExcelBuilder :: Error while Building the Excel Report file : ", fe);
        } catch(Exception e) {
        	logger.error(" InsuranceReportExcelBuilder :: Error while Building the Excel Report file : ", e);
        	}finally {
	        	workbook = null;
	        	sheet = null;
	        	style = null;
	        }
		
		}
		
		// Process ZIP the generated reports - with the Directory Name generated for Reports
				List<String> fileList = new ArrayList<String>(); 
				String sourceFolderPath = pathArr[0]+"/reportsData/LegalEntitiesReports/"+forderNameTimeStampString;
				String outputZipFileName = sourceFolderPath + ".zip";
						
				fileList = commonUtil.generateFileList(reportsDirectory, fileList, sourceFolderPath);
				folderZipUtil.zipIt(outputZipFileName, sourceFolderPath, fileList,forderNameTimeStampString);
				
				return reportsPath;
	}
	
	public Map<String, List<InsuranceReportDataVO>> processReportsMapByControlGroup(List<?> reportsList, List<String> controlGroupList) {
		Map<String, List<InsuranceReportDataVO>> reportsMapByControlGroup = new HashMap<String, List<InsuranceReportDataVO>>();
		for(String controlGroupName : controlGroupList) {
			List<InsuranceReportDataVO> reportList = new ArrayList<InsuranceReportDataVO>();
			for(Object objRef : reportsList) {
				InsuranceReportDataVO nhnftReportObj = (InsuranceReportDataVO)objRef;
				if(controlGroupName.equalsIgnoreCase(nhnftReportObj.getControlGroup())) {
					reportList.add(nhnftReportObj);
				}
			}
			reportsMapByControlGroup.put(controlGroupName, reportList);
		}
		return reportsMapByControlGroup;
	}
}
