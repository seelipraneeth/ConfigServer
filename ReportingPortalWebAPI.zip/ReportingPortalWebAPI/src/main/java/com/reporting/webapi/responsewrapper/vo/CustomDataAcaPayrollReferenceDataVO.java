package com.reporting.webapi.responsewrapper.vo;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.reporting.webapi.response.vo.DataAcaPayrollReferenceDataVO;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class CustomDataAcaPayrollReferenceDataVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private DataAcaPayrollReferenceDataVO dataAcaPayrollReferenceData;

	public DataAcaPayrollReferenceDataVO getDataAcaPayrollReferenceData() {
		return dataAcaPayrollReferenceData;
	}

	public void setDataAcaPayrollReferenceData(DataAcaPayrollReferenceDataVO dataAcaPayrollReferenceData) {
		this.dataAcaPayrollReferenceData = dataAcaPayrollReferenceData;
	}
	
	
}
