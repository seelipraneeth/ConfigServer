package com.reporting.webapi.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import com.reporting.webapi.bean.AcaDataSetReferenceData;
import com.reporting.webapi.dao.IAcaDataSetServiceDao;
import com.reporting.webapi.response.vo.AcaDataSetServiceDataCountVO;
import com.reporting.webapi.response.vo.AcaDataSetServiceReportDataVO;

@Repository
public class AcaDataSetServiceDaoImpl implements IAcaDataSetServiceDao{

	private final Logger logger = Logger.getLogger(AcaDataSetServiceDaoImpl.class);
	
	@Resource(name = "sessionFactory")
	private SessionFactory sessionFactory;
	
	@SuppressWarnings("unchecked")
	@Override
	public AcaDataSetReferenceData getAcaDataSetServiceReferenceData() {
		if (logger.isDebugEnabled()) {
			logger.debug(
					"START :: AcaDataSetServiceDaoImpl : getAcaDataSetServiceReferenceData : Method to getAcaDataSetServiceReferenceData");
		}
		Session session = sessionFactory.openSession();
		AcaDataSetReferenceData acaDataSetReferenceData = new AcaDataSetReferenceData();
		
		try {
			Query controlGroupQuery = session.getNamedQuery("PRC_AcaDataSet_GetControlGroup");
			acaDataSetReferenceData.setControlGroupList(controlGroupQuery.list());
			
			Query employerNameQuery = session.getNamedQuery("PRC_AcaDataSet_GetEmployerName");
			acaDataSetReferenceData.setEmployerNameList(employerNameQuery.list());
			
			Query sourceCodeQuery = session.getNamedQuery("PRC_AcaDataSet_GetSourceCode");
			acaDataSetReferenceData.setSourceCodeList(sourceCodeQuery.list());
		} catch(Exception e) {
			logger.error("Error while fetching data getAcaDataSetServiceReferenceData : " + e.getMessage());
		}
		if (logger.isDebugEnabled()) {
			logger.debug(
					"END :: AcaDataSetServiceDaoImpl : getAcaDataSetServiceReferenceData : Method to getAcaDataSetServiceReferenceData");
		}
		return acaDataSetReferenceData;
	}

	@Override
	public List<AcaDataSetServiceDataCountVO> getAcaDataSetServiceDataCount(String controlGroup, String employerName,
			String sourceCode, String employeeName, String hoursPaid) {
		if (logger.isDebugEnabled()) {
			logger.debug(
					"START :: AcaDataSetServiceDaoImpl : getAcaDataSetServiceDataCount : Method to getAcaDataSetServiceDataCount");
		}
		Session session = sessionFactory.openSession();
		List<AcaDataSetServiceDataCountVO> listVO = null;
		List<AcaDataSetServiceDataCountVO> list = null;
		AcaDataSetServiceDataCountVO acaDataSetServiceDataCountVO = null;
		try {
			Query query = session.getNamedQuery("PRC_AcaDataSet_DataCount");
			query.setParameter("controlGroup", controlGroup);
			query.setParameter("employerName", employerName);
			query.setParameter("sourceCode", sourceCode);
			query.setParameter("employeeName", employeeName);
			query.setParameter("hoursPaid", hoursPaid);
			list = query.list();

			if (list != null && list.size() > 0) {
				listVO = new ArrayList<AcaDataSetServiceDataCountVO>();
				for (Object acaDataSetServiceDataCount : list) {
					acaDataSetServiceDataCountVO = new AcaDataSetServiceDataCountVO();
					if (null != acaDataSetServiceDataCount) {
						acaDataSetServiceDataCountVO.setAcaDataSetCount(acaDataSetServiceDataCount.toString());
					}
					listVO.add(acaDataSetServiceDataCountVO);
				}
			}
		}catch(Exception e) {
			logger.error("Error while fetching data getAcaDataSetServiceDataCount : " + e.getMessage());
		}
		if (logger.isDebugEnabled()) {
			logger.debug(
					"END :: AcaDataSetServiceDaoImpl : getAcaDataSetServiceDataCount : Method to getAcaDataSetServiceDataCount");
		}
		return listVO;
	}

	@Override
	public List<AcaDataSetServiceReportDataVO> getAcaDataSetServiceReportData(String controlGroup, String employerName,
			String sourceCode, String employeeName, String hoursPaid) {
		if (logger.isDebugEnabled()) {
			logger.debug(
					"START :: AcaDataSetServiceDaoImpl : getAcaDataSetServiceReportData : Method to getAcaDataSetServiceReportData");
		}
		Session session = sessionFactory.openSession();
		List<AcaDataSetServiceReportDataVO> listVO = null;
		List<AcaDataSetServiceReportDataVO> list = null;
		AcaDataSetServiceReportDataVO acaDataSetServiceReportDataVO = null;
		try {
			Query query = session.getNamedQuery("PRC_AcaDataSet_ReportData");
			query.setParameter("controlGroup", controlGroup);
			query.setParameter("employerName", employerName);
			query.setParameter("sourceCode", sourceCode);
			query.setParameter("employeeName", employeeName);
			query.setParameter("hoursPaid", hoursPaid);
			list = query.list();
			
			if (list != null && list.size() > 0) {
				listVO = new ArrayList<>();
				for(Object obj : list) {
					
					acaDataSetServiceReportDataVO = new AcaDataSetServiceReportDataVO();
					
					Object[] column = (Object[]) obj;
					
					if (null != column[0]) {
						acaDataSetServiceReportDataVO.setControlGroupName((column[0].toString()));
					}
					if (null != column[1]) {
						acaDataSetServiceReportDataVO.setEmployerName((column[1].toString()));
					}
					if (null != column[2]) {
						acaDataSetServiceReportDataVO.setEmployerFederalTaxID((column[2].toString()));
					}
					if (null != column[3]) {
						acaDataSetServiceReportDataVO.setSsn((column[3].toString()));
					}
					if (null != column[4]) {
						acaDataSetServiceReportDataVO.setEmployeeFirstName((column[4].toString()));
						acaDataSetServiceReportDataVO.setEmployeeName((column[4].toString()) + " ");
					}
					if (null != column[5]) {
						acaDataSetServiceReportDataVO.setEmployeeLastName((column[5].toString()));
						if(StringUtils.isNotBlank(acaDataSetServiceReportDataVO.getEmployeeName())){
							acaDataSetServiceReportDataVO.setEmployeeName(acaDataSetServiceReportDataVO.getEmployeeName() + (column[5].toString()));
						}else{
							acaDataSetServiceReportDataVO.setEmployeeName((column[5].toString()));
						}
					}
					if (null != column[6]) {
						acaDataSetServiceReportDataVO.setSourceCode((column[6].toString()));
					}
					if (null != column[7]) {
						acaDataSetServiceReportDataVO.setHoursPaid((column[7].toString()));
					}
					if (null != column[8]) {
						acaDataSetServiceReportDataVO.setFirstPayPeriodStartDate((column[8].toString()));
					}
					if (null != column[9]) {
						acaDataSetServiceReportDataVO.setEmploymentStatus((column[9].toString()));
					}
					if (null != column[10]) {
						acaDataSetServiceReportDataVO.setAcaEmploymentStatus((column[10].toString()));
					}
					if (null != column[11]) {
						acaDataSetServiceReportDataVO.setBenefitsEnrollmentStatus((column[11].toString()));
					}
					if (null != column[12]) {
						acaDataSetServiceReportDataVO.setUnionStatus((column[12].toString()));
					}
					if (null != column[13]) {
						acaDataSetServiceReportDataVO.setHrsFilename((column[13].toString()));
					}
					if (null != column[14]) {
						acaDataSetServiceReportDataVO.setInsFilename((column[14].toString()));
					}
					
					listVO.add(acaDataSetServiceReportDataVO);
				}
			}
			
		} catch(Exception e) {
			
		}
		if (logger.isDebugEnabled()) {
			logger.debug(
					"END :: AcaDataSetServiceDaoImpl : getAcaDataSetServiceReportData : Method to getAcaDataSetServiceReportData");
		}
		return listVO;
	}

}
