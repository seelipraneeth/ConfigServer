package com.reporting.webapi.responsewrapper.vo;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.reporting.webapi.response.vo.LegalEntitiesReferanceDataVO;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class CustomLegalEntitiesReferenceDataVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private LegalEntitiesReferanceDataVO legalEntitiesReferanceData;

	public LegalEntitiesReferanceDataVO getLegalEntitiesReferanceData() {
		return legalEntitiesReferanceData;
	}

	public void setLegalEntitiesReferanceData(LegalEntitiesReferanceDataVO legalEntitiesReferanceData) {
		this.legalEntitiesReferanceData = legalEntitiesReferanceData;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	

	
	
	

}
