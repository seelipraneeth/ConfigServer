


package com.reporting.webapi.dao;

import java.util.List;

import com.reporting.webapi.bean.InsuranceServiceReferanceDataBean;
import com.reporting.webapi.response.vo.InsuranceReportDataVO;

public interface IInsuranceReportDao {
	public InsuranceServiceReferanceDataBean getInsuranceServiceReferenceData()throws Exception;
	public List<InsuranceReportDataVO> getInsuranceReportData(String taxYear,String controlGroup) throws Exception;
}
