package com.reporting.webapi.response.vo;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "LegalEntitiesReferanceData")
public class LegalEntitiesReferanceDataVO implements Serializable {

	@XmlElementWrapper(name = "TaxYear")
	@XmlElement(name = "TaxYear")
	private List<String> taxYear;

	@XmlElementWrapper(name = "ControlGroup")
	@XmlElement(name = "ControlGroup")
	private List<String> controlGroup;

	
	public List<String> getControlGroup() {
		return controlGroup;
	}

	public void setControlGroup(List<String> controlGroup) {
		this.controlGroup = controlGroup;
	}

	public List<String> getTaxYear() {
		return taxYear;
	}

	public void setTaxYear(List<String> taxYear) {
		this.taxYear = taxYear;
	}
	
	
}
