package com.reporting.webapi.response.vo;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "measurementDate")
public class MeasurementDateByControlGroupVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@XmlElement
	private List<String> measurementStartDatesByControlGroupList;
	
	@XmlElement
	private List<String> measurementEndDatesByControlGroupList;

	public List<String> getMeasurementStartDatesByControlGroupList() {
		return measurementStartDatesByControlGroupList;
	}

	public void setMeasurementStartDatesByControlGroupList(List<String> measurementStartDatesByControlGroupList) {
		this.measurementStartDatesByControlGroupList = measurementStartDatesByControlGroupList;
	}

	public List<String> getMeasurementEndDatesByControlGroupList() {
		return measurementEndDatesByControlGroupList;
	}

	public void setMeasurementEndDatesByControlGroupList(List<String> measurementEndDatesByControlGroupList) {
		this.measurementEndDatesByControlGroupList = measurementEndDatesByControlGroupList;
	}

	
	
	
}
