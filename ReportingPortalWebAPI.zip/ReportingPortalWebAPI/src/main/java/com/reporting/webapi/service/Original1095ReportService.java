package com.reporting.webapi.service;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.reporting.webapi.adapter.IOriginal1095ReportAdapter;
import com.reporting.webapi.bean.Original1095ReportReferenceData;
import com.reporting.webapi.response.vo.Original1095ReportDataVO;
import com.reporting.webapi.response.vo.Original1095ReportReferenceDataVO;
import com.reporting.webapi.responsewrapper.vo.CustomOriginal1095ReportReferenceDataVO;
import com.reporting.webapi.responsewrapper.vo.CustomtOriginal1095ReportDataVO;
import com.reporting.webapi.util.CommonConstants;
import com.reporting.webapi.util.ReportsExcelBuilderUtil;

@Component
@Path(value=CommonConstants.ORIGINAL_1095_SERVICE)
public class Original1095ReportService {

	private final Logger logger = Logger.getLogger(Original1095ReportService.class);
	
	@Autowired
	private IOriginal1095ReportAdapter original1095ReportAdapter;
	
	@Autowired
	private ReportsExcelBuilderUtil reportsExcelBuilderUtil;
	
	@Path(CommonConstants.ORIGINAL_1095_REFERENCE_DATA)
	@GET
	@Produces( { MediaType.APPLICATION_JSON})
	public Response getOriginal1095ReportReferenceData() {
		
		if(logger.isDebugEnabled()){
			logger.debug("START :: Original1095ReportService : getOriginal1095ReportReferenceData : Method to getOriginal1095ReportReferenceData");
		}
		
		CustomOriginal1095ReportReferenceDataVO customOriginal1095ReportReferenceDataVO = new CustomOriginal1095ReportReferenceDataVO();
		try{
			Original1095ReportReferenceData original1095ReportReferenceData = original1095ReportAdapter.getOriginal1095ReportReferenceData();
			
			Original1095ReportReferenceDataVO original1095ReportReferenceDataVO =  new Original1095ReportReferenceDataVO();
			original1095ReportReferenceDataVO.setControlgroups(original1095ReportReferenceData.getControlGroupList());
			original1095ReportReferenceDataVO.setTaxYears(original1095ReportReferenceData.getTaxYearList());
			
			customOriginal1095ReportReferenceDataVO.setOriginal1095ReportReferenceDataVO(original1095ReportReferenceDataVO);
			
		} catch (Exception e) {
			logger.error("Error while invoking getOriginal1095ReportReferenceData : " + e.getMessage());
		}	
		if(logger.isDebugEnabled()){
			logger.debug("END :: Original1095ReportService : getOriginal1095ReportReferenceData : Method to getOriginal1095ReportReferenceData");
		}
		
		return Response.ok(customOriginal1095ReportReferenceDataVO).build();
	}
	
	@Path(CommonConstants.ORIGINAL_1095_REPORT_DATA)
	@GET
	@Produces( { MediaType.APPLICATION_JSON})
	public Response getOriginal1095ReportData(@QueryParam(CommonConstants.CONTROL_GROUP) String controlGroup, @QueryParam(CommonConstants.TAX_YEAR) String taxYear) {
		
		if(logger.isDebugEnabled()){
			logger.debug("START :: Original1095ReportService : getOriginal1095ReportData : Method to getOriginal1095ReportData");
		}
		
		CustomtOriginal1095ReportDataVO customtOriginal1095ReportDataVO = new CustomtOriginal1095ReportDataVO();
		List<Original1095ReportDataVO> original1095ReportData = null;
		
		try {
			
			if(null != controlGroup && controlGroup.contains("''") &&  controlGroup.length() == 2) {
				controlGroup = null;
			}
			if(null != taxYear && taxYear.contains("''") && taxYear.length() == 2) {
				taxYear = null;
			}
			
			original1095ReportData = original1095ReportAdapter.getOriginal1095ReportData(controlGroup, taxYear);
			customtOriginal1095ReportDataVO.setOriginal1095ReportData(original1095ReportData);
			
		} catch(Exception e) {
			logger.error("Error while invoking getOriginal1095ReportData : " + e.getMessage());
		}
		
		if(logger.isDebugEnabled()){
			logger.debug("END :: Original1095ReportService : getOriginal1095ReportData : Method to getOriginal1095ReportData");
		}
		
		return Response.ok(customtOriginal1095ReportDataVO).build();
	}
	
	@Path(CommonConstants.ORIGINAL_1095_EXCEL_ZIP_DOWNLOAD)
	@GET
	@Produces(CommonConstants.APPLICATION_ZIP)
	public Response processOriginal1095ReportExcelUpload(@QueryParam(CommonConstants.CONTROL_GROUP) String controlGroup, @QueryParam(CommonConstants.TAX_YEAR) String taxYear) {
		
		if(logger.isDebugEnabled()){
			logger.debug("START :: Original1095ReportService : processOriginal1095ReportExcelUpload : Method to processOriginal1095ReportExcelUpload");
		}
		
		List<Original1095ReportDataVO> original1095ReportData = null;
		String generatedReportsPath = "";
		
		try {
			
			if(null != controlGroup && controlGroup.contains("''") &&  controlGroup.length() == 2) {
				controlGroup = null;
			}
			if(null != taxYear && taxYear.contains("''") && taxYear.length() == 2) {
				taxYear = null;
			}
			
			original1095ReportData = original1095ReportAdapter.getOriginal1095ReportData(controlGroup, taxYear);
			
			// Code To Invoke Excel Builder 
			Map<String, List<?>> reportsDataMap = new HashMap<>();
			reportsDataMap.put(CommonConstants.ORIGINAL_1095_REPORT, original1095ReportData);
			
			Original1095ReportReferenceData original1095ReportReferenceData = original1095ReportAdapter.getOriginal1095ReportReferenceData();
			List<String> controlGroupList = original1095ReportReferenceData.getControlGroupList();
			
			generatedReportsPath = reportsExcelBuilderUtil.buildExcelDocument(reportsDataMap, controlGroupList, controlGroup, taxYear);
			
		} catch(Exception e) {
			logger.error("Error while invoking processOriginal1095ReportExcelUpload : " + e.getMessage());
		}
		
		if(logger.isDebugEnabled()){
			logger.debug("END :: Original1095ReportService : processOriginal1095ReportExcelUpload : Method to processOriginal1095ReportExcelUpload");
		}
		
		File downloadDocumentFile = new File(generatedReportsPath + ".zip");
		String buildZipFilename = "Original1095Reports_" + generatedReportsPath.substring(generatedReportsPath.lastIndexOf("/")+1, generatedReportsPath.length()) + ".zip";
		ResponseBuilder responseBuilder = Response.ok((Object) downloadDocumentFile);
        responseBuilder.header("Content-Disposition", "attachment; filename=" + buildZipFilename );
		return responseBuilder.build();
	}
}
