package com.reporting.webapi.response.vo;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "acaDataSetServiceDataCountVO")
public class AcaDataSetServiceDataCountVO implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@XmlElement(name = "acaDataSetCount")
	private String acaDataSetCount;

	public String getAcaDataSetCount() {
		return acaDataSetCount;
	}

	public void setAcaDataSetCount(String acaDataSetCount) {
		this.acaDataSetCount = acaDataSetCount;
	}

}
