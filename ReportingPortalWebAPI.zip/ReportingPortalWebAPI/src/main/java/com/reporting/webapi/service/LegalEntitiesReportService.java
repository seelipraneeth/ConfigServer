package com.reporting.webapi.service;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.reporting.webapi.adapter.ILegalEntitiesReportAdapter;
import com.reporting.webapi.bean.EligibilityServiceReferanceDataBean;
import com.reporting.webapi.bean.LegalEntitiesServiceReferanceDataBean;
import com.reporting.webapi.response.vo.LegalEntitiesReferanceDataVO;
import com.reporting.webapi.response.vo.LegalEntitiesReportDataVO;
import com.reporting.webapi.responsewrapper.vo.CustomLegalEntitiesReferenceDataVO;
import com.reporting.webapi.responsewrapper.vo.CustomLegalEntitiesReportVO;
import com.reporting.webapi.util.CommonConstants;
import com.reporting.webapi.util.ReportsExcelBuilderUtil;

@Component
@Path(value=CommonConstants.LEGAL_ENTITIES_SERVICE)
public class LegalEntitiesReportService {
	
	private final Logger logger = Logger.getLogger(LegalEntitiesReportService.class);
	
	@Autowired
	private ILegalEntitiesReportAdapter legalEntitiesReportAdapter;
	
	@Autowired
	private ReportsExcelBuilderUtil reportsExcelBuilderUtil;
	
	@Path(CommonConstants.LEGAL_ENTITIES_SERVICE_REFERENCE_DATA)
	@GET
	@Produces( { MediaType.APPLICATION_JSON})
	public Response getLegalEntitiesServiceReferenceData() {
		
		if(logger.isDebugEnabled()){
			logger.debug("START :: LegalEntitiesReportService : getLegalEntitiesServiceReferenceData : Method to getLegalEntitiesServiceReferenceData");
		}
		
		CustomLegalEntitiesReferenceDataVO customLegalEntitiesReferenceDataVO = new CustomLegalEntitiesReferenceDataVO();
		try{
			LegalEntitiesServiceReferanceDataBean legalEntitiesServiceReferanceDataBean = legalEntitiesReportAdapter.getLegalEntitiesServiceReferenceData();
			
			LegalEntitiesReferanceDataVO legalEntitiesReferanceDataVO =  new LegalEntitiesReferanceDataVO();
			legalEntitiesReferanceDataVO.setTaxYear(legalEntitiesServiceReferanceDataBean.getTaxYearList());
			legalEntitiesReferanceDataVO.setControlGroup(legalEntitiesServiceReferanceDataBean.getControlGroupList());
						
			customLegalEntitiesReferenceDataVO.setLegalEntitiesReferanceData(legalEntitiesReferanceDataVO);
			
		} catch (Exception e) {
			logger.error("Error while invoking getEligibilityServiceReferenceData : " + e.getMessage());
		}	
		if(logger.isDebugEnabled()){
			logger.debug("END :: EligibilityReportService : getEligibilityServiceReferenceData : Method to getEligibilityServiceReferenceData");
		}
		
		return Response.ok(customLegalEntitiesReferenceDataVO).build();
	}
	
	
	@Path(CommonConstants.LEGAL_ENTITIES_SERVICE_REPORT_DATA)
	@GET
	@Produces( { MediaType.APPLICATION_JSON})
	public Response getLegalEntitiesReportData(@QueryParam(CommonConstants.TAX_YEAR) String taxYear,
			@QueryParam(CommonConstants.CONTROL_GROUP) String controlGroup) {
		
		if(logger.isDebugEnabled()){
			logger.debug("START :: LegalEntitiesReportService : getLegalEntitiesReportData");
		}
		
		CustomLegalEntitiesReportVO customLegalEntitiesReportVO = new CustomLegalEntitiesReportVO();
		try{
			if(null != taxYear && taxYear.contains("''") &&  taxYear.length() == 2) {
				taxYear = null;
			}
			if(null != controlGroup && controlGroup.contains("''") &&  controlGroup.length() == 2) {
				controlGroup = null;
			}
			List<LegalEntitiesReportDataVO> legalEntitiesReportDataVO = legalEntitiesReportAdapter.getLegalEntitiesReportData(taxYear,controlGroup);
			
			customLegalEntitiesReportVO.setLegalEntitiesReportData(legalEntitiesReportDataVO);
			
		} catch (Exception e) {
			logger.error("Error while invoking getLegalEntitiesReportData : " + e.getMessage());
		}
		
		
		if(logger.isDebugEnabled()){
			logger.debug("END :: LegalEntitiesReportService : getLegalEntitiesReportData");
		}
		
		return Response.ok(customLegalEntitiesReportVO).build();
	}
	
	
	@Path(CommonConstants.LEGAL_ENTITIES_SERVICE_PROCESS_EXCEL_ZIP_DOWNLOAD)
	@GET
	@Produces(CommonConstants.APPLICATION_ZIP)
	public Response processBreakInReportExcelUpload(@QueryParam(CommonConstants.TAX_YEAR) String taxYear,
			@QueryParam(CommonConstants.CONTROL_GROUP) String controlGroup) {
		List<LegalEntitiesReportDataVO> legalEntitiesReportDataVO = null;
		String generatedReportsPath = "";
		try{
			if(null != taxYear && taxYear.contains("''") &&  taxYear.length() == 2) {
				taxYear = null;
			}
			if(null != controlGroup && controlGroup.contains("''") &&  controlGroup.length() == 2) {
				controlGroup = null;
			}
			
			legalEntitiesReportDataVO = legalEntitiesReportAdapter.getLegalEntitiesReportData(taxYear,controlGroup);
			
			// Code To Invoke Excel Builder 
			Map<String, List<?>> reportsDataMap = new HashMap<>();
			reportsDataMap.put(CommonConstants.LEGAL_ENTITIES_REPORT, legalEntitiesReportDataVO);
			
			LegalEntitiesServiceReferanceDataBean legalEntitiesServiceReferanceDataBean = legalEntitiesReportAdapter.getLegalEntitiesServiceReferenceData();
			List<String> controlGroupList = legalEntitiesServiceReferanceDataBean.getControlGroupList();
			
			generatedReportsPath = reportsExcelBuilderUtil.buildExcelDocument(reportsDataMap, controlGroupList, taxYear,controlGroup);
						
		} catch (Exception e) {
			//logger.error("Error while invoking getHireWorkYears : " + e.getMessage());
		}
		
		File downloadDocumentFile = new File(generatedReportsPath + ".zip");
		String buildZipFilename = "LegalEntitiesReport_" + generatedReportsPath.substring(generatedReportsPath.lastIndexOf("/")+1, generatedReportsPath.length()) + ".zip";
		ResponseBuilder responseBuilder = Response.ok((Object) downloadDocumentFile);
        responseBuilder.header("Content-Disposition", "attachment; filename=" + buildZipFilename );
		return responseBuilder.build();
	}
	
}
