package com.reporting.webapi.dao.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import com.reporting.webapi.bean.LegalEntitiesServiceReferanceDataBean;
import com.reporting.webapi.dao.ILegalEntitiesReportDao;
import com.reporting.webapi.response.vo.LegalEntitiesReportDataVO;

@Repository
public class LegalEntitiesReportDaoImpl implements ILegalEntitiesReportDao{
	
	private final Logger logger = Logger.getLogger(LegalEntitiesReportDaoImpl.class);

	@Resource(name = "sessionFactory")
	private SessionFactory sessionFactory;
	
	@SuppressWarnings("unchecked")
	@Override
	public LegalEntitiesServiceReferanceDataBean getLegalEntitiesServiceReferenceData() throws Exception {

		if(logger.isDebugEnabled()){
			logger.debug("START :: LegalEntitiesReportDaoImpl : getLegalEntitiesServiceReferenceData ");
		}
		
		Session session = sessionFactory.openSession();
		LegalEntitiesServiceReferanceDataBean legalEntitiesServiceReferanceDataBean = new LegalEntitiesServiceReferanceDataBean();
		
		try{
			Query taxYearQuery = session.getNamedQuery("PRC_LegalEntities_ReferenceData_TaxYear");
			legalEntitiesServiceReferanceDataBean.setTaxYearList(taxYearQuery.list());
			
			Query controlGroupQuery = session.getNamedQuery("PRC_LegalEntities_ReferenceData_ControlGroup");
			legalEntitiesServiceReferanceDataBean.setControlGroupList(controlGroupQuery.list());
			
		}catch(Exception e){
			logger.error("Error while fetching data getLegalEntitiesServiceReferenceData : " + e.getMessage());
		}
		
		if(logger.isDebugEnabled()){
			logger.debug("END :: LegalEntitiesReportDaoImpl : getLegalEntitiesServiceReferenceData ");
		}
		
		return legalEntitiesServiceReferanceDataBean;
	}

	
	@SuppressWarnings({ "unchecked" })
	@Override
	public List<LegalEntitiesReportDataVO> getLegalEntitiesReportData(String taxYear,String controlGroup) throws Exception {
		
		if(logger.isDebugEnabled()){
			logger.debug("START :: LegalEntitiesReportDaoImpl : getLegalEntitiesReportData ");
		}
		
		Session session = sessionFactory.openSession();
		LegalEntitiesReportDataVO legalEntitiesReportDataVO = null;
		List<LegalEntitiesReportDataVO> listVo = null;
		try{
			Query query = session.getNamedQuery("PRC_LegalEntities_ReportData");
			query.setParameter("taxYear",taxYear);
			query.setParameter("controlGroup", controlGroup);
			List<?> list = query.list();
			
			listVo = new ArrayList<LegalEntitiesReportDataVO>();
			if (list != null && list.size() > 0) {
			Iterator<?> iterator = list.iterator();
			while(iterator.hasNext()){
				Object column[] = (Object[])iterator.next();
				legalEntitiesReportDataVO = new LegalEntitiesReportDataVO();
				if (null != column[0]) {
					legalEntitiesReportDataVO.setControlGroup(column[0].toString());
				}
				if (null != column[1]) {
					legalEntitiesReportDataVO.setTaxYear(column[1].toString());
				}
				if (null != column[2]) {
					legalEntitiesReportDataVO.setEmployerEIN(column[2].toString());
				}
				if (null != column[3]) {
					legalEntitiesReportDataVO.setEmployerName(column[3].toString());
				}
				if (null != column[4]) {
					legalEntitiesReportDataVO.setAddressLine1(column[4].toString());
				}
				if (null != column[5]) {
					legalEntitiesReportDataVO.setAddressLine2(column[5].toString());
				}
				if (null != column[6]) {
					legalEntitiesReportDataVO.setCity(column[6].toString());
				}
				if (null != column[7]) {
					legalEntitiesReportDataVO.setState(column[7].toString());
				}
				if (null != column[8]) {
					legalEntitiesReportDataVO.setZipCode(column[8].toString());
				}
				if (null != column[9]) {
					legalEntitiesReportDataVO.setContactFirstName(column[9].toString());
				}
				if (null != column[10]) {
					legalEntitiesReportDataVO.setContactLastName(column[10].toString());
				}
				if (null != column[11]) {
					legalEntitiesReportDataVO.setContactPhone(column[11].toString());
				}
				if (null != column[12]) {
					legalEntitiesReportDataVO.setTransitionRelief(column[12].toString());
				}
				if (null != column[13]) {
					legalEntitiesReportDataVO.setIsAuthoritative(column[13].toString());
				}
				if (null != column[14]) {
					legalEntitiesReportDataVO.setUnionRuleType(column[14].toString());
				}
				if (null != column[15]) {
					legalEntitiesReportDataVO.setNonUnionRuleType(column[15].toString());
				}
				listVo.add(legalEntitiesReportDataVO);
			}
			}else{
				listVo=null;
			}
			
			
		}catch(Exception e){
			logger.error("Error while fetching data getLegalEntitiesReportData : " + e.getMessage());
		}
		
		if(logger.isDebugEnabled()){
			logger.debug("END :: LegalEntitiesReportDaoImpl : getLegalEntitiesReportData ");
		}
		
		return listVo;
	}

}
