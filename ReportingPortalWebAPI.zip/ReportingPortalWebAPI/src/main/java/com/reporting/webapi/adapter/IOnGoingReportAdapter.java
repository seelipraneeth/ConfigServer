package com.reporting.webapi.adapter;

import java.util.List;

import com.reporting.webapi.bean.OngoingReferanceDataBean;
import com.reporting.webapi.response.vo.MeasurementDateByControlGroupVO;
import com.reporting.webapi.response.vo.OnGoingReportsByWeekCountVO;

public interface IOnGoingReportAdapter {

	public OngoingReferanceDataBean getOnGoingReportReferenceData() throws Exception;

	public Integer getOnGoingReportCountByWeek(String measurementStartDate, String measurementEndDate, String avgWeeklyHours,
			String controlGroup, String typeOfHours) throws Exception;

	public List<OnGoingReportsByWeekCountVO> getOnGoingReportData(String measurementStartDate, String measurementEndDate, String avgWeeklyHours, String controlGroup,
			String typeOfHours, String reportOfWeek)throws Exception;
	
	public MeasurementDateByControlGroupVO getOnGoingServiceMeasurementDatesByControlGroup(String controlGroup) throws Exception;

}
