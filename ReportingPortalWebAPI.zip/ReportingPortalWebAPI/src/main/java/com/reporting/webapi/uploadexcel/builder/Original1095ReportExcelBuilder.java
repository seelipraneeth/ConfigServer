package com.reporting.webapi.uploadexcel.builder;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.reporting.webapi.response.vo.Original1095ReportDataVO;
import com.reporting.webapi.util.CommonUtil;
import com.reporting.webapi.util.FolderZipUtil;

@Component
public class Original1095ReportExcelBuilder {

	private final Logger logger = Logger.getLogger(Original1095ReportExcelBuilder.class);

	@Autowired
	private CommonUtil commonUtil;
	
	@Autowired
	private FolderZipUtil folderZipUtil;
	
	public String processExcelContent(Map<String, List<Original1095ReportDataVO>> reportsMapByControlGroup,
			String[] argParams) throws UnsupportedEncodingException {

		XSSFWorkbook workbook = null;
		XSSFSheet sheet = null;
		XSSFCellStyle style = null;
		Set<String> keySetValues = reportsMapByControlGroup.keySet();

		String folderNameTimeStampString = new SimpleDateFormat("yyyyMMddHHmmsss").format(new Date());
		String path = this.getClass().getClassLoader().getResource("").getPath();
		String fullPath = URLDecoder.decode(path, "UTF-8");

		String pathArr[] = fullPath.split("/WEB-INF/classes/");
		String reportsPath = pathArr[0] + "/reportsData/Original1095Reports/" + folderNameTimeStampString;

		File reportsDirectory = new File(reportsPath);
		if (!reportsDirectory.exists()) {
			try {
				reportsDirectory.mkdirs();
			} catch (SecurityException se) {
				logger.error(" processExcelContent :: Error while creating the required Directory : ", se);
			}
		}

		for (String reportMapKey : keySetValues) {

			// Retrieving the ReportList specific to the ControlGroup matching
			// reportMapKey
			List<Original1095ReportDataVO> reportsList = reportsMapByControlGroup.get(reportMapKey);

			// Set the Control Group Name to controlGroup param in argParams
			argParams[0] = reportMapKey;

			// Initializing workbook, sheet and style
			// initialize work book
			workbook = new XSSFWorkbook();

			// initialize sheet
			sheet = workbook.createSheet("Sheet1");

			sheet.setDefaultColumnWidth(30);

			XSSFCellStyle headerCellStyle = workbook.createCellStyle();
			XSSFFont boldFont = workbook.createFont();
			boldFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
			headerCellStyle.setFont(boldFont);

			style = workbook.createCellStyle();
			XSSFFont font = workbook.createFont();

			font.setFontName("Arial");
			style.setFillForegroundColor(IndexedColors.BLUE.getIndex());
			style.setFillPattern(CellStyle.SOLID_FOREGROUND);
			font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
			font.setColor(IndexedColors.WHITE.getIndex());
			style.setFont(font);

			logger.info(" processExcelContent :: 'workbook', 'sheet' and 'style' have been initialized ");

			Row header = sheet.createRow(0);
			header.createCell(0).setCellValue("EmployeeFirstName");
			header.getCell(0).setCellStyle(style);
			header.createCell(1).setCellValue("EmployeeMiddleName");
			header.getCell(1).setCellStyle(style);
			header.createCell(2).setCellValue("EmployeeLastName");
			header.getCell(2).setCellStyle(style);
			header.createCell(3).setCellValue("EmployeeSSN");
			header.getCell(3).setCellStyle(style);
			header.createCell(4).setCellValue("EmployeeStreetAddressLine1");
			header.getCell(4).setCellStyle(style);
			header.createCell(5).setCellValue("EmployeeStreetAddressLine2");
			header.getCell(5).setCellStyle(style);
			header.createCell(6).setCellValue("EmployeeCity");
			header.getCell(6).setCellStyle(style);
			header.createCell(7).setCellValue("EmployeeState");
			header.getCell(7).setCellStyle(style);
			header.createCell(8).setCellValue("EmployeeCountry");
			header.getCell(8).setCellStyle(style);
			header.createCell(9).setCellValue("EmployeeZip");
			header.getCell(9).setCellStyle(style);
			header.createCell(10).setCellValue("EmployerName");
			header.getCell(10).setCellStyle(style);
			header.createCell(11).setCellValue("EmployerFEIN");
			header.getCell(11).setCellStyle(style);
			header.createCell(12).setCellValue("EmployerStreetAddressLine1");
			header.getCell(12).setCellStyle(style);
			header.createCell(13).setCellValue("EmployerStreetAddressLine2");
			header.getCell(13).setCellStyle(style);
			header.createCell(14).setCellValue("EmployerStreetAddressLine3");
			header.getCell(14).setCellStyle(style);
			header.createCell(15).setCellValue("EmployerContactPhone");
			header.getCell(15).setCellStyle(style);
			header.createCell(16).setCellValue("EmployerCity");
			header.getCell(16).setCellStyle(style);
			header.createCell(17).setCellValue("EmployerState");
			header.getCell(17).setCellStyle(style);
			header.createCell(18).setCellValue("EmployerCountry");
			header.getCell(18).setCellStyle(style);
			header.createCell(19).setCellValue("EmployerZip");
			header.getCell(19).setCellStyle(style);
			header.createCell(20).setCellValue("SelfInsuranceCoverage");
			header.getCell(20).setCellStyle(style);
			header.createCell(21).setCellValue("ControlGroup");
			header.getCell(21).setCellStyle(style);
			header.createCell(22).setCellValue("TaxYear");
			header.getCell(22).setCellStyle(style);
			header.createCell(23).setCellValue("Line14AllMonths");
			header.getCell(23).setCellStyle(style);
			header.createCell(24).setCellValue("Line14Jan");
			header.getCell(24).setCellStyle(style);
			header.createCell(25).setCellValue("Line14Feb");
			header.getCell(25).setCellStyle(style);
			header.createCell(26).setCellValue("Line14Mar");
			header.getCell(26).setCellStyle(style);
			header.createCell(27).setCellValue("Line14Apr");
			header.getCell(27).setCellStyle(style);
			header.createCell(28).setCellValue("Line14May");
			header.getCell(28).setCellStyle(style);
			header.createCell(29).setCellValue("Line14June");
			header.getCell(29).setCellStyle(style);
			header.createCell(30).setCellValue("Line14July");
			header.getCell(30).setCellStyle(style);
			header.createCell(31).setCellValue("Line14Aug");
			header.getCell(31).setCellStyle(style);
			header.createCell(32).setCellValue("Line14Sept");
			header.getCell(32).setCellStyle(style);
			header.createCell(33).setCellValue("Line14Oct");
			header.getCell(33).setCellStyle(style);
			header.createCell(34).setCellValue("Line14Nov");
			header.getCell(34).setCellStyle(style);
			header.createCell(35).setCellValue("Line14Dec");
			header.getCell(35).setCellStyle(style);
			header.createCell(36).setCellValue("Line15AllMonths");
			header.getCell(36).setCellStyle(style);
			header.createCell(37).setCellValue("Line15Jan");
			header.getCell(37).setCellStyle(style);
			header.createCell(38).setCellValue("Line15Feb");
			header.getCell(38).setCellStyle(style);
			header.createCell(39).setCellValue("Line15Mar");
			header.getCell(39).setCellStyle(style);
			header.createCell(40).setCellValue("Line15Apr");
			header.getCell(40).setCellStyle(style);
			header.createCell(41).setCellValue("Line15May");
			header.getCell(41).setCellStyle(style);
			header.createCell(42).setCellValue("Line15June");
			header.getCell(42).setCellStyle(style);
			header.createCell(43).setCellValue("Line15July");
			header.getCell(43).setCellStyle(style);
			header.createCell(44).setCellValue("Line15Aug");
			header.getCell(44).setCellStyle(style);
			header.createCell(45).setCellValue("Line15Sept");
			header.getCell(45).setCellStyle(style);
			header.createCell(46).setCellValue("Line15Oct");
			header.getCell(46).setCellStyle(style);
			header.createCell(47).setCellValue("Line15Nov");
			header.getCell(47).setCellStyle(style);
			header.createCell(48).setCellValue("Line15Dec");
			header.getCell(48).setCellStyle(style);
			header.createCell(49).setCellValue("Line16AllMonths");
			header.getCell(49).setCellStyle(style);
			header.createCell(50).setCellValue("Line16Jan");
			header.getCell(50).setCellStyle(style);
			header.createCell(51).setCellValue("Line16Feb");
			header.getCell(51).setCellStyle(style);
			header.createCell(52).setCellValue("Line16Mar");
			header.getCell(52).setCellStyle(style);
			header.createCell(53).setCellValue("Line16Apr");
			header.getCell(53).setCellStyle(style);
			header.createCell(54).setCellValue("Line16May");
			header.getCell(54).setCellStyle(style);
			header.createCell(55).setCellValue("Line16June");
			header.getCell(55).setCellStyle(style);
			header.createCell(56).setCellValue("Line16July");
			header.getCell(56).setCellStyle(style);
			header.createCell(57).setCellValue("Line16Aug");
			header.getCell(57).setCellStyle(style);
			header.createCell(58).setCellValue("Line16Sept");
			header.getCell(58).setCellStyle(style);
			header.createCell(59).setCellValue("Line16Oct");
			header.getCell(59).setCellStyle(style);
			header.createCell(60).setCellValue("Line16Nov");
			header.getCell(60).setCellStyle(style);
			header.createCell(61).setCellValue("Line16Dec");
			header.getCell(61).setCellStyle(style);
			header.createCell(62).setCellValue("Line17FirstName");
			header.getCell(62).setCellStyle(style);
			header.createCell(63).setCellValue("Line17LastName");
			header.getCell(63).setCellStyle(style);
			header.createCell(64).setCellValue("Line17SSN");
			header.getCell(64).setCellStyle(style);
			header.createCell(65).setCellValue("Line17DateOfBirth");
			header.getCell(65).setCellStyle(style);
			header.createCell(66).setCellValue("Line17AllMonths");
			header.getCell(66).setCellStyle(style);
			header.createCell(67).setCellValue("Line17Jan");
			header.getCell(67).setCellStyle(style);
			header.createCell(68).setCellValue("Line17Feb");
			header.getCell(68).setCellStyle(style);
			header.createCell(69).setCellValue("Line17Mar");
			header.getCell(69).setCellStyle(style);
			header.createCell(70).setCellValue("Line17Apr");
			header.getCell(70).setCellStyle(style);
			header.createCell(71).setCellValue("Line17May");
			header.getCell(71).setCellStyle(style);
			header.createCell(72).setCellValue("Line17June");
			header.getCell(72).setCellStyle(style);
			header.createCell(73).setCellValue("Line17July");
			header.getCell(73).setCellStyle(style);
			header.createCell(74).setCellValue("Line17Aug");
			header.getCell(74).setCellStyle(style);
			header.createCell(75).setCellValue("Line17Sept");
			header.getCell(75).setCellStyle(style);
			header.createCell(76).setCellValue("Line17Oct");
			header.getCell(76).setCellStyle(style);
			header.createCell(77).setCellValue("Line17Nov");
			header.getCell(77).setCellStyle(style);
			header.createCell(78).setCellValue("Line17Dec");
			header.getCell(78).setCellStyle(style);
			header.createCell(79).setCellValue("Line18FirstName");
			header.getCell(79).setCellStyle(style);
			header.createCell(80).setCellValue("Line18LastName");
			header.getCell(80).setCellStyle(style);
			header.createCell(81).setCellValue("Line18SSN");
			header.getCell(81).setCellStyle(style);
			header.createCell(82).setCellValue("Line18DateOfBirth");
			header.getCell(82).setCellStyle(style);
			header.createCell(83).setCellValue("Line18AllMonths");
			header.getCell(83).setCellStyle(style);
			header.createCell(84).setCellValue("Line18Jan");
			header.getCell(84).setCellStyle(style);
			header.createCell(85).setCellValue("Line18Feb");
			header.getCell(85).setCellStyle(style);
			header.createCell(86).setCellValue("Line18Mar");
			header.getCell(86).setCellStyle(style);
			header.createCell(87).setCellValue("Line18Apr");
			header.getCell(87).setCellStyle(style);
			header.createCell(88).setCellValue("Line18May");
			header.getCell(88).setCellStyle(style);
			header.createCell(89).setCellValue("Line18June");
			header.getCell(89).setCellStyle(style);
			header.createCell(90).setCellValue("Line18July");
			header.getCell(90).setCellStyle(style);
			header.createCell(91).setCellValue("Line18Aug");
			header.getCell(91).setCellStyle(style);
			header.createCell(92).setCellValue("Line18Sept");
			header.getCell(92).setCellStyle(style);
			header.createCell(93).setCellValue("Line18Oct");
			header.getCell(93).setCellStyle(style);
			header.createCell(94).setCellValue("Line18Nov");
			header.getCell(94).setCellStyle(style);
			header.createCell(95).setCellValue("Line18Dec");
			header.getCell(95).setCellStyle(style);
			header.createCell(96).setCellValue("Line19FirstName");
			header.getCell(96).setCellStyle(style);
			header.createCell(97).setCellValue("Line19LastName");
			header.getCell(97).setCellStyle(style);
			header.createCell(98).setCellValue("Line19SSN");
			header.getCell(98).setCellStyle(style);
			header.createCell(99).setCellValue("Line19DateOfBirth");
			header.getCell(99).setCellStyle(style);
			header.createCell(100).setCellValue("Line19AllMonths");
			header.getCell(100).setCellStyle(style);
			header.createCell(101).setCellValue("Line19Jan");
			header.getCell(101).setCellStyle(style);
			header.createCell(102).setCellValue("Line19Feb");
			header.getCell(102).setCellStyle(style);
			header.createCell(103).setCellValue("Line19Mar");
			header.getCell(103).setCellStyle(style);
			header.createCell(104).setCellValue("Line19Apr");
			header.getCell(104).setCellStyle(style);
			header.createCell(105).setCellValue("Line19May");
			header.getCell(105).setCellStyle(style);
			header.createCell(106).setCellValue("Line19June");
			header.getCell(106).setCellStyle(style);
			header.createCell(107).setCellValue("Line19July");
			header.getCell(107).setCellStyle(style);
			header.createCell(108).setCellValue("Line19Aug");
			header.getCell(108).setCellStyle(style);
			header.createCell(109).setCellValue("Line19Sept");
			header.getCell(109).setCellStyle(style);
			header.createCell(110).setCellValue("Line19Oct");
			header.getCell(110).setCellStyle(style);
			header.createCell(111).setCellValue("Line19Nov");
			header.getCell(111).setCellStyle(style);
			header.createCell(112).setCellValue("Line19Dec");
			header.getCell(112).setCellStyle(style);
			header.createCell(113).setCellValue("Line20FirstName");
			header.getCell(113).setCellStyle(style);
			header.createCell(114).setCellValue("Line20LastName");
			header.getCell(114).setCellStyle(style);
			header.createCell(115).setCellValue("Line20SSN");
			header.getCell(115).setCellStyle(style);
			header.createCell(116).setCellValue("Line20DateOfBirth");
			header.getCell(116).setCellStyle(style);
			header.createCell(117).setCellValue("Line20AllMonths");
			header.getCell(117).setCellStyle(style);
			header.createCell(118).setCellValue("Line20Jan");
			header.getCell(118).setCellStyle(style);
			header.createCell(119).setCellValue("Line20Feb");
			header.getCell(119).setCellStyle(style);
			header.createCell(120).setCellValue("Line20Mar");
			header.getCell(120).setCellStyle(style);
			header.createCell(121).setCellValue("Line20Apr");
			header.getCell(121).setCellStyle(style);
			header.createCell(122).setCellValue("Line20May");
			header.getCell(122).setCellStyle(style);
			header.createCell(123).setCellValue("Line20June");
			header.getCell(123).setCellStyle(style);
			header.createCell(124).setCellValue("Line20July");
			header.getCell(124).setCellStyle(style);
			header.createCell(125).setCellValue("Line20Aug");
			header.getCell(125).setCellStyle(style);
			header.createCell(126).setCellValue("Line20Sept");
			header.getCell(126).setCellStyle(style);
			header.createCell(127).setCellValue("Line20Oct");
			header.getCell(127).setCellStyle(style);
			header.createCell(128).setCellValue("Line20Nov");
			header.getCell(128).setCellStyle(style);
			header.createCell(129).setCellValue("Line20Dec");
			header.getCell(129).setCellStyle(style);
			header.createCell(130).setCellValue("Line21FirstName");
			header.getCell(130).setCellStyle(style);
			header.createCell(131).setCellValue("Line21LastName");
			header.getCell(131).setCellStyle(style);
			header.createCell(132).setCellValue("Line21SSN");
			header.getCell(132).setCellStyle(style);
			header.createCell(133).setCellValue("Line21DateOfBirth");
			header.getCell(133).setCellStyle(style);
			header.createCell(134).setCellValue("Line21AllMonths");
			header.getCell(134).setCellStyle(style);
			header.createCell(135).setCellValue("Line21Jan");
			header.getCell(135).setCellStyle(style);
			header.createCell(136).setCellValue("Line21Feb");
			header.getCell(136).setCellStyle(style);
			header.createCell(137).setCellValue("Line21Mar");
			header.getCell(137).setCellStyle(style);
			header.createCell(138).setCellValue("Line21Apr");
			header.getCell(138).setCellStyle(style);
			header.createCell(139).setCellValue("Line21May");
			header.getCell(139).setCellStyle(style);
			header.createCell(140).setCellValue("Line21June");
			header.getCell(140).setCellStyle(style);
			header.createCell(141).setCellValue("Line21July");
			header.getCell(141).setCellStyle(style);
			header.createCell(142).setCellValue("Line21Aug");
			header.getCell(142).setCellStyle(style);
			header.createCell(143).setCellValue("Line21Sept");
			header.getCell(143).setCellStyle(style);
			header.createCell(144).setCellValue("Line21Oct");
			header.getCell(144).setCellStyle(style);
			header.createCell(145).setCellValue("Line21Nov");
			header.getCell(145).setCellStyle(style);
			header.createCell(146).setCellValue("Line21Dec");
			header.getCell(146).setCellStyle(style);
			header.createCell(147).setCellValue("Line22FirstName");
			header.getCell(147).setCellStyle(style);
			header.createCell(148).setCellValue("Line22LastName");
			header.getCell(148).setCellStyle(style);
			header.createCell(149).setCellValue("Line22SSN");
			header.getCell(149).setCellStyle(style);
			header.createCell(150).setCellValue("Line22DateOfBirth");
			header.getCell(150).setCellStyle(style);
			header.createCell(151).setCellValue("Line22AllMonths");
			header.getCell(151).setCellStyle(style);
			header.createCell(152).setCellValue("Line22Jan");
			header.getCell(152).setCellStyle(style);
			header.createCell(153).setCellValue("Line22Feb");
			header.getCell(153).setCellStyle(style);
			header.createCell(154).setCellValue("Line22Mar");
			header.getCell(154).setCellStyle(style);
			header.createCell(155).setCellValue("Line22Apr");
			header.getCell(155).setCellStyle(style);
			header.createCell(156).setCellValue("Line22May");
			header.getCell(156).setCellStyle(style);
			header.createCell(157).setCellValue("Line22June");
			header.getCell(157).setCellStyle(style);
			header.createCell(158).setCellValue("Line22July");
			header.getCell(158).setCellStyle(style);
			header.createCell(159).setCellValue("Line22Aug");
			header.getCell(159).setCellStyle(style);
			header.createCell(160).setCellValue("Line22Sept");
			header.getCell(160).setCellStyle(style);
			header.createCell(161).setCellValue("Line22Oct");
			header.getCell(161).setCellStyle(style);
			header.createCell(162).setCellValue("Line22Nov");
			header.getCell(162).setCellStyle(style);
			header.createCell(163).setCellValue("Line22Dec");
			header.getCell(163).setCellStyle(style);

			int rowCount = 1;
			for (Object reportObj : reportsList) {
				Original1095ReportDataVO reportRowBean = (Original1095ReportDataVO) reportObj;

				Row newRow = sheet.createRow(rowCount++);

				newRow.createCell(0).setCellValue(reportRowBean.getEmployeeFirstName());
				newRow.createCell(1).setCellValue(reportRowBean.getEmployeeMiddleName());
				newRow.createCell(2).setCellValue(reportRowBean.getEmployeeLastName());
				newRow.createCell(3).setCellValue(reportRowBean.getEmployeeSSN());
				newRow.createCell(4).setCellValue(reportRowBean.getEmployeeAddressLine1());
				newRow.createCell(5).setCellValue(reportRowBean.getEmployeeAddressLine2());
				newRow.createCell(6).setCellValue(reportRowBean.getEmployeeCity());
				newRow.createCell(7).setCellValue(reportRowBean.getEmployeeState());
				newRow.createCell(8).setCellValue(reportRowBean.getEmployeeCountry());
				newRow.createCell(9).setCellValue(reportRowBean.getEmployeeZip());
				newRow.createCell(10).setCellValue(reportRowBean.getEmployerName());
				newRow.createCell(11).setCellValue(reportRowBean.getEmployerFEIN());
				newRow.createCell(12).setCellValue(reportRowBean.getEmployerAddressLine1());
				newRow.createCell(13).setCellValue(reportRowBean.getEmployerAddressLine2());
				newRow.createCell(14).setCellValue(reportRowBean.getEmployerAddressLine3());
				newRow.createCell(15).setCellValue(reportRowBean.getEmployerContactPhone());
				newRow.createCell(16).setCellValue(reportRowBean.getEmployerCity());
				newRow.createCell(17).setCellValue(reportRowBean.getEmployerState());
				newRow.createCell(18).setCellValue(reportRowBean.getEmployerCountry());
				newRow.createCell(19).setCellValue(reportRowBean.getEmployerZip());
				newRow.createCell(20).setCellValue(reportRowBean.getSelfInsuranceCoverage());
				newRow.createCell(21).setCellValue(reportRowBean.getControlGroup());
				newRow.createCell(22).setCellValue(reportRowBean.getTaxYear());
				newRow.createCell(23).setCellValue(reportRowBean.getLine14AllMonths());
				newRow.createCell(24).setCellValue(reportRowBean.getLine14Jan());
				newRow.createCell(25).setCellValue(reportRowBean.getLine14Feb());
				newRow.createCell(26).setCellValue(reportRowBean.getLine14Mar());
				newRow.createCell(27).setCellValue(reportRowBean.getLine14Apr());
				newRow.createCell(28).setCellValue(reportRowBean.getLine14May());
				newRow.createCell(29).setCellValue(reportRowBean.getLine14June());
				newRow.createCell(30).setCellValue(reportRowBean.getLine14July());
				newRow.createCell(31).setCellValue(reportRowBean.getLine14Aug());
				newRow.createCell(32).setCellValue(reportRowBean.getLine14Sept());
				newRow.createCell(33).setCellValue(reportRowBean.getLine14Oct());
				newRow.createCell(34).setCellValue(reportRowBean.getLine14Nov());
				newRow.createCell(35).setCellValue(reportRowBean.getLine14Dec());
				newRow.createCell(36).setCellValue(reportRowBean.getLine15AllMonths());
				newRow.createCell(37).setCellValue(reportRowBean.getLine15Jan());
				newRow.createCell(38).setCellValue(reportRowBean.getLine15Feb());
				newRow.createCell(39).setCellValue(reportRowBean.getLine15Mar());
				newRow.createCell(40).setCellValue(reportRowBean.getLine15Apr());
				newRow.createCell(41).setCellValue(reportRowBean.getLine15May());
				newRow.createCell(42).setCellValue(reportRowBean.getLine15June());
				newRow.createCell(43).setCellValue(reportRowBean.getLine15July());
				newRow.createCell(44).setCellValue(reportRowBean.getLine15Aug());
				newRow.createCell(45).setCellValue(reportRowBean.getLine15Sept());
				newRow.createCell(46).setCellValue(reportRowBean.getLine15Oct());
				newRow.createCell(47).setCellValue(reportRowBean.getLine15Nov());
				newRow.createCell(48).setCellValue(reportRowBean.getLine15Dec());
				newRow.createCell(49).setCellValue(reportRowBean.getLine16AllMonths());
				newRow.createCell(50).setCellValue(reportRowBean.getLine16Jan());
				newRow.createCell(51).setCellValue(reportRowBean.getLine16Feb());
				newRow.createCell(52).setCellValue(reportRowBean.getLine16Mar());
				newRow.createCell(53).setCellValue(reportRowBean.getLine16Apr());
				newRow.createCell(54).setCellValue(reportRowBean.getLine16May());
				newRow.createCell(55).setCellValue(reportRowBean.getLine16June());
				newRow.createCell(56).setCellValue(reportRowBean.getLine16July());
				newRow.createCell(57).setCellValue(reportRowBean.getLine16Aug());
				newRow.createCell(58).setCellValue(reportRowBean.getLine16Sept());
				newRow.createCell(59).setCellValue(reportRowBean.getLine16Oct());
				newRow.createCell(60).setCellValue(reportRowBean.getLine16Nov());
				newRow.createCell(61).setCellValue(reportRowBean.getLine16Dec());
				newRow.createCell(62).setCellValue(reportRowBean.getLine17FirstName());
				newRow.createCell(63).setCellValue(reportRowBean.getLine17LastName());
				newRow.createCell(64).setCellValue(reportRowBean.getLine17SSN());
				newRow.createCell(65).setCellValue(reportRowBean.getLine17DateOfBirth());
				newRow.createCell(66).setCellValue(reportRowBean.getLine17AllMonths());
				newRow.createCell(67).setCellValue(reportRowBean.getLine17Jan());
				newRow.createCell(68).setCellValue(reportRowBean.getLine17Feb());
				newRow.createCell(69).setCellValue(reportRowBean.getLine17Mar());
				newRow.createCell(70).setCellValue(reportRowBean.getLine17Apr());
				newRow.createCell(71).setCellValue(reportRowBean.getLine17May());
				newRow.createCell(72).setCellValue(reportRowBean.getLine17June());
				newRow.createCell(73).setCellValue(reportRowBean.getLine17July());
				newRow.createCell(74).setCellValue(reportRowBean.getLine17Aug());
				newRow.createCell(75).setCellValue(reportRowBean.getLine17Sept());
				newRow.createCell(76).setCellValue(reportRowBean.getLine17Oct());
				newRow.createCell(77).setCellValue(reportRowBean.getLine17Nov());
				newRow.createCell(78).setCellValue(reportRowBean.getLine17Dec());
				newRow.createCell(79).setCellValue(reportRowBean.getLine18FirstName());
				newRow.createCell(80).setCellValue(reportRowBean.getLine18LastName());
				newRow.createCell(81).setCellValue(reportRowBean.getLine18SSN());
				newRow.createCell(82).setCellValue(reportRowBean.getLine18DateOfBirth());
				newRow.createCell(83).setCellValue(reportRowBean.getLine18AllMonths());
				newRow.createCell(84).setCellValue(reportRowBean.getLine18Jan());
				newRow.createCell(85).setCellValue(reportRowBean.getLine18Feb());
				newRow.createCell(86).setCellValue(reportRowBean.getLine18Mar());
				newRow.createCell(87).setCellValue(reportRowBean.getLine18Apr());
				newRow.createCell(88).setCellValue(reportRowBean.getLine18May());
				newRow.createCell(89).setCellValue(reportRowBean.getLine18June());
				newRow.createCell(90).setCellValue(reportRowBean.getLine18July());
				newRow.createCell(91).setCellValue(reportRowBean.getLine18Aug());
				newRow.createCell(92).setCellValue(reportRowBean.getLine18Sept());
				newRow.createCell(93).setCellValue(reportRowBean.getLine18Oct());
				newRow.createCell(94).setCellValue(reportRowBean.getLine18Nov());
				newRow.createCell(95).setCellValue(reportRowBean.getLine18Dec());
				newRow.createCell(96).setCellValue(reportRowBean.getLine19FirstName());
				newRow.createCell(97).setCellValue(reportRowBean.getLine19LastName());
				newRow.createCell(98).setCellValue(reportRowBean.getLine19SSN());
				newRow.createCell(99).setCellValue(reportRowBean.getLine19DateOfBirth());
				newRow.createCell(100).setCellValue(reportRowBean.getLine19AllMonths());
				newRow.createCell(101).setCellValue(reportRowBean.getLine19Jan());
				newRow.createCell(102).setCellValue(reportRowBean.getLine19Feb());
				newRow.createCell(103).setCellValue(reportRowBean.getLine19Mar());
				newRow.createCell(104).setCellValue(reportRowBean.getLine19Apr());
				newRow.createCell(105).setCellValue(reportRowBean.getLine19May());
				newRow.createCell(106).setCellValue(reportRowBean.getLine19June());
				newRow.createCell(107).setCellValue(reportRowBean.getLine19July());
				newRow.createCell(108).setCellValue(reportRowBean.getLine19Aug());
				newRow.createCell(109).setCellValue(reportRowBean.getLine19Sept());
				newRow.createCell(110).setCellValue(reportRowBean.getLine19Oct());
				newRow.createCell(111).setCellValue(reportRowBean.getLine19Nov());
				newRow.createCell(112).setCellValue(reportRowBean.getLine19Dec());
				newRow.createCell(113).setCellValue(reportRowBean.getLine20FirstName());
				newRow.createCell(114).setCellValue(reportRowBean.getLine20LastName());
				newRow.createCell(115).setCellValue(reportRowBean.getLine20SSN());
				newRow.createCell(116).setCellValue(reportRowBean.getLine20DateOfBirth());
				newRow.createCell(117).setCellValue(reportRowBean.getLine20AllMonths());
				newRow.createCell(118).setCellValue(reportRowBean.getLine20Jan());
				newRow.createCell(119).setCellValue(reportRowBean.getLine20Feb());
				newRow.createCell(120).setCellValue(reportRowBean.getLine20Mar());
				newRow.createCell(121).setCellValue(reportRowBean.getLine20Apr());
				newRow.createCell(122).setCellValue(reportRowBean.getLine20May());
				newRow.createCell(123).setCellValue(reportRowBean.getLine20June());
				newRow.createCell(124).setCellValue(reportRowBean.getLine20July());
				newRow.createCell(125).setCellValue(reportRowBean.getLine20Aug());
				newRow.createCell(126).setCellValue(reportRowBean.getLine20Sept());
				newRow.createCell(127).setCellValue(reportRowBean.getLine20Oct());
				newRow.createCell(128).setCellValue(reportRowBean.getLine20Nov());
				newRow.createCell(129).setCellValue(reportRowBean.getLine20Dec());
				newRow.createCell(130).setCellValue(reportRowBean.getLine21FirstName());
				newRow.createCell(131).setCellValue(reportRowBean.getLine21LastName());
				newRow.createCell(132).setCellValue(reportRowBean.getLine21SSN());
				newRow.createCell(133).setCellValue(reportRowBean.getLine21DateOfBirth());
				newRow.createCell(134).setCellValue(reportRowBean.getLine21AllMonths());
				newRow.createCell(135).setCellValue(reportRowBean.getLine21Jan());
				newRow.createCell(136).setCellValue(reportRowBean.getLine21Feb());
				newRow.createCell(137).setCellValue(reportRowBean.getLine21Mar());
				newRow.createCell(138).setCellValue(reportRowBean.getLine21Apr());
				newRow.createCell(139).setCellValue(reportRowBean.getLine21May());
				newRow.createCell(140).setCellValue(reportRowBean.getLine21June());
				newRow.createCell(141).setCellValue(reportRowBean.getLine21July());
				newRow.createCell(142).setCellValue(reportRowBean.getLine21Aug());
				newRow.createCell(143).setCellValue(reportRowBean.getLine21Sept());
				newRow.createCell(144).setCellValue(reportRowBean.getLine21Oct());
				newRow.createCell(145).setCellValue(reportRowBean.getLine21Nov());
				newRow.createCell(146).setCellValue(reportRowBean.getLine21Dec());
				newRow.createCell(147).setCellValue(reportRowBean.getLine22FirstName());
				newRow.createCell(148).setCellValue(reportRowBean.getLine22LastName());
				newRow.createCell(149).setCellValue(reportRowBean.getLine22SSN());
				newRow.createCell(150).setCellValue(reportRowBean.getLine22DateOfBirth());
				newRow.createCell(151).setCellValue(reportRowBean.getLine22AllMonths());
				newRow.createCell(152).setCellValue(reportRowBean.getLine22Jan());
				newRow.createCell(153).setCellValue(reportRowBean.getLine22Feb());
				newRow.createCell(154).setCellValue(reportRowBean.getLine22Mar());
				newRow.createCell(155).setCellValue(reportRowBean.getLine22Apr());
				newRow.createCell(156).setCellValue(reportRowBean.getLine22May());
				newRow.createCell(157).setCellValue(reportRowBean.getLine22June());
				newRow.createCell(158).setCellValue(reportRowBean.getLine22July());
				newRow.createCell(159).setCellValue(reportRowBean.getLine22Aug());
				newRow.createCell(160).setCellValue(reportRowBean.getLine22Sept());
				newRow.createCell(161).setCellValue(reportRowBean.getLine22Oct());
				newRow.createCell(162).setCellValue(reportRowBean.getLine22Nov());
				newRow.createCell(163).setCellValue(reportRowBean.getLine22Dec());

			}

			try {
				String fileName = commonUtil.buildUploadExcelFileName(argParams);
				System.out.println("FileName Built with argument params : " + fileName);
				logger.info("Original1095ReportExcelBuilder :: FileName Built with argument params : " + fileName);

				FileOutputStream outputStream = new FileOutputStream(reportsPath + "/" + fileName);

				workbook.write(outputStream);
				workbook.close();

			} catch (FileNotFoundException fe) {
				logger.error(" Original1095ReportExcelBuilder :: Error while Building the Excel Report file : ", fe);
			} catch (Exception e) {
				logger.error(" Original1095ReportExcelBuilder :: Error while Building the Excel Report file : ", e);
			} finally {
				workbook = null;
				sheet = null;
				style = null;
			}
		}

		// Process ZIP the generated reports - with the Directory Name generated
		// for Reports
		List<String> fileList = new ArrayList<String>();
		String sourceFolderPath = pathArr[0] + "/reportsData/Original1095Reports/" + folderNameTimeStampString;
		String outputZipFileName = sourceFolderPath + ".zip";

		fileList = commonUtil.generateFileList(reportsDirectory, fileList, sourceFolderPath);
		folderZipUtil.zipIt(outputZipFileName, sourceFolderPath, fileList, folderNameTimeStampString);

		return reportsPath;
	}
	
	public Map<String, List<Original1095ReportDataVO>> processReportsMapByControlGroup(List<?> reportsList, List<String> controlGroupList) {
		Map<String, List<Original1095ReportDataVO>> reportsMapByControlGroup = new HashMap<String, List<Original1095ReportDataVO>>();
		for(String controlGroupName : controlGroupList) {
			List<Original1095ReportDataVO> reportList = new ArrayList<Original1095ReportDataVO>();
			for(Object objRef : reportsList) {
				Original1095ReportDataVO original1095ReportObj = (Original1095ReportDataVO)objRef;
				if(controlGroupName.equalsIgnoreCase(original1095ReportObj.getControlGroup())) {
					reportList.add(original1095ReportObj);
				}
			}
			reportsMapByControlGroup.put(controlGroupName, reportList);
		}
		return reportsMapByControlGroup;
	}
}
