package com.reporting.webapi.responsewrapper.vo;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.reporting.webapi.response.vo.OnGoingCountVO;

@XmlRootElement(name = "customOnGoingCountByWeeks")
@XmlAccessorType(XmlAccessType.FIELD)
public class CustomOnGoingCountByWeeksVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private OnGoingCountVO ongoingCountVO;

	public OnGoingCountVO getOngoingCountVO() {
		return ongoingCountVO;
	}

	public void setOngoingCountVO(OnGoingCountVO ongoingCountVO) {
		this.ongoingCountVO = ongoingCountVO;
	}
	
	
}
