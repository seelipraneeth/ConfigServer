package com.reporting.webapi.responsewrapper.vo;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.reporting.webapi.response.vo.OnGoingReportDataVO;

@XmlRootElement(name = "customOnGoingReportsByWeeksCount")
@XmlAccessorType(XmlAccessType.FIELD)
public class CustomOnGoingReportsByWeeksCountVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private OnGoingReportDataVO onGoingReportDataVO;

	public OnGoingReportDataVO getOnGoingReportDataVO() {
		return onGoingReportDataVO;
	}

	public void setOnGoingReportDataVO(OnGoingReportDataVO onGoingReportDataVO) {
		this.onGoingReportDataVO = onGoingReportDataVO;
	}
	
	
}
