package com.reporting.webapi.response.vo;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "InsuranceReportData")
public class InsuranceReportDataVO implements Serializable {

	@XmlElementWrapper(name = "TaxYear")
	@XmlElement(name = "TaxYear")
	private String taxYear;
	
	public String getTaxYear() {
		return taxYear;
	}

	public void setTaxYear(String taxYear) {
		this.taxYear = taxYear;
	}
	
	@XmlElementWrapper(name = "ControlGroup")
	@XmlElement(name = "ControlGroup")
	private String controlGroup;

	
	public String getControlGroup() {
		return controlGroup;
	}

	public void setControlGroup(String controlGroup) {
		this.controlGroup = controlGroup;
	}


	@XmlElementWrapper(name = "SSN")
	@XmlElement(name = "SSN")
	private String sSN;

	
	public String getSSN() {
		return sSN;
	}

	public void setSSN(String sSN) {
		this.sSN = sSN;
	}

	@XmlElementWrapper(name = "PlanProvidesMec")
	@XmlElement(name = "PlanProvidesMec")
	private String planProvidesMec;

	
	public String getPlanProvidesMec() {
		return planProvidesMec;
	}

	public void setPlanProvidesMec(String planProvidesMec) {
		this.planProvidesMec = planProvidesMec;
	}
	

	@XmlElementWrapper(name = "PlanProvidesMinValue")
	@XmlElement(name = "PlanProvidesMinValue")
	private String planProvidesMinValue;

	
	public String getPlanProvidesMinValue() {
		return planProvidesMinValue;
	}

	public void setPlanProvidesMinValue(String planProvidesMinValue) {
		this.planProvidesMinValue = planProvidesMinValue;
	}
	


	@XmlElementWrapper(name = "PlanEligiblePersons")
	@XmlElement(name = "PlanEligiblePersons")
	private String planEligiblePersons;

	
	public String getPlanEligiblePersons() {
		return planEligiblePersons;
	}

	public void setPlanEligiblePersons(String planEligiblePersons) {
		this.planEligiblePersons = planEligiblePersons;
	}

	
	@XmlElementWrapper(name = "PlanSelfInsured")
	@XmlElement(name = "PlanSelfInsured")
	private String planSelfInsured;

	
	public String getPlanSelfInsured() {
		return planSelfInsured;
	}

	public void setPlanSelfInsured(String planSelfInsured) {
		this.planSelfInsured = planSelfInsured;
	}


	@XmlElementWrapper(name = "LowestCostSelfOnlyPremium")
	@XmlElement(name = "LowestCostSelfOnlyPremium")
	private String lowestCostSelfOnlyPremium;

	
	public String getLowestCostSelfOnlyPremium() {
		return lowestCostSelfOnlyPremium;
	}

	public void setLowestCostSelfOnlyPremium(String lowestCostSelfOnlyPremium) {
		this.lowestCostSelfOnlyPremium = lowestCostSelfOnlyPremium;
	}

	@XmlElementWrapper(name = "BenefitCoverageStartDate")
	@XmlElement(name = "BenefitCoverageStartDate")
	private String benefitCoverageStartDate;

	
	public String getBenefitCoverageStartDate() {
		return benefitCoverageStartDate;
	}

	public void setBenefitCoverageStartDate(String benefitCoverageStartDate) {
		this.benefitCoverageStartDate = benefitCoverageStartDate;
	}
	


	@XmlElementWrapper(name = "BenefitCoverageChangeEffectiveDate")
	@XmlElement(name = "BenefitCoverageChangeEffectiveDate")
	private String benefitCoverageChangeEffectiveDate;

	
	public String getBenefitCoverageChangeEffectiveDate() {
		return benefitCoverageChangeEffectiveDate;
	}

	public void setBenefitCoverageChangeEffectiveDate(String benefitCoverageChangeEffectiveDate) {
		this.benefitCoverageChangeEffectiveDate = benefitCoverageChangeEffectiveDate;
	}
	

	@XmlElementWrapper(name = "BenefitCoverageEndDate")
	@XmlElement(name = "BenefitCoverageEndDate")
	private String benefitCoverageEndDate;

	
	public String getBenefitCoverageEndDate() {
		return benefitCoverageEndDate;
	}

	public void setBenefitCoverageEndDate(String benefitCoverageEndDate) {
		this.benefitCoverageEndDate = benefitCoverageEndDate;
	}

	@XmlElementWrapper(name = "AffordabilitySafeHarbor")
	@XmlElement(name = "AffordabilitySafeHarbor")
	private String affordabilitySafeHarbor;

	
	public String getAffordabilitySafeHarbor() {
		return affordabilitySafeHarbor;
	}

	public void setAffordabilitySafeHarbor(String affordabilitySafeHarbor) {
		this.affordabilitySafeHarbor = affordabilitySafeHarbor;
	}

	@XmlElementWrapper(name = "BenefitCoverageEnrolledDeclined")
	@XmlElement(name = "BenefitCoverageEnrolledDeclined")
	private String benefitCoverageEnrolledDeclined;

	
	public String getBenefitCoverageEnrolledDeclined() {
		return benefitCoverageEnrolledDeclined;
	}

	public void setBenefitCoverageEnrolledDeclined(String benefitCoverageEnrolledDeclined) {
		this.benefitCoverageEnrolledDeclined = benefitCoverageEnrolledDeclined;
	}


	@XmlElementWrapper(name = "EligibilityPeriodStartDate")
	@XmlElement(name = "EligibilityPeriodStartDate")
	private String eligibilityPeriodStartDate;

	
	public String getEligibilityPeriodStartDate() {
		return eligibilityPeriodStartDate;
	}

	public void setEligibilityPeriodStartDate(String eligibilityPeriodStartDate) {
		this.eligibilityPeriodStartDate = eligibilityPeriodStartDate;
	}
	

	@XmlElementWrapper(name = "CobraEnrollment")
	@XmlElement(name = "CobraEnrollment")
	private String cobraEnrollment;

	
	public String getCobraEnrollment() {
		return cobraEnrollment;
	}

	public void setCobraEnrollment(String cobraEnrollment) {
		this.cobraEnrollment = cobraEnrollment;
	}
	

	@XmlElementWrapper(name = "NonEmployee")
	@XmlElement(name = "NonEmployee")
	private String nonEmployee;

	
	public String getNonEmployee() {
		return nonEmployee;
	}

	public void setNonEmployee(String nonEmployee) {
		this.nonEmployee = nonEmployee;
	}
	

	@XmlElementWrapper(name = "PlanYearStartDate")
	@XmlElement(name = "PlanYearStartDate")
	private String planYearStartDate;

	
	public String getPlanYearStartDate() {
		return planYearStartDate;
	}

	public void setPlanYearStartDate(String planYearStartDate) {
		this.planYearStartDate = planYearStartDate;
	}
	
	@XmlElementWrapper(name = "PlanYearEndDate")
	@XmlElement(name = "PlanYearEndDate")
	private String planYearEndDate;

	
	public String getPlanYearEndDate() {
		return planYearEndDate;
	}

	public void setPlanYearEndDate(String planYearEndDate) {
		this.planYearEndDate = planYearEndDate;
	}
	
	@XmlElementWrapper(name = "NonEmployeeFirstName")
	@XmlElement(name = "NonEmployeeFirstName")
	private String nonEmployeeFirstName;

	
	public String getNonEmployeeFirstName() {
		return nonEmployeeFirstName;
	}

	public void setNonEmployeeFirstName(String nonEmployeeFirstName) {
		this.nonEmployeeFirstName = nonEmployeeFirstName;
	}


	@XmlElementWrapper(name = "NonEmployeeLastName")
	@XmlElement(name = "NonEmployeeLastName")
	private String nonEmployeeLastName;

	
	public String getNonEmployeeLastName() {
		return nonEmployeeLastName;
	}

	public void setNonEmployeeLastName(String nonEmployeeLastName) {
		this.nonEmployeeLastName = nonEmployeeLastName;
	}


	@XmlElementWrapper(name = "NonEmployeeAddress1")
	@XmlElement(name = "NonEmployeeAddress1")
	private String nonEmployeeAddress1;

	
	public String getNonEmployeeAddress1() {
		return nonEmployeeAddress1;
	}

	public void setNonEmployeeAddress1(String nonEmployeeAddress1) {
		this.nonEmployeeAddress1 = nonEmployeeAddress1;
	}

	
	@XmlElementWrapper(name = "NonEmployeeAddress2")
	@XmlElement(name = "NonEmployeeAddress2")
	private String nonEmployeeAddress2;

	
	public String getNonEmployeeAddress2() {
		return nonEmployeeAddress2;
	}

	public void setNonEmployeeAddress2(String nonEmployeeAddress2) {
		this.nonEmployeeAddress2 = nonEmployeeAddress2;
	}
	
	@XmlElementWrapper(name = "NonEmployeeCity")
	@XmlElement(name = "NonEmployeeCity")
	private String nonEmployeeCity;

	
	public String getNonEmployeeCity() {
		return nonEmployeeCity;
	}

	public void setNonEmployeeCity(String nonEmployeeCity) {
		this.nonEmployeeCity = nonEmployeeCity;
	}
	
	@XmlElementWrapper(name = "NonEmployeeState")
	@XmlElement(name = "NonEmployeeState")
	private String nonEmployeeState;

	
	public String getNonEmployeeState() {
		return nonEmployeeState;
	}

	public void setNonEmployeeState(String nonEmployeeState) {
		this.nonEmployeeState = nonEmployeeState;
	}

	@XmlElementWrapper(name = "NonEmployeeZip")
	@XmlElement(name = "NonEmployeeZip")
	private String nonEmployeeZip;

	
	public String getNonEmployeeZip() {
		return nonEmployeeZip;
	}

	public void setNonEmployeeZip(String nonEmployeeZip) {
		this.nonEmployeeZip = nonEmployeeZip;
	}

	@XmlElementWrapper(name = "NonEmployeeCountryCode")
	@XmlElement(name = "NonEmployeeCountryCode")
	private String nonEmployeeCountryCode;

	
	public String getNonEmployeeCountryCode() {
		return nonEmployeeCountryCode;
	}

	public void setNonEmployeeCountryCode(String nonEmployeeCountryCode) {
		this.nonEmployeeCountryCode = nonEmployeeCountryCode;
	}
	
	
	@XmlElementWrapper(name = "NonEmployeeEmployerEIN")
	@XmlElement(name = "NonEmployeeEmployerEIN")
	private String nonEmployeeEmployerEIN;

	
	public String getNonEmployeeEmployerEIN() {
		return nonEmployeeEmployerEIN;
	}

	public void setNonEmployeeEmployerEIN(String nonEmployeeEmployerEIN) {
		this.nonEmployeeEmployerEIN = nonEmployeeEmployerEIN;
	}
	
}
