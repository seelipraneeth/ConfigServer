package com.reporting.webapi.responsewrapper.vo;

import java.io.Serializable;
import java.util.List;

import com.reporting.webapi.response.vo.Original1095ReportDataVO;

public class CustomtOriginal1095ReportDataVO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private List<Original1095ReportDataVO> original1095ReportData;

	public List<Original1095ReportDataVO> getOriginal1095ReportData() {
		return original1095ReportData;
	}

	public void setOriginal1095ReportData(List<Original1095ReportDataVO> original1095ReportData) {
		this.original1095ReportData = original1095ReportData;
	}
	
	
}
