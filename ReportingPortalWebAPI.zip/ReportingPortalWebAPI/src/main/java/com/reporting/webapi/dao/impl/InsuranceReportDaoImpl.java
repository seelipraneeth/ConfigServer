package com.reporting.webapi.dao.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import com.reporting.webapi.bean.InsuranceServiceReferanceDataBean;
import com.reporting.webapi.dao.IInsuranceReportDao;
import com.reporting.webapi.response.vo.InsuranceReportDataVO;

@Repository
public class InsuranceReportDaoImpl implements IInsuranceReportDao{
	
	private final Logger logger = Logger.getLogger(InsuranceReportDaoImpl.class);

	@Resource(name = "sessionFactory")
	private SessionFactory sessionFactory;
	
	@SuppressWarnings("unchecked")
	@Override
	public InsuranceServiceReferanceDataBean getInsuranceServiceReferenceData() throws Exception {

		if(logger.isDebugEnabled()){
			logger.debug("START :: InsuranceReportDaoImpl : getInsuranceServiceReferenceData ");
		}
		
		Session session = sessionFactory.openSession();
		InsuranceServiceReferanceDataBean insuranceServiceReferanceDataBean = new InsuranceServiceReferanceDataBean();
		
		try{
			Query taxYearQuery = session.getNamedQuery("PRC_Insurance_ReferenceData_TaxYear");// PRC_LegalEntities_ReferenceData_TaxYear
			insuranceServiceReferanceDataBean.setTaxYearList(taxYearQuery.list());
			
			Query controlGroupQuery = session.getNamedQuery("PRC_Insurance_ReferenceData_ControlGroup");//PRC_LegalEntities_ReferenceData_ControlGroup
			insuranceServiceReferanceDataBean.setControlGroupList(controlGroupQuery.list());
			
		}catch(Exception e){
			logger.error("Error while fetching data getInsuranceServiceReferenceData : " + e.getMessage());
		}
		
		if(logger.isDebugEnabled()){
			logger.debug("END :: InsuranceReportDaoImpl : getInsuranceServiceReferenceData ");
		}
		
		return insuranceServiceReferanceDataBean;
	}

	
	@SuppressWarnings({ "unchecked" })
	@Override
	public List<InsuranceReportDataVO> getInsuranceReportData(String taxYear,String controlGroup) throws Exception {
		
		if(logger.isDebugEnabled()){
			logger.debug("START :: InsuranceReportDaoImpl : getInsuranceReportData ");
		}
		
		Session session = sessionFactory.openSession();
		InsuranceReportDataVO insuranceReportDataVO = null;
		List<InsuranceReportDataVO> listVo = null;
		try{
			Query query = session.getNamedQuery("PRC_Insurance_ReportData");//PRC_LegalEntities_ReportData
			query.setParameter("taxYear",taxYear);
			query.setParameter("controlGroup", controlGroup);
			List<?> list = query.list();
			
			listVo = new ArrayList<InsuranceReportDataVO>();
			if (list != null && list.size() > 0) {
			Iterator<?> iterator = list.iterator();
			while(iterator.hasNext()){
				Object column[] = (Object[])iterator.next();
				insuranceReportDataVO = new InsuranceReportDataVO();
				if (null != column[0]) {
					insuranceReportDataVO.setControlGroup(column[0].toString());
				}
				if (null != column[1]) {
					insuranceReportDataVO.setTaxYear(column[1].toString());
				}
				if (null != column[2]) {
					insuranceReportDataVO.setSSN(column[2].toString());
				}
				if (null != column[3]) {
					insuranceReportDataVO.setPlanProvidesMec(column[3].toString());
				}
				if (null != column[4]) {
					insuranceReportDataVO.setPlanProvidesMinValue(column[4].toString());
				}
				if (null != column[5]) {
					insuranceReportDataVO.setPlanEligiblePersons(column[5].toString());
				}
				if (null != column[6]) {
					insuranceReportDataVO.setPlanSelfInsured(column[6].toString());
				}
				if (null != column[7]) {
					insuranceReportDataVO.setLowestCostSelfOnlyPremium(column[7].toString());
				}
				if (null != column[8]) {
					insuranceReportDataVO.setBenefitCoverageStartDate(column[8].toString());
				}
				if (null != column[9]) {
					insuranceReportDataVO.setBenefitCoverageChangeEffectiveDate(column[9].toString());
				}
				if (null != column[10]) {
					insuranceReportDataVO.setBenefitCoverageEndDate(column[10].toString());
				}
				if (null != column[11]) {
					insuranceReportDataVO.setAffordabilitySafeHarbor(column[11].toString());
				}
				if (null != column[12]) {
					insuranceReportDataVO.setBenefitCoverageEnrolledDeclined(column[12].toString());
				}
				if (null != column[13]) {
					insuranceReportDataVO.setEligibilityPeriodStartDate(column[13].toString());
				}
				if (null != column[14]) {
					insuranceReportDataVO.setCobraEnrollment(column[14].toString());
				}
				if (null != column[15]) {
					insuranceReportDataVO.setNonEmployee(column[15].toString());
				}
				if (null != column[16]) {
					insuranceReportDataVO.setPlanYearStartDate(column[16].toString());
				}
				if (null != column[17]) {
					insuranceReportDataVO.setPlanYearEndDate(column[17].toString());
				}
				if (null != column[18]) {
					insuranceReportDataVO.setNonEmployeeFirstName(column[18].toString());
				}
				if (null != column[19]) {
					insuranceReportDataVO.setNonEmployeeLastName(column[19].toString());
				}
				if (null != column[20]) {
					insuranceReportDataVO.setNonEmployeeAddress1(column[20].toString());
				}
				if (null != column[21]) {
					insuranceReportDataVO.setNonEmployeeAddress2(column[21].toString());
				}
				if (null != column[22]) {
					insuranceReportDataVO.setNonEmployeeCity(column[22].toString());
				}
				if (null != column[23]) {
					insuranceReportDataVO.setNonEmployeeState(column[23].toString());
				}
				if (null != column[24]) {
					insuranceReportDataVO.setNonEmployeeZip(column[24].toString());
				}
				if (null != column[25]) {
					insuranceReportDataVO.setNonEmployeeCountryCode(column[25].toString());
				}
				if (null != column[26]) {
					insuranceReportDataVO.setNonEmployeeEmployerEIN(column[26].toString());
				}
				
				
				listVo.add(insuranceReportDataVO);
			}
			}else{
				listVo=null;
			}
			
			
		}catch(Exception e){
			logger.error("Error while fetching data getLegalEntitiesReportData : " + e.getMessage());
		}
		
		if(logger.isDebugEnabled()){
			logger.debug("END :: LegalEntitiesReportDaoImpl : getLegalEntitiesReportData ");
		}
		
		return listVo;
	}

}
