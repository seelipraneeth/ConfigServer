package com.reporting.webapi.adapter;

import java.util.List;

import com.reporting.webapi.bean.LegalEntitiesServiceReferanceDataBean;
import com.reporting.webapi.response.vo.LegalEntitiesReportDataVO;

public interface ILegalEntitiesReportAdapter {
	public LegalEntitiesServiceReferanceDataBean getLegalEntitiesServiceReferenceData()throws Exception;
	public List<LegalEntitiesReportDataVO> getLegalEntitiesReportData(String taxYear,String controlGroup) throws Exception;
}
