package com.reporting.webapi.adapter.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.reporting.webapi.adapter.IDataAcaPayrollServiceAdapter;
import com.reporting.webapi.bean.DataAcaPayrollReferenceData;
import com.reporting.webapi.dao.IDataAcaPayrollServiceDao;
import com.reporting.webapi.response.vo.DataAcaPayrollServiceDataCountVO;
import com.reporting.webapi.response.vo.DataAcaPayrollServiceReportDataVO;

@Service
public class DataAcaPayrollServiceAdapterImpl implements IDataAcaPayrollServiceAdapter{

	private final Logger logger = Logger.getLogger(DataAcaPayrollServiceAdapterImpl.class);
	
	@Autowired
	private IDataAcaPayrollServiceDao dataAcaPayrollServiceDao;

	@Override
	public DataAcaPayrollReferenceData getDataAcaPayrollServiceReferenceData() {
		if (logger.isDebugEnabled()) {
			logger.debug(
					"START :: DataAcaPayrollServiceAdapterImpl : getDataAcaPayrollServiceReferenceData : Method to getDataAcaPayrollServiceReferenceData");
		}
		DataAcaPayrollReferenceData dataAcaPayrollReferenceData = dataAcaPayrollServiceDao
				.getDataAcaPayrollServiceReferenceData();
		if (logger.isDebugEnabled()) {
			logger.debug(
					"END :: DataAcaPayrollServiceAdapterImpl : getDataAcaPayrollServiceReferenceData : Method to getDataAcaPayrollServiceReferenceData");
		}
		return dataAcaPayrollReferenceData;
	}

	@Override
	public List<DataAcaPayrollServiceDataCountVO> getDataAcaPayrollServiceDataCount(String taxYear, String controlGroup,
			String sourceName, String prodCoName, String prodShowName) {
		if (logger.isDebugEnabled()) {
			logger.debug(
					"START :: DataAcaPayrollServiceAdapterImpl : getDataAcaPayrollServiceDataCount : Method to getDataAcaPayrollServiceDataCount");
		}
		List<DataAcaPayrollServiceDataCountVO> dataAcaPayrollServiceDataCount = dataAcaPayrollServiceDao
				.getDataAcaPayrollServiceDataCount(taxYear, controlGroup, sourceName, prodCoName, prodShowName);
		if (logger.isDebugEnabled()) {
			logger.debug(
					"END :: DataAcaPayrollServiceAdapterImpl : getDataAcaPayrollServiceDataCount : Method to getDataAcaPayrollServiceDataCount");
		}
		return dataAcaPayrollServiceDataCount;
	}

	@Override
	public List<DataAcaPayrollServiceReportDataVO> getDataAcaPayrollServiceReportData(String taxYear,
			String controlGroup, String sourceName, String prodCoName, String prodShowName) {
		if (logger.isDebugEnabled()) {
			logger.debug(
					"START :: DataAcaPayrollServiceAdapterImpl : getDataAcaPayrollServiceDataCount : Method to getDataAcaPayrollServiceDataCount");
		}
		List<DataAcaPayrollServiceReportDataVO> dataAcaPayrollServiceReportData = dataAcaPayrollServiceDao
				.getDataAcaPayrollServiceReportData(taxYear, controlGroup, sourceName, prodCoName, prodShowName);
		if (logger.isDebugEnabled()) {
			logger.debug(
					"END :: DataAcaPayrollServiceAdapterImpl : getDataAcaPayrollServiceDataCount : Method to getDataAcaPayrollServiceDataCount");
		}
		return dataAcaPayrollServiceReportData;
	}
}
