package com.reporting.webapi.adapter;

import java.util.List;

import com.reporting.webapi.bean.DataAcaPayrollReferenceData;
import com.reporting.webapi.response.vo.DataAcaPayrollServiceDataCountVO;
import com.reporting.webapi.response.vo.DataAcaPayrollServiceReportDataVO;

public interface IDataAcaPayrollServiceAdapter {
	
	public DataAcaPayrollReferenceData getDataAcaPayrollServiceReferenceData();

	public List<DataAcaPayrollServiceDataCountVO> getDataAcaPayrollServiceDataCount(String taxYear, String controlGroup, String sourceName, String prodCoName, String prodShowName);
	
	public List<DataAcaPayrollServiceReportDataVO> getDataAcaPayrollServiceReportData(String taxYear, String controlGroup, String sourceName, String prodCoName, String prodShowName);
	
	
}
