package com.reporting.webapi.util;

import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import com.reporting.webapi.response.vo.AcaDataSetServiceReportDataVO;
import com.reporting.webapi.response.vo.BreakInReportDataVO;
import com.reporting.webapi.response.vo.DataAcaPayrollServiceReportDataVO;
import com.reporting.webapi.response.vo.DemoGraphicsReportDataVO;
import com.reporting.webapi.response.vo.EligibilityReportDataVO;
import com.reporting.webapi.response.vo.LegalEntitiesReportDataVO;
import com.reporting.webapi.response.vo.InsuranceReportDataVO;
import com.reporting.webapi.response.vo.OnGoingReportsByWeekCountVO;
import com.reporting.webapi.response.vo.Original1095ReportDataVO;
import com.reporting.webapi.response.vo.ReportsByACAEligibleCountVO;
import com.reporting.webapi.response.vo.ReportsByAnnualizedMonthlyCountVO;
import com.reporting.webapi.response.vo.ReportsByWeeksCountVO;
import com.reporting.webapi.response.vo.ReportsForPayrollDataActivityVO;
import com.reporting.webapi.uploadexcel.builder.AcaDataSetReportExcelBuilder;
import com.reporting.webapi.uploadexcel.builder.BreakInServiceReportExcelBuilder;
import com.reporting.webapi.uploadexcel.builder.DataAcaPayrollReportExcelBuilder;
import com.reporting.webapi.uploadexcel.builder.DemographicsReportExcelBuilder;
import com.reporting.webapi.uploadexcel.builder.ERCoverageReportExcelBuilder;
import com.reporting.webapi.uploadexcel.builder.EligibilityReportExcelBuilder;
import com.reporting.webapi.uploadexcel.builder.LegalEntitiesReportExcelBuilder;
import com.reporting.webapi.uploadexcel.builder.InsuranceReportExcelBuilder;
import com.reporting.webapi.uploadexcel.builder.NewHiresFullTimeReportExcelBuilder;
import com.reporting.webapi.uploadexcel.builder.NewHiresNonFullTimeReportExcelBuilder;
import com.reporting.webapi.uploadexcel.builder.OnGoingReportExcelBuilder;
import com.reporting.webapi.uploadexcel.builder.Original1095ReportExcelBuilder;
import com.reporting.webapi.uploadexcel.builder.PayrollDataActivityReportExcelBuilder;

@Component
public class ReportsExcelBuilderUtil extends AbstractExcelView {

	private final Logger logger = Logger.getLogger(ReportsExcelBuilderUtil.class);
	
	@Autowired
	private CommonUtil commonUtil;
	
	@Autowired
	private NewHiresNonFullTimeReportExcelBuilder nhnftExcelBuilder;
	
	@Autowired
	private NewHiresFullTimeReportExcelBuilder nhftExcelBuilder;
	
	@Autowired
	private OnGoingReportExcelBuilder ongoingExcelBuilder;
	
	@Autowired
	private ERCoverageReportExcelBuilder erCoverageExcelBuilder;
	
	@Autowired
	private BreakInServiceReportExcelBuilder breakInServiceReportExcelBuilder;
	
	@Autowired
	private PayrollDataActivityReportExcelBuilder payrollDataActivityExcelBuilder;
	
	@Autowired
	private DemographicsReportExcelBuilder demographicsReportExcelBuilder;
	
	@Autowired
	private EligibilityReportExcelBuilder eligibilityReportExcelBuilder;
	
	@Autowired
	private DataAcaPayrollReportExcelBuilder dataAcaPayrollReportExcelBuilder;
	
	@Autowired
	private LegalEntitiesReportExcelBuilder legalEntitiesReportExcelBuilder;
	
	@Autowired
	private InsuranceReportExcelBuilder insuranceReportExcelBuilder;
	
	@Autowired
	private AcaDataSetReportExcelBuilder acaDataSetReportExcelBuilder;
	
	@Autowired
	private Original1095ReportExcelBuilder original1095ReportExcelBuilder;
	
	@SuppressWarnings("unchecked")
	public String buildExcelDocument(Map<String,List<?>> reportsDataMap, List<String> controlGroupList,String...argParams) throws Exception {
		
        Set<String> reportsListKeys = reportsDataMap.keySet();
        String generatedDocumentPath = null;
        
        if(CollectionUtils.isNotEmpty(reportsListKeys)){
        	for(String reportKey : reportsListKeys) {
            	switch(reportKey) {
            		case "NewHiresNonFullTimeReport" :
            			if(null != argParams[2]) {
            				String controlGroupValue = argParams[2];
            				List<String> selectedControlGroupList = commonUtil.getSelectedControlGroupList(controlGroupValue);
            				Map<String, List<ReportsByWeeksCountVO>> reportsMapByControlGroup = nhnftExcelBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), selectedControlGroupList);
            				generatedDocumentPath = nhnftExcelBuilder.processExcelContent(reportsMapByControlGroup,argParams);
            			} else {
            				Map<String, List<ReportsByWeeksCountVO>> reportsMapByControlGroup = nhnftExcelBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), controlGroupList);
            				generatedDocumentPath = nhnftExcelBuilder.processExcelContent(reportsMapByControlGroup,argParams);
            			}
            			break;
            		case "NewHiresFullTimeReport" :
            			if(null != argParams[2]) {
            				String controlGroupValue = argParams[2];
            				List<String> selectedControlGroupList = commonUtil.getSelectedControlGroupList(controlGroupValue);
            				Map<String, List<ReportsByACAEligibleCountVO>> reportsMapByControlGroup = nhftExcelBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), selectedControlGroupList);
            				generatedDocumentPath = nhftExcelBuilder.processExcelContent(reportsMapByControlGroup,argParams);
            			} else {
            				Map<String, List<ReportsByACAEligibleCountVO>> reportsMapByControlGroup = nhftExcelBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), controlGroupList);
            				generatedDocumentPath = nhftExcelBuilder.processExcelContent(reportsMapByControlGroup,argParams);
            			}
            			break;
            		case "OnGoingReport" :
            			if(null != argParams[3]) {
            				String controlGroupValue = argParams[3];
            				List<String> selectedControlGroupList = commonUtil.getSelectedControlGroupList(controlGroupValue);
            				Map<String, List<OnGoingReportsByWeekCountVO>> reportsMapByControlGroup = ongoingExcelBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), selectedControlGroupList);
            				generatedDocumentPath = ongoingExcelBuilder.processExcelContent(reportsMapByControlGroup,argParams);
            			} else {
            				Map<String, List<OnGoingReportsByWeekCountVO>> reportsMapByControlGroup = ongoingExcelBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), controlGroupList);
            				generatedDocumentPath = ongoingExcelBuilder.processExcelContent(reportsMapByControlGroup,argParams);
            			}
            			break;
            		case "ERCoverageReport" : 
            			if(null != argParams[1]) {
            				String controlGroupValue = argParams[1];
            				List<String> selectedControlGroupList = commonUtil.getSelectedControlGroupList(controlGroupValue);
            				Map<String, List<ReportsByAnnualizedMonthlyCountVO>> reportsMapByControlGroup = erCoverageExcelBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), selectedControlGroupList);
            				generatedDocumentPath = erCoverageExcelBuilder.processExcelContent(reportsMapByControlGroup,argParams);
            			} else {
            				Map<String, List<ReportsByAnnualizedMonthlyCountVO>> reportsMapByControlGroup = erCoverageExcelBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), controlGroupList);
            				generatedDocumentPath = erCoverageExcelBuilder.processExcelContent(reportsMapByControlGroup,argParams);
            			}
            			break;
            		case "PayrollDataActivityReport" :
            				if(null != argParams[1]) {
                				String controlGroupValue = argParams[1];
                				List<String> selectedControlGroupList = commonUtil.getSelectedControlGroupList(controlGroupValue);
                				Map<String, List<ReportsForPayrollDataActivityVO>> reportsMapByControlGroup = payrollDataActivityExcelBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), selectedControlGroupList);
                				generatedDocumentPath = payrollDataActivityExcelBuilder.processExcelContent(reportsMapByControlGroup,argParams);
                			} else {
                				Map<String, List<ReportsForPayrollDataActivityVO>> reportsMapByControlGroup = payrollDataActivityExcelBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), controlGroupList);
                				generatedDocumentPath = payrollDataActivityExcelBuilder.processExcelContent(reportsMapByControlGroup,argParams);
                			}
            			break;
            		case "BreakInReport" :
            				if(null != argParams[1]) {
                				String controlGroupValue = argParams[1];
                				List<String> selectedControlGroupList = commonUtil.getSelectedControlGroupList(controlGroupValue);
                				Map<String, List<BreakInReportDataVO>> reportsMapByControlGroup = breakInServiceReportExcelBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), selectedControlGroupList);
                				generatedDocumentPath = breakInServiceReportExcelBuilder.processExcelContent(reportsMapByControlGroup,argParams);
                			} else {
                				Map<String, List<BreakInReportDataVO>> reportsMapByControlGroup = breakInServiceReportExcelBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), controlGroupList);
                				generatedDocumentPath = breakInServiceReportExcelBuilder.processExcelContent(reportsMapByControlGroup,argParams);
                			}
            			break;
            		case "DemographicsReport" :
            				if(null != argParams[1]) {
                				String controlGroupValue = argParams[1];
                				List<String> selectedControlGroupList = commonUtil.getSelectedControlGroupList(controlGroupValue);
                				Map<String, List<DemoGraphicsReportDataVO>> reportsMapByControlGroup = demographicsReportExcelBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), selectedControlGroupList);
                				generatedDocumentPath = demographicsReportExcelBuilder.processExcelContent(reportsMapByControlGroup,argParams);
                			} else {
                				Map<String, List<DemoGraphicsReportDataVO>> reportsMapByControlGroup = demographicsReportExcelBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), controlGroupList);
                				generatedDocumentPath = demographicsReportExcelBuilder.processExcelContent(reportsMapByControlGroup,argParams);
                			}
            			break;
            		case "EligibilityReport" :
            				if(null != argParams[1]) {
                				String controlGroupValue = argParams[1];
                				List<String> selectedControlGroupList = commonUtil.getSelectedControlGroupList(controlGroupValue);
                				Map<String, List<EligibilityReportDataVO>> reportsMapByControlGroup = eligibilityReportExcelBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), selectedControlGroupList);
                				generatedDocumentPath = eligibilityReportExcelBuilder.processExcelContent(reportsMapByControlGroup,argParams);
                			} else {
                				Map<String, List<EligibilityReportDataVO>> reportsMapByControlGroup = eligibilityReportExcelBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), controlGroupList);
                				generatedDocumentPath = eligibilityReportExcelBuilder.processExcelContent(reportsMapByControlGroup,argParams);
                			}
            			break;
            		case "DataAcaPayrollServiceReport" :
	            			if(null != argParams[1]) {
	            				String controlGroupValue = argParams[1];
	            				List<String> selectedControlGroupList = commonUtil.getSelectedControlGroupList(controlGroupValue);
	            				Map<String, List<DataAcaPayrollServiceReportDataVO>> reportsMapByControlGroup = dataAcaPayrollReportExcelBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), selectedControlGroupList);
	            				generatedDocumentPath = dataAcaPayrollReportExcelBuilder.processExcelContent(reportsMapByControlGroup, argParams);
	            			} else {
	            				Map<String, List<DataAcaPayrollServiceReportDataVO>> reportsMapByControlGroup = dataAcaPayrollReportExcelBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), controlGroupList);
	            				generatedDocumentPath = dataAcaPayrollReportExcelBuilder.processExcelContent(reportsMapByControlGroup, argParams);
	            			}
            			break;
            		case "LegalEntitiesReport" :
        				if(null != argParams[1]) {
            				String controlGroupValue = argParams[1];
            				List<String> selectedControlGroupList = commonUtil.getSelectedControlGroupList(controlGroupValue);
            				Map<String, List<LegalEntitiesReportDataVO>> reportsMapByControlGroup = legalEntitiesReportExcelBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), selectedControlGroupList);
            				generatedDocumentPath = legalEntitiesReportExcelBuilder.processExcelContent(reportsMapByControlGroup,argParams);
            			} else {
            				Map<String, List<LegalEntitiesReportDataVO>> reportsMapByControlGroup = legalEntitiesReportExcelBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), controlGroupList);
            				generatedDocumentPath = legalEntitiesReportExcelBuilder.processExcelContent(reportsMapByControlGroup,argParams);
            			}
        			break;
            		case "InsuranceReport" :
        				if(null != argParams[1]) {
            				String controlGroupValue = argParams[1];
            				List<String> selectedControlGroupList = commonUtil.getSelectedControlGroupList(controlGroupValue);
            				Map<String, List<InsuranceReportDataVO>> reportsMapByControlGroup = insuranceReportExcelBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), selectedControlGroupList);
            				generatedDocumentPath = insuranceReportExcelBuilder.processExcelContent(reportsMapByControlGroup,argParams);
            			} else {
            				Map<String, List<InsuranceReportDataVO>> reportsMapByControlGroup = insuranceReportExcelBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), controlGroupList);
            				generatedDocumentPath = insuranceReportExcelBuilder.processExcelContent(reportsMapByControlGroup,argParams);
            			}
        			break;
					case "AcaDataSetServiceReport" :
            			if(null != argParams[0]) {
            				String controlGroupValue = argParams[0];
            				List<String> selectedControlGroupList = commonUtil.getSelectedControlGroupList(controlGroupValue);
            				Map<String, List<AcaDataSetServiceReportDataVO>> reportsMapByControlGroup = acaDataSetReportExcelBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), selectedControlGroupList);
            				generatedDocumentPath = acaDataSetReportExcelBuilder.processExcelContent(reportsMapByControlGroup, argParams);
            			} else {
            				Map<String, List<AcaDataSetServiceReportDataVO>> reportsMapByControlGroup = acaDataSetReportExcelBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), controlGroupList);
            				generatedDocumentPath = acaDataSetReportExcelBuilder.processExcelContent(reportsMapByControlGroup, argParams);
            			}
            			break;
            		case "Original1095Report" :
            			if(null != argParams[0]) {
            				String controlGroupValue = argParams[0];
            				List<String> selectedControlGroupList = commonUtil.getSelectedControlGroupList(controlGroupValue);
            				Map<String, List<Original1095ReportDataVO>> reportsMapByControlGroup = original1095ReportExcelBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), selectedControlGroupList);
            				generatedDocumentPath = original1095ReportExcelBuilder.processExcelContent(reportsMapByControlGroup, argParams);
            			} else {
            				
            			}
            		default :
            			logger.info("ReportsExcelBuilder is invoked but the requested Report to be generated is not yet configured in the Reporting Portal");
            	}
            }
        }
        
        
        return generatedDocumentPath;
	}
	
	@Override
	protected void buildExcelDocument(Map<String, Object> arg0, HSSFWorkbook arg1, HttpServletRequest arg2,
			HttpServletResponse arg3) throws Exception {
		
		// TODO Auto-generated method stub
		
	}

}
