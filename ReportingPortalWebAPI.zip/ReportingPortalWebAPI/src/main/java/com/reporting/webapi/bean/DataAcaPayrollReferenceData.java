package com.reporting.webapi.bean;

import java.util.List;

public class DataAcaPayrollReferenceData {

	private List<String> taxYearList;
	private List<String> controlGroupList;
	private List<String> sourceNameList;
	private List<String> prodCoNameList;
	private List<String> prodShowNameList;
	
	public List<String> getTaxYearList() {
		return taxYearList;
	}
	public void setTaxYearList(List<String> taxYearList) {
		this.taxYearList = taxYearList;
	}
	public List<String> getControlGroupList() {
		return controlGroupList;
	}
	public void setControlGroupList(List<String> controlGroupList) {
		this.controlGroupList = controlGroupList;
	}
	public List<String> getSourceNameList() {
		return sourceNameList;
	}
	public void setSourceNameList(List<String> sourceNameList) {
		this.sourceNameList = sourceNameList;
	}
	public List<String> getProdCoNameList() {
		return prodCoNameList;
	}
	public void setProdCoNameList(List<String> prodCoNameList) {
		this.prodCoNameList = prodCoNameList;
	}
	public List<String> getProdShowNameList() {
		return prodShowNameList;
	}
	public void setProdShowNameList(List<String> prodShowNameList) {
		this.prodShowNameList = prodShowNameList;
	}
	
	
}
