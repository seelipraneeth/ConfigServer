package com.reporting.webapi.dao;

import java.util.List;

import com.reporting.webapi.bean.Original1095ReportReferenceData;
import com.reporting.webapi.response.vo.Original1095ReportDataVO;

public interface IOriginal1095ReportDao {

	public Original1095ReportReferenceData getOriginal1095ReportReferenceData();
	
	public List<Original1095ReportDataVO> getOriginal1095ReportData(String controlGroup, String taxYear);
}
