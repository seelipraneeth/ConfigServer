package com.reporting.webapi.adapter.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.reporting.webapi.adapter.IInsuranceReportAdapter;
import com.reporting.webapi.bean.InsuranceServiceReferanceDataBean;
import com.reporting.webapi.dao.IInsuranceReportDao;
import com.reporting.webapi.response.vo.InsuranceReportDataVO;

@Service
public class InsuranceReportAdapterImpl implements IInsuranceReportAdapter {

	private final Logger logger = Logger.getLogger(LegalEntitiesReportAdapterImpl.class);

	@Autowired
	private IInsuranceReportDao insuranceReportDao;
	
	@Override
	public InsuranceServiceReferanceDataBean getInsuranceServiceReferenceData() throws Exception {
		if(logger.isDebugEnabled()){
			logger.debug("START :: InsuranceReportAdapterImpl : getInsuranceServiceReferenceData : Method to getInsuranceServiceReferenceData");
		}
		InsuranceServiceReferanceDataBean insuranceServiceReferanceDataBean = insuranceReportDao.getInsuranceServiceReferenceData();
		if(logger.isDebugEnabled()){
			logger.debug("END :: InsuranceReportAdapterImpl : getInsuranceServiceReferenceData : Method to getInsuranceServiceReferenceData");
		}
		return insuranceServiceReferanceDataBean;
	}
	
	
	@Override
	public List<InsuranceReportDataVO> getInsuranceReportData(String taxYear,String controlGroup) throws Exception {
		if(logger.isDebugEnabled()){
			logger.debug("START :: InsuranceReportDataVO : getInsuranceReportData : Method to getInsuranceReportData");
		}
		List<InsuranceReportDataVO> insuranceReportDataVO = insuranceReportDao.getInsuranceReportData(taxYear,controlGroup);
		if(logger.isDebugEnabled()){
			logger.debug("END :: InsuranceReportDataVO : getInsuranceReportData : Method to getInsuranceReportData");
		}
		return insuranceReportDataVO;
	}
	
	
}
