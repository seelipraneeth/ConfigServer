package com.reporting.webapi.adapter.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.reporting.webapi.adapter.IOriginal1095ReportAdapter;
import com.reporting.webapi.bean.Original1095ReportReferenceData;
import com.reporting.webapi.dao.IOriginal1095ReportDao;
import com.reporting.webapi.response.vo.Original1095ReportDataVO;

@Service
public class Original1095ReportAdapterImpl implements IOriginal1095ReportAdapter {

	private final Logger logger = Logger.getLogger(AcaDataSetServiceAdapterImpl.class);
	
	@Autowired
	private IOriginal1095ReportDao original1095ReportDao;

	@Override
	public Original1095ReportReferenceData getOriginal1095ReportReferenceData() {
		if (logger.isDebugEnabled()) {
			logger.debug(
					"START :: Original1095ReportAdapterImpl : getOriginal1095ReportReferenceData : Method to getOriginal1095ReportReferenceData");
		}
		Original1095ReportReferenceData referenceData = original1095ReportDao.getOriginal1095ReportReferenceData();
		if (logger.isDebugEnabled()) {
			logger.debug(
					"END :: Original1095ReportAdapterImpl : getOriginal1095ReportReferenceData : Method to getOriginal1095ReportReferenceData");
		}
		return referenceData;
	}

	@Override
	public List<Original1095ReportDataVO> getOriginal1095ReportData(String controlGroup, String taxYear) {
		if (logger.isDebugEnabled()) {
			logger.debug(
					"START :: Original1095ReportAdapterImpl : getOriginal1095ReportData : Method to getOriginal1095ReportData");
		}
		List<Original1095ReportDataVO> reportData = original1095ReportDao.getOriginal1095ReportData(controlGroup, taxYear);
		if (logger.isDebugEnabled()) {
			logger.debug(
					"END :: Original1095ReportAdapterImpl : getOriginal1095ReportData : Method to getOriginal1095ReportReferenceData");
		}
		return reportData;
	}
}
