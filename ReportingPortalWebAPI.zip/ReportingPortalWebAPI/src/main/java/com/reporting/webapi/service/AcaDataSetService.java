package com.reporting.webapi.service;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.reporting.webapi.adapter.IAcaDataSetServiceAdapter;
import com.reporting.webapi.bean.AcaDataSetReferenceData;
import com.reporting.webapi.response.vo.AcaDataSetReferenceDataVO;
import com.reporting.webapi.response.vo.AcaDataSetServiceDataCountVO;
import com.reporting.webapi.response.vo.AcaDataSetServiceReportDataVO;
import com.reporting.webapi.responsewrapper.vo.CustomAcaDataSetServiceReferenceDataVO;
import com.reporting.webapi.responsewrapper.vo.CustomtAcaDataSetServiceCountVO;
import com.reporting.webapi.responsewrapper.vo.CustomtAcaDataSetServiceReportDataVO;
import com.reporting.webapi.util.CommonConstants;
import com.reporting.webapi.util.ReportsExcelBuilderUtil;

@Component
@Path(value=CommonConstants.ACA_DATASET_SERVICE)
public class AcaDataSetService {

private final Logger logger = Logger.getLogger(DataAcaPayrollService.class);
	
	@Autowired
	private IAcaDataSetServiceAdapter acaDataSetServiceAdapter;
	
	@Autowired
	private ReportsExcelBuilderUtil reportsExcelBuilderUtil;
	
	@Path(CommonConstants.ACA_DATASET_SERVICE_REFERENCE_DATA)
	@GET
	@Produces( { MediaType.APPLICATION_JSON})
	public Response getAcaDataSetServiceReferenceData() {
		
		if(logger.isDebugEnabled()){
			logger.debug("START :: AcaDataSetService : getAcaDataSetServiceReferenceData : Method to getAcaDataSetServiceReferenceData");
		}
		
		CustomAcaDataSetServiceReferenceDataVO customAcaDataSetServiceReferenceDataVO = new CustomAcaDataSetServiceReferenceDataVO();
		try{
			AcaDataSetReferenceData acaDataSetReferenceData = acaDataSetServiceAdapter.getAcaDataSetServiceReferenceData();
			
			AcaDataSetReferenceDataVO acaDataSetReferenceDataVO =  new AcaDataSetReferenceDataVO();
			acaDataSetReferenceDataVO.setControlgroups(acaDataSetReferenceData.getControlGroupList());
			acaDataSetReferenceDataVO.setEmployerNames(acaDataSetReferenceData.getEmployerNameList());
			acaDataSetReferenceDataVO.setSourceCodes(acaDataSetReferenceData.getSourceCodeList());
			
			customAcaDataSetServiceReferenceDataVO.setAcaDataSetReferenceDataVO(acaDataSetReferenceDataVO);
			
		} catch (Exception e) {
			logger.error("Error while invoking getAcaDataSetServiceReferenceData : " + e.getMessage());
		}	
		if(logger.isDebugEnabled()){
			logger.debug("END :: AcaDataSetService : getAcaDataSetServiceReferenceData : Method to getAcaDataSetServiceReferenceData");
		}
		
		return Response.ok(customAcaDataSetServiceReferenceDataVO).build();
	}
	
	@Path(CommonConstants.ACA_DATASET_SERVICE_COUNT)
	@GET
	@Produces( { MediaType.APPLICATION_JSON})
	public Response getAcaDataSetServiceCount(@QueryParam(CommonConstants.CONTROL_GROUP) String controlGroup, @QueryParam(CommonConstants.EMPLOYER_NAME) String employerName,
			@QueryParam(CommonConstants.SOURCE_CODE) String sourceCode, @QueryParam(CommonConstants.EMPLOYEE_NAME) String employeeName, @QueryParam(CommonConstants.HOURS_PAID) String hoursPaid) {
	
		if(logger.isDebugEnabled()){
			logger.debug("START :: AcaDataSetService : getAcaDataSetServiceCount : Method to getAcaDataSetServiceCount");
		}
		
		CustomtAcaDataSetServiceCountVO customtAcaDataSetServiceCountVO = new CustomtAcaDataSetServiceCountVO();
		List<AcaDataSetServiceDataCountVO> acaDataSetServiceCount = null;
		
		try {
			if(null != controlGroup && controlGroup.contains("''") &&  controlGroup.length() == 2) {
				controlGroup = null;
			}
			if(null != employerName && employerName.contains("''") &&  employerName.length() == 2) {
				employerName = null;
			}
			if(null != sourceCode && sourceCode.contains("''") &&  sourceCode.length() == 2) {
				sourceCode = null;
			}
			if(null != employeeName && employeeName.contains("''") &&  employeeName.length() == 2) {
				employeeName = null;
			}
			if(null != hoursPaid && hoursPaid.contains("''") &&  hoursPaid.length() == 2) {
				hoursPaid = null;
			}
			
			acaDataSetServiceCount = acaDataSetServiceAdapter.getAcaDataSetServiceDataCount(controlGroup, employerName, sourceCode, employeeName, hoursPaid);
			customtAcaDataSetServiceCountVO.setAcaDataSetServiceCount(acaDataSetServiceCount);
		} catch(Exception e) {
			logger.error("Error while invoking getAcaDataSetServiceCount : " + e.getMessage());
		}
		
		if(logger.isDebugEnabled()){
			logger.debug("END :: AcaDataSetService : getAcaDataSetServiceCount : Method to getAcaDataSetServiceCount");
		}
		
		return Response.ok(customtAcaDataSetServiceCountVO).build();
	}
	
	@Path(CommonConstants.ACA_DATASET_SERVICE_REPORT_DATA)
	@GET
	@Produces( { MediaType.APPLICATION_JSON})
	public Response getAcaDataSetServiceReportData(@QueryParam(CommonConstants.CONTROL_GROUP) String controlGroup, @QueryParam(CommonConstants.EMPLOYER_NAME) String employerName,
			@QueryParam(CommonConstants.SOURCE_CODE) String sourceCode, @QueryParam(CommonConstants.EMPLOYEE_NAME) String employeeName, @QueryParam(CommonConstants.HOURS_PAID) String hoursPaid) {
	
		if(logger.isDebugEnabled()){
			logger.debug("START :: AcaDataSetService : getAcaDataSetServiceReportData : Method to getAcaDataSetServiceReportData");
		}
		CustomtAcaDataSetServiceReportDataVO customtAcaDataSetServiceReportDataVO = new CustomtAcaDataSetServiceReportDataVO();
		List<AcaDataSetServiceReportDataVO> acaDataSetServiceReportDataVO = null;
		
		try {
			if(null != controlGroup && controlGroup.contains("''") &&  controlGroup.length() == 2) {
				controlGroup = null;
			}
			if(null != employerName && employerName.contains("''") &&  employerName.length() == 2) {
				employerName = null;
			}
			if(null != sourceCode && sourceCode.contains("''") &&  sourceCode.length() == 2) {
				sourceCode = null;
			}
			if(null != employeeName && employeeName.contains("''") &&  employeeName.length() == 2) {
				employeeName = null;
			}
			if(null != hoursPaid && hoursPaid.contains("''") &&  hoursPaid.length() == 2) {
				hoursPaid = null;
			}
			
			acaDataSetServiceReportDataVO = acaDataSetServiceAdapter.getAcaDataSetServiceReportData(controlGroup, employerName, sourceCode, employeeName, hoursPaid);
			customtAcaDataSetServiceReportDataVO.setAcaDataSetServiceReportDataVO(acaDataSetServiceReportDataVO);
		} catch(Exception e) {
			logger.error("Error while invoking getAcaDataSetServiceReportData : " + e.getMessage());
		}
		if(logger.isDebugEnabled()){
			logger.debug("END :: AcaDataSetService : getAcaDataSetServiceReportData : Method to getAcaDataSetServiceReportData");
		}
		
		return Response.ok(customtAcaDataSetServiceReportDataVO).build();
	}
	
	@Path(CommonConstants.ACA_DATASET_SERVICE_PROCESS_EXCEL_ZIP_DOWNLOAD)
	@GET
	@Produces(CommonConstants.APPLICATION_ZIP)
	public Response processAcaDataSetServiceReportExcelUpload(@QueryParam(CommonConstants.CONTROL_GROUP) String controlGroup, @QueryParam(CommonConstants.EMPLOYER_NAME) String employerName,
			@QueryParam(CommonConstants.SOURCE_CODE) String sourceCode, @QueryParam(CommonConstants.EMPLOYEE_NAME) String employeeName, @QueryParam(CommonConstants.HOURS_PAID) String hoursPaid) {
		
		if(logger.isDebugEnabled()){
			logger.debug("START :: AcaDataSetService : processAcaDataSetServiceReportExcelUpload : Method to processAcaDataSetServiceReportExcelUpload");
		}
		
		List<AcaDataSetServiceReportDataVO> acaDataSetServiceReportData = null;
		String generatedReportsPath = "";
		
		try {
			if(null != controlGroup && controlGroup.contains("''") &&  controlGroup.length() == 2) {
				controlGroup = null;
			}
			if(null != employerName && employerName.contains("''") &&  employerName.length() == 2) {
				employerName = null;
			}
			if(null != sourceCode && sourceCode.contains("''") &&  sourceCode.length() == 2) {
				sourceCode = null;
			}
			if(null != employeeName && employeeName.contains("''") &&  employeeName.length() == 2) {
				employeeName = null;
			}
			if(null != hoursPaid && hoursPaid.contains("''") &&  hoursPaid.length() == 2) {
				hoursPaid = null;
			}
			
			acaDataSetServiceReportData = acaDataSetServiceAdapter.getAcaDataSetServiceReportData(controlGroup, employerName, sourceCode, employeeName, hoursPaid);
			
			// Code To Invoke Excel Builder 
			Map<String, List<?>> reportsDataMap = new HashMap<>();
			reportsDataMap.put(CommonConstants.ACA_DATA_SET_REPORT, acaDataSetServiceReportData);
									
			AcaDataSetReferenceData acaDataSetReferenceData = acaDataSetServiceAdapter.getAcaDataSetServiceReferenceData();
			List<String> controlGroupList = acaDataSetReferenceData.getControlGroupList();
						
			generatedReportsPath = reportsExcelBuilderUtil.buildExcelDocument(reportsDataMap, controlGroupList, controlGroup, employerName, sourceCode, employeeName, hoursPaid);
						
		} catch(Exception e) {
			logger.error("Error while invoking processAcaDataSetServiceReportExcelUpload : " + e.getMessage());
		}
		if(logger.isDebugEnabled()){
			logger.debug("END :: AcaDataSetService : processAcaDataSetServiceReportExcelUpload : Method to processAcaDataSetServiceReportExcelUpload");
		}
	
		File downloadDocumentFile = new File(generatedReportsPath + ".zip");
		String buildZipFilename = "AcaDataSetServiceReports_" + generatedReportsPath.substring(generatedReportsPath.lastIndexOf("/")+1, generatedReportsPath.length()) + ".zip";
		ResponseBuilder responseBuilder = Response.ok((Object) downloadDocumentFile);
        responseBuilder.header("Content-Disposition", "attachment; filename=" + buildZipFilename );
		return responseBuilder.build();
	}
}
