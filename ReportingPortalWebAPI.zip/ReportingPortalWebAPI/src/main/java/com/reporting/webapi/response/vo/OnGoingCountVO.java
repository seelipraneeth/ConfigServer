package com.reporting.webapi.response.vo;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "onGoingCountVO")
public class OnGoingCountVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@XmlElement(name = "onGoingMonthDiffCount")
	private String onGoingMonthDiffCount;
	
	@XmlElement(name = "onGoingReportCount")
	private String onGoingReportCount;

	public String getOnGoingMonthDiffCount() {
		return onGoingMonthDiffCount;
	}

	public void setOnGoingMonthDiffCount(String onGoingMonthDiffCount) {
		this.onGoingMonthDiffCount = onGoingMonthDiffCount;
	}

	public String getOnGoingReportCount() {
		return onGoingReportCount;
	}

	public void setOnGoingReportCount(String onGoingReportCount) {
		this.onGoingReportCount = onGoingReportCount;
	}

	
	/*
	@XmlElement(name = "onGoingCountByWeeks")
	private List<OnGoingCountByWeeksVO> onGoingCountByWeeks;
	
	public List<OnGoingCountByWeeksVO> getOnGoingCountByWeeks() {
		return onGoingCountByWeeks;
	}

	public void setOnGoingCountByWeeks(List<OnGoingCountByWeeksVO> onGoingCountByWeeks) {
		this.onGoingCountByWeeks = onGoingCountByWeeks;
	}
	*/
	
}
