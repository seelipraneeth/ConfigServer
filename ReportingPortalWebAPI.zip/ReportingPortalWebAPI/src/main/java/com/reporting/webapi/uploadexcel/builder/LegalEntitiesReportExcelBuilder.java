package com.reporting.webapi.uploadexcel.builder;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.reporting.webapi.response.vo.EligibilityReportDataVO;
import com.reporting.webapi.response.vo.LegalEntitiesReportDataVO;
import com.reporting.webapi.util.CommonUtil;
import com.reporting.webapi.util.FolderZipUtil;


@Component
public class LegalEntitiesReportExcelBuilder {

	private final Logger logger = Logger.getLogger(LegalEntitiesReportExcelBuilder.class);

	@Autowired
	private CommonUtil commonUtil;
	
	@Autowired
	private FolderZipUtil folderZipUtil;
	
	public String processExcelContent(Map<String, List<LegalEntitiesReportDataVO>> reportsMapByControlGroup, String[] argParams) throws UnsupportedEncodingException {
		
		XSSFWorkbook workbook = null;
		XSSFSheet sheet = null;
		XSSFCellStyle style = null;
		Set<String> keySetValues = reportsMapByControlGroup.keySet();
		
		String forderNameTimeStampString = new SimpleDateFormat("yyyyMMddHHmmsss").format(new Date());
		String path = this.getClass().getClassLoader().getResource("").getPath();
		String fullPath = URLDecoder.decode(path, "UTF-8");
		
		String pathArr[] = fullPath.split("/WEB-INF/classes/");
		String reportsPath = pathArr[0]+"/reportsData/LegalEntitiesReports/"+forderNameTimeStampString;
		
		File reportsDirectory = new File(reportsPath);
		if(!reportsDirectory.exists()){
			try{
				reportsDirectory.mkdirs();
			} 
			catch(SecurityException se){
				logger.error(" processExcelContent :: Error while creating the required Directory : ", se);
			}      
		}
		
		for(String reportMapKey : keySetValues) {

			// Retrieving the ReportList specific to the ControlGroup matching reportMapKey
			List<LegalEntitiesReportDataVO> reportsList = reportsMapByControlGroup.get(reportMapKey);

			// Set the Control Group Name to controlGroup param in argParams
			argParams[1] = reportMapKey;

			// Initializing workbook, sheet and style
			// initialize work book
			workbook = new XSSFWorkbook();

			// initialize sheet
			sheet = workbook.createSheet("Sheet1");

			sheet.setDefaultColumnWidth(30);

			XSSFCellStyle headerCellStyle = workbook.createCellStyle();
			XSSFFont boldFont = workbook.createFont();
			boldFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
			headerCellStyle.setFont(boldFont);

			style = workbook.createCellStyle();
			XSSFFont font = workbook.createFont();

			font.setFontName("Arial");
			style.setFillForegroundColor(IndexedColors.BLUE.getIndex());
			style.setFillPattern(CellStyle.SOLID_FOREGROUND);
			font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
			font.setColor(IndexedColors.WHITE.getIndex());
			style.setFont(font);

			logger.info(" processExcelContent :: 'workbook', 'sheet' and 'style' have been initialized ");	
		
		Row header = sheet.createRow(0);
        header.createCell(0).setCellValue("Control Group");
        header.getCell(0).setCellStyle(style);
        header.createCell(1).setCellValue("Tax Year");
        header.getCell(1).setCellStyle(style);
        header.createCell(2).setCellValue("Employer EIN");
        header.getCell(2).setCellStyle(style);
        header.createCell(3).setCellValue("Employer Name");
        header.getCell(3).setCellStyle(style);
        header.createCell(4).setCellValue("Address Line 1");
        header.getCell(4).setCellStyle(style);
        header.createCell(5).setCellValue("Address Line 2");
        header.getCell(5).setCellStyle(style);
        header.createCell(6).setCellValue("City");
        header.getCell(6).setCellStyle(style);
        header.createCell(7).setCellValue("State");
        header.getCell(7).setCellStyle(style);
        header.createCell(8).setCellValue("Zip Code");
        header.getCell(8).setCellStyle(style);
        header.createCell(9).setCellValue("Contact First Name");
        header.getCell(9).setCellStyle(style);
        header.createCell(10).setCellValue("Contact Last Name");
        header.getCell(10).setCellStyle(style);        
        header.createCell(11).setCellValue("Contact Phone");
        header.getCell(11).setCellStyle(style);
        header.createCell(12).setCellValue("Transition Relief");
        header.getCell(12).setCellStyle(style);
        header.createCell(13).setCellValue("Is Authoritative");
        header.getCell(13).setCellStyle(style);
        header.createCell(14).setCellValue("Union Rule Type");
        header.getCell(14).setCellStyle(style);
        header.createCell(15).setCellValue("Non Union Rule Type");
        header.getCell(15).setCellStyle(style);
        
        
        int rowCount = 1;
        for(Object reportObj : reportsList) {
        	LegalEntitiesReportDataVO reportRowBean = (LegalEntitiesReportDataVO)reportObj;
        	
        	Row newRow = sheet.createRow(rowCount++);
        		
        	newRow.createCell(0).setCellValue(reportRowBean.getControlGroup());
        	newRow.createCell(1).setCellValue(reportRowBean.getTaxYear());
        	newRow.createCell(2).setCellValue(reportRowBean.getEmployerEIN());
        	newRow.createCell(3).setCellValue(reportRowBean.getEmployerName());
        	newRow.createCell(4).setCellValue(reportRowBean.getAddressLine1());
        	newRow.createCell(5).setCellValue(reportRowBean.getAddressLine2());
        	newRow.createCell(6).setCellValue(reportRowBean.getCity());
        	newRow.createCell(7).setCellValue(reportRowBean.getState());
        	newRow.createCell(8).setCellValue(reportRowBean.getZipCode());
        	newRow.createCell(9).setCellValue(reportRowBean.getContactFirstName());
        	newRow.createCell(10).setCellValue(reportRowBean.getContactLastName());
        	newRow.createCell(11).setCellValue(reportRowBean.getContactPhone());
        	newRow.createCell(12).setCellValue(reportRowBean.getTransitionRelief());
        	newRow.createCell(13).setCellValue(reportRowBean.getIsAuthoritative());
        	newRow.createCell(14).setCellValue(reportRowBean.getUnionRuleType());
        	newRow.createCell(15).setCellValue(reportRowBean.getNonUnionRuleType());
        }
        
		try{
        	String fileName = commonUtil.buildUploadExcelFileName(argParams);
        	System.out.println("FileName Built with aegument params : " + fileName);
        	logger.info("ERCoverageReportExcelBuilder :: FileName Built with aegument params : " + fileName);
        	
        	FileOutputStream outputStream = new FileOutputStream(reportsPath+"/"+fileName);
        	
        	workbook.write(outputStream);
            workbook.close();
            
        } catch(FileNotFoundException fe) {
        	logger.error(" ERCoverageReportExcelBuilder :: Error while Building the Excel Report file : ", fe);
        } catch(Exception e) {
        	logger.error(" ERCoverageReportExcelBuilder :: Error while Building the Excel Report file : ", e);
        	}finally {
	        	workbook = null;
	        	sheet = null;
	        	style = null;
	        }
		
		}
		
		// Process ZIP the generated reports - with the Directory Name generated for Reports
				List<String> fileList = new ArrayList<String>(); 
				String sourceFolderPath = pathArr[0]+"/reportsData/LegalEntitiesReports/"+forderNameTimeStampString;
				String outputZipFileName = sourceFolderPath + ".zip";
						
				fileList = commonUtil.generateFileList(reportsDirectory, fileList, sourceFolderPath);
				folderZipUtil.zipIt(outputZipFileName, sourceFolderPath, fileList,forderNameTimeStampString);
				
				return reportsPath;
	}
	
	public Map<String, List<LegalEntitiesReportDataVO>> processReportsMapByControlGroup(List<?> reportsList, List<String> controlGroupList) {
		Map<String, List<LegalEntitiesReportDataVO>> reportsMapByControlGroup = new HashMap<String, List<LegalEntitiesReportDataVO>>();
		for(String controlGroupName : controlGroupList) {
			List<LegalEntitiesReportDataVO> reportList = new ArrayList<LegalEntitiesReportDataVO>();
			for(Object objRef : reportsList) {
				LegalEntitiesReportDataVO nhnftReportObj = (LegalEntitiesReportDataVO)objRef;
				if(controlGroupName.equalsIgnoreCase(nhnftReportObj.getControlGroup())) {
					reportList.add(nhnftReportObj);
				}
			}
			reportsMapByControlGroup.put(controlGroupName, reportList);
		}
		return reportsMapByControlGroup;
	}
}
