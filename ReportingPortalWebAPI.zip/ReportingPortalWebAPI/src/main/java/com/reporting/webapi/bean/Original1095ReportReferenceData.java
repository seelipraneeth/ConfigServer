package com.reporting.webapi.bean;

import java.util.List;

public class Original1095ReportReferenceData {

	private List<String> controlGroupList;
	
	private List<String> taxYearList;

	public List<String> getControlGroupList() {
		return controlGroupList;
	}

	public void setControlGroupList(List<String> controlGroupList) {
		this.controlGroupList = controlGroupList;
	}

	public List<String> getTaxYearList() {
		return taxYearList;
	}

	public void setTaxYearList(List<String> taxYearList) {
		this.taxYearList = taxYearList;
	}
	
}
