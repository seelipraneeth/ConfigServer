
package com.reporting.webapi.adapter;

import java.util.List;

import com.reporting.webapi.bean.InsuranceServiceReferanceDataBean;
import com.reporting.webapi.response.vo.InsuranceReportDataVO;

public interface IInsuranceReportAdapter {
	public InsuranceServiceReferanceDataBean getInsuranceServiceReferenceData()throws Exception;
	public List<InsuranceReportDataVO> getInsuranceReportData(String taxYear,String controlGroup) throws Exception;
}
