package com.reporting.webapi.bean;

import java.util.List;

public class AcaDataSetReferenceData {

	private List<String> controlGroupList;
	private List<String> sourceCodeList;
	private List<String> employerNameList;
	
	public List<String> getControlGroupList() {
		return controlGroupList;
	}
	public void setControlGroupList(List<String> controlGroupList) {
		this.controlGroupList = controlGroupList;
	}
	public List<String> getSourceCodeList() {
		return sourceCodeList;
	}
	public void setSourceCodeList(List<String> sourceCodeList) {
		this.sourceCodeList = sourceCodeList;
	}
	public List<String> getEmployerNameList() {
		return employerNameList;
	}
	public void setEmployerNameList(List<String> employerNameList) {
		this.employerNameList = employerNameList;
	}
	
	
}
