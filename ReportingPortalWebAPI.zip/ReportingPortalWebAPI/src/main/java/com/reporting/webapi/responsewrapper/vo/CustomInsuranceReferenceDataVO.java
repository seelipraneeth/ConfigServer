

package com.reporting.webapi.responsewrapper.vo;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.reporting.webapi.response.vo.InsuranceReferanceDataVO;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class CustomInsuranceReferenceDataVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private InsuranceReferanceDataVO insuranceReferanceData;

	public InsuranceReferanceDataVO getInsuranceReferanceData() {
		return insuranceReferanceData;
	}

	public void setInsuranceReferanceData(InsuranceReferanceDataVO insuranceReferanceData) {
		this.insuranceReferanceData = insuranceReferanceData;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	

	
	
	

}
