package com.reporting.webapi.responsewrapper.vo;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.reporting.webapi.response.vo.AcaDataSetServiceReportDataVO;

@XmlRootElement(name = "customtAcaDataSetServiceReportDataVO")
@XmlAccessorType(XmlAccessType.FIELD)
public class CustomtAcaDataSetServiceReportDataVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private List<AcaDataSetServiceReportDataVO> acaDataSetServiceReportDataVO;

	public List<AcaDataSetServiceReportDataVO> getAcaDataSetServiceReportDataVO() {
		return acaDataSetServiceReportDataVO;
	}

	public void setAcaDataSetServiceReportDataVO(List<AcaDataSetServiceReportDataVO> acaDataSetServiceReportDataVO) {
		this.acaDataSetServiceReportDataVO = acaDataSetServiceReportDataVO;
	}
	
	
}
