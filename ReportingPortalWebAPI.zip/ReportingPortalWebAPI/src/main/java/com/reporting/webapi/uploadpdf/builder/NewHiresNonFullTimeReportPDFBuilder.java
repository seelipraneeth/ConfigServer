package com.reporting.webapi.uploadpdf.builder;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.itextpdf.text.Document;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.tool.xml.XMLWorkerHelper;
import com.reporting.webapi.response.vo.ReportsByWeeksCountVO;
import com.reporting.webapi.util.CommonUtil;
import com.reporting.webapi.util.FolderZipUtil;

@Component
public class NewHiresNonFullTimeReportPDFBuilder {

	private final Logger logger = Logger
			.getLogger(NewHiresNonFullTimeReportPDFBuilder.class);

	public static final String HTML_PDF_TEMPLATE = "/htmlToPDF_template/InitialMeasurementPeriodHTMLTemplateForPDF.html";

	@Autowired
	private CommonUtil commonUtil;

	@Autowired
	private FolderZipUtil folderZipUtil;

	public String processPDFContent(
			Map<String, List<ReportsByWeeksCountVO>> reportsMapByControlGroup,
			String[] argParams) throws UnsupportedEncodingException {

		Document document = null;
		PdfWriter writer = null;
		Set<String> keySetValues = reportsMapByControlGroup.keySet();

		String forderNameTimeStampString = new SimpleDateFormat("yyyyMMddHHmmsss").format(new Date());
		String path = this.getClass().getClassLoader().getResource("").getPath();
		String fullPath = URLDecoder.decode(path, "UTF-8");

		String pathArr[] = fullPath.split("/WEB-INF/classes/");
		String reportsPath = pathArr[0] + "/reportsData/NewHiresNonFullTimePDFReports/"+ forderNameTimeStampString;

		File reportsDirectory = new File(reportsPath);
		if (!reportsDirectory.exists()) {
			try {
				reportsDirectory.mkdirs();
			} catch (SecurityException se) {
				logger.error("NewHiresNonFullTimeReportPDFBuilder#processPDFContent :: Error while creating the required Directory : ",se);
			}
		}

		// Read Template
		String htmlTemplateContent = "";
		try {
			htmlTemplateContent = commonUtil.readFileContent(HTML_PDF_TEMPLATE);
		} catch (IOException ioe) {
			logger.error("NewHiresNonFullTimeReportPDFBuilder#processPDFContent :: Error while reading the template file : ",ioe);
		}		
		
		String workYears = argParams[0].replaceAll(":", ", ");
		argParams[0]=argParams[0].replaceAll(":", "_");
		
		for (String reportMapKey : keySetValues) {
			// Retrieving the ReportList specific to the ControlGroup matching
			// reportMapKey
			List<ReportsByWeeksCountVO> reportsList = reportsMapByControlGroup.get(reportMapKey);
			int reportsCount = reportsList.size();
			// Set the Control Group Name to controlGroup param in argParams
			argParams[2] = reportMapKey;
			// insert values in template
			String htmlContent = "";
			htmlContent += htmlTemplateContent;		
			htmlContent = htmlContent.replaceAll("%%WORK_YEAR%%", workYears);
			htmlContent = htmlContent.replaceAll("%%CONTROL_GROUP%%",reportMapKey);
			htmlContent = htmlContent.replaceAll("%%REPORT_COUNT%%",String.valueOf(reportsCount));
			htmlContent = htmlContent.replaceAll("%%REPORT_SERACH_CRITERIA%%",reportMapKey);
			
			// initialize document
			document = new Document(PageSize.A4);
			String fileName = "";

			try {
				fileName = commonUtil.buildUploadPDFFileName(argParams);
				logger.info("NewHiresNonFullTimeReportPDFBuilder#processPDFContent :: FileName Built with argument params : " + fileName);
				// initialize pdfwriter
				writer = PdfWriter.getInstance(document, new FileOutputStream(reportsPath + "/" + fileName));
				logger.info("NewHiresNonFullTimeReportPDFBuilder#processPDFContent :: 'Document', 'PdfWriter' have been initialized ");
				document.open();
				ByteArrayInputStream bis = new ByteArrayInputStream(htmlContent.getBytes());
				XMLWorkerHelper.getInstance().parseXHtml(writer, document, bis);

			} catch (FileNotFoundException fe) {
				logger.error("NewHiresNonFullTimeReportPDFBuilder#processPDFContent :: Error while Building the pdf Report file : ", fe);
			} catch (Exception e) {
				logger.error("NewHiresNonFullTimeReportPDFBuilder#processPDFContent :: Error while Building the pdf Report file : ", e);
			} finally {
				document.close();
			}

		}

		// Process ZIP the generated reports - with the Directory Name generated
		// for Reports
		List<String> fileList = new ArrayList<String>();
		String sourceFolderPath = pathArr[0] + "/reportsData/NewHiresNonFullTimePDFReports/" + forderNameTimeStampString;
		String outputZipFileName = sourceFolderPath + ".zip";
		fileList = commonUtil.generateFileList(reportsDirectory, fileList, sourceFolderPath);
		folderZipUtil.zipIt(outputZipFileName, sourceFolderPath, fileList, forderNameTimeStampString);

		return reportsPath;
	}

	public Map<String, List<ReportsByWeeksCountVO>> processReportsMapByControlGroup(
			List<?> reportsList, List<String> controlGroupList) {
		Map<String, List<ReportsByWeeksCountVO>> reportsMapByControlGroup = new HashMap<String, List<ReportsByWeeksCountVO>>();
		if (CollectionUtils.isNotEmpty(controlGroupList)) {
			for (String controlGroupName : controlGroupList) {
				List<ReportsByWeeksCountVO> reportList = new ArrayList<ReportsByWeeksCountVO>();
				for (Object objRef : reportsList) {
					ReportsByWeeksCountVO reportsByWeeksCountData = (ReportsByWeeksCountVO) objRef;
					if(reportsByWeeksCountData.getCONTROL_GROUP().equalsIgnoreCase(controlGroupName))
						reportList.add(reportsByWeeksCountData);
				}
				reportsMapByControlGroup.put(controlGroupName, reportList);
			}
		}
		return reportsMapByControlGroup;
	}
}
