package com.reporting.webapi.util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.StringTokenizer;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

@Component
public class CommonUtil {

	private final Logger logger = Logger.getLogger(CommonUtil.class);
	
	private final String ENCODING="UTF-8";
	
	/**
	 * Method to build Excel FileName
	 * @param argParams
	 * @return
	 */
	public String buildUploadExcelFileName(String[] argParams) {
		StringBuilder fileName = new StringBuilder();
		for(String param : argParams) {
			if(null != param && param.length() > 0 && !(param.contains("\\") || param.contains("/"))){
				logger.info("Excel File added :: " + fileName);
				fileName = fileName.append(param).append("_");
			}
		}
		
		// Adding Current System TimeStamp to fileName
		String dateTimeStampString = new SimpleDateFormat("yyyyMMddHHmmsss").format(new Date());
		fileName.append(dateTimeStampString);
		
		// Appending .xlsx extension to fileName
		fileName.append(".xlsx");
		
		return fileName.toString();
	}
	
	public List<String> generateFileList(File node, List<String> fileList, String sourceFolderPath) {
		// add file only
		if (node.isFile()) {
			logger.info(" generateFileList method :: File added to fileList :: " + node.toString());
			fileList.add(generateZipEntry(node.toString(), sourceFolderPath));
		}
		
		if (node.isDirectory()) {
			String[] subNode = node.list();
			for (String filename : subNode) {
				generateFileList(new File(node, filename), fileList, sourceFolderPath);
			}
		}
		return fileList;
	}

	private String generateZipEntry(String file, String sourceFolderPath) {
		logger.info(" generateZipEntry method :: Value for File :: " + file);
		logger.info(" generateZipEntry method :: Value for sourceFolderPath :: " + sourceFolderPath);
		return file.substring(sourceFolderPath.length(), file.length());
	}

	
	
	/*public void initializeWorkBookDetails(XSSFWorkbook workbook, XSSFSheet sheet, XSSFCellStyle style) {
		
		// initialize work book
		workbook = new XSSFWorkbook();
		
		// initialize sheet
		sheet = workbook.createSheet("Sheet1");
		
		sheet.setDefaultColumnWidth(30);
		
		XSSFCellStyle headerCellStyle = workbook.createCellStyle();
        XSSFFont boldFont = workbook.createFont();
        boldFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
        headerCellStyle.setFont(boldFont);
        
        style = workbook.createCellStyle();
        XSSFFont font = workbook.createFont();
        
        font.setFontName("Arial");
        style.setFillForegroundColor(IndexedColors.BLUE.getIndex());
        style.setFillPattern(CellStyle.SOLID_FOREGROUND);
        font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
        font.setColor(IndexedColors.WHITE.getIndex());
        style.setFont(font);
        
        logger.info(" ReportsExcelBuilderUtil :: 'workbook', 'sheet' and 'style' have been initialized ");
	}*/
	
	public List<String> getSelectedControlGroupList(String controlGroupValue) {
		List<String> selectedControlGroupList = new ArrayList<>();
		if(StringUtils.isNotBlank(controlGroupValue)) {
			StringTokenizer st = new StringTokenizer(controlGroupValue, ":");
			while(st.hasMoreTokens()) {
				String cgToken = st.nextToken();
				selectedControlGroupList.add(cgToken);
			}
		} else {
			selectedControlGroupList.add(controlGroupValue);
		}
		
		return selectedControlGroupList;
	}
	
	public Date parseDateInput(String dateInput) {
		Date date = null;
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		try{
			date = sdf.parse(dateInput);
		}catch(Exception e){
			logger.error("Error while fetching parseDateToMilliSeconds : " + e.getMessage());
		}
		return date;
	}
	
	public int getDatesDiffInMonths(Calendar startCalendar, Calendar endCalendar) {
		int diffYear = endCalendar.get(Calendar.YEAR) - startCalendar.get(Calendar.YEAR);
		return diffYear * 12 + endCalendar.get(Calendar.MONTH) - startCalendar.get(Calendar.MONTH);
	}
	
	
	/**
	 * Method to build PDF FileName
	 * @param argParams
	 * @return
	 */
	public String buildUploadPDFFileName(String[] argParams) {
		StringBuilder fileName = new StringBuilder();
		for(String param : argParams) {
			if(null != param && param.length() > 0 && !(param.contains("\\") || param.contains("/"))){
				logger.info("PDF File added :: " + fileName);
				fileName = fileName.append(param).append("_");
			}
		}
		
		// Adding Current System TimeStamp to fileName
		String dateTimeStampString = new SimpleDateFormat("yyyyMMddHHmmsss").format(new Date());
		fileName.append(dateTimeStampString);
		
		// Appending .xlsx extension to fileName
		fileName.append(".pdf");
		
		return fileName.toString();
	}
	
	public String readFileContent(String filePath) throws IOException{
		
		String fileContent="";
		
		InputStream inputStream= getClass().getClassLoader().getResourceAsStream(filePath);
		StringWriter writer = new StringWriter();
		IOUtils.copy(inputStream, writer, ENCODING);
		fileContent = writer.toString();

		return fileContent;
	}
}
