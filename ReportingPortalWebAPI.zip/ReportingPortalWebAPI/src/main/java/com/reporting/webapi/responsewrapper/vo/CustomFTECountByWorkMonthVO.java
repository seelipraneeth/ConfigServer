package com.reporting.webapi.responsewrapper.vo;

import java.io.Serializable;
import java.util.List;

import com.reporting.webapi.response.vo.FTECountByWorkMonthVO;

public class CustomFTECountByWorkMonthVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private List<FTECountByWorkMonthVO> fteCountByWorkMonthList;

	public List<FTECountByWorkMonthVO> getFteCountByWorkMonthList() {
		return fteCountByWorkMonthList;
	}

	public void setFteCountByWorkMonthList(List<FTECountByWorkMonthVO> fteCountByWorkMonthList) {
		this.fteCountByWorkMonthList = fteCountByWorkMonthList;
	}
	
	
}
