package com.reporting.webapi.util;


public class CommonConstants {
	
	public static final String APPLICATION_ZIP = "application/zip";
	
	//Query Params
	public static final String WORK_YEAR = "WorkYear";
	public static final String TAX_YEAR = "TaxYear";
	public static final String WORK_MONTH = "WorkMonth";
	public static final String CONTROL_GROUP = "ControlGroup";
	public static final String WEEK_STARTING = "WeekStarting";
	public static final String WEEK_ENDING = "WeekEnding";
	public static final String PARENT_COMPANY = "ParentCompnay";
	public static final String PRODUCTION_COMPANY = "Proudctioncompany";
	public static final String PAYROLL_COMPANY = "PayrollCompany";
	public static final String UNION_STATUS = "UnionStatus";
	public static final String UNION_TYPE = "UnionType";
	public static final String TYPE_OF_HOURS = "TypeOfHours";
	public static final String EMPLOYEE_TYPE = "EmployeeType";
	public static final String REPORT_OF_WEEK = "ReportOfWeek";
	public static final String ACA_ELIGIBLE_COUNT = "AcaEligibleCount";
	public static final String MEASUREMENT_START_DATE = "MeasurementStartDate";
	public static final String MEASUREMENT_END_DATE = "MeasurementEndDate";
	public static final String AVERAGE_WEEKLY_HOURS = "AvgWeeklyHours";
	public static final String ANNUALIZED_MONTHLY_COUNT = "annualizedMonthlyCount";
	public static final String SOURCE_NAME = "SourceName";
	public static final String PROD_CO_NAME = "ProdCoName";
	public static final String PROD_SHOW_NAME = "ProdShowName";
	public static final String EMPLOYER_NAME = "EmployerName";
	public static final String SOURCE_CODE = "SourceCode";
	public static final String EMPLOYEE_NAME = "EmployeeName";
	public static final String HOURS_PAID = "HoursPaid";
	public static final String AVERAGE_WEEKLY_THRESHOLD = "AvgWeeklyThreshold";
	
	//Setting Report Name to Map
	public static final String NEW_HIRES_NON_FULL_TIME_REPORTS = "NewHiresNonFullTimeReport";
	public static final String NEW_HIRES_FULL_TIME_REPORTS = "NewHiresFullTimeReport";
	public static final String ON_GOING_REPORT = "OnGoingReport";
	public static final String ER_COVERAGE_REPORT = "ERCoverageReport";
	public static final String PAYROLL_DATA_ACTIVITY_REPORT = "PayrollDataActivityReport";
	public static final String BREAK_IN_REPORT = "BreakInReport";
	public static final String DEMO_GRAPHICS_REPORT = "DemographicsReport";
	public static final String ELIGIBILITY_REPORT = "EligibilityReport";
	public static final String DATA_ACA_PAYROLL_REPORT = "DataAcaPayrollServiceReport";
	public static final String LEGAL_ENTITIES_REPORT = "LegalEntitiesReport";
	public static final String INSURANCE_REPORT = "InsuranceReport";
	public static final String ACA_DATA_SET_REPORT = "AcaDataSetServiceReport";
	public static final String ER_COVERAGE_PDF_REPORT = "ERCoveragePDFReport";
	public static final String ORIGINAL_1095_REPORT = "Original1095Report";

	// New Hires Non FullTime Report Service Constants
	public static final String NEW_HIRES_NON_FULL_TIME_SERVICE = "/newhiresnonfulltimereportservice";
	public static final String NEW_HIRES_NON_FULL_TIME_SERVICE_REFERENCE_DATA = "/getNewHiresNonFullTimeReportReferenceData";
	public static final String NEW_HIRES_NON_FULL_TIME_SERVICE_COUNT_BY_WEEK = "/getNewHiresNonFullTimeCountByWeek";
	public static final String NEW_HIRES_NON_FULL_TIME_SERVICE_REPORT_DATA = "/getNewHiresNonFullTimeReportData";
	public static final String NEW_HIRES_NON_FULL_TIME_SERVICE_PROCESS_EXCEL_ZIP_DOWNLOAD = "/processnewhiresnonfulltimeexcelzipdownload";
	//Added By Praneeth -- start
		public static final String NEW_HIRES_NON_FULL_TIME_SERVICE_PROCESS_PDF_ZIP_DOWNLOAD = "/processNewHiresNonFullTimeReportPDFUpload";	
		public static final String NEW_HIRES_NON_FULL_TIME_PDF_REPORT = "NewHiresNonFullTimePDFReport";
		//Added By Praneeth -- end
		
	//New Hires FullTime Report Service Constants
	public static final String NEW_HIRES_FULL_TIME_SERVICE = "/newhiresfulltimereportservice";
	public static final String NEW_HIRES_FULL_TIME_SERVICE_REFERENCE_DATA = "/getNewHiresFullTimeReportReferenceData";
	public static final String NEW_HIRES_FULL_TIME_SERVICE_COUNT_BY_WEEK = "/getNewHiresFullTimeCountByWeek";
	public static final String NEW_HIRES_FULL_TIME_SERVICE_REPORT_DATA = "/getNewHiresFullTimeReportData";
	public static final String NEW_HIRES_FULL_TIME_SERVICE_PROCESS_EXCEL_ZIP_DOWNLOAD = "/processNewHireFullTimeExcelUpload";
	//Added By Praneeth -- start
	public static final String NEW_HIRES_FULL_TIME_SERVICE_PROCESS_PDF_ZIP_DOWNLOAD = "/processNewHiresFullTimeReportPDFUpload";	
	public static final String NEW_HIRES_FULL_TIME_PDF_REPORT = "NewHiresFullTimePDFReport";
	//Added By Praneeth -- end
	
	//On Going Report Service Constants
	public static final String ON_GOING_SERVICE = "/ongoingreportservice";
	public static final String ON_GOING_SERVICE_REFERENCE_DATA = "/getonGoingreportreferencedata";
	public static final String ON_GOING_SERVICE_COUNT_BY_WEEK = "/getOnGoingReportCountByWeek";
	public static final String ON_GOING_SERVICE_REPORT_DATA = "/getOnGoingReportReportData";
	public static final String ON_GOING_SERVICE_PROCESS_EXCEL_ZIP_DOWNLOAD = "/processOnGoingReportExcelUpload";
	public static final String ON_GOING_SERVICE_MEASUREMENT_DATE_BY_CONTROLGROUP = "/getMeasurementDatesByControlGroup";
	//Added By Praneeth -- start
		public static final String ON_GOING_SERVICE_PROCESS_PDF_ZIP_DOWNLOAD = "/processOnGoingReportPDFUpload";	
		public static final String ON_GOING_PDF_REPORT = "OnGoingPDFReport";
	//Added By Praneeth -- end
	//ER Coverage Report Service Constants
	public static final String ER_COVERAGE_SERVICE = "/ercoveragereportservice";
	public static final String ER_COVERAGE_SERVICE_REFERENCE_DATA = "/getERCoverageReportReferenceData";
	public static final String ER_COVERAGE_SERVICE_COUNT_BY_WEEK = "/getERCoverageReportCountByWeek";
	public static final String ER_COVERAGE_SERVICE_REPORT_DATA = "/getERCoverageReportData";
	public static final String ER_COVERAGE_SERVICE_PROCESS_EXCEL_ZIP_DOWNLOAD = "/processERCoverageReportExcelUpload";
	public static final String ER_COVERAGE_FTE_COUNT_BY_WORK_MONTH = "/getERCoverageFTECountByWorkMonth";
	public static final String ER_COVERAGE_SERVICE_PROCESS_PDF_ZIP_DOWNLOAD = "/processERCoverageReportPDFUpload";
	
	//Pay Roll Data Active Report Service Constants
	public static final String PAY_ROLL_DATA_ACTIVE_SERVICE = "/payrolldataactivityreportservice";
	public static final String PAY_ROLL_DATA_ACTIVE_SERVICE_REFERENCE_DATA = "/getPayrollDataActivityReportReferenceData";
	public static final String PAY_ROLL_DATA_ACTIVE_SERVICE_REPORT_DATA = "/getPayrollDataActivityReportData";
	public static final String PAY_ROLL_DATA_ACTIVE_SERVICE_PROCESS_EXCEL_ZIP_DOWNLOAD = "/processPayrollDataActivityReportExcelUpload";
	//Added By Praneeth -- start
	public static final String PAY_ROLL_DATA_ACTIVE_SERVICE_PROCESS_PDF_ZIP_DOWNLOAD = "/processPayrollDataActivityReportPDFUpload";	
	public static final String PAY_ROLL_DATA_ACTIVE_PDF_REPORT = "PayrollDataActivityPDFReport";
	//Added By Praneeth -- end
	//Break In Report Service Constants
	public static final String BREAK_IN_SERVICE = "/breakinreportservice";
	public static final String BREAK_IN_SERVICE_REFERENCE_DATA = "/getBreakInReportReferenceData";
	public static final String BREAK_IN_SERVICE_REPORT_DATA = "/getBreakInServiceReportData";
	public static final String BREAK_IN_SERVICE_PROCESS_EXCEL_ZIP_DOWNLOAD = "/processBreakInServiceReportExcelUpload";
	//Added By Praneeth -- start
	public static final String BREAK_IN_SERVICE_PROCESS_PDF_ZIP_DOWNLOAD = "/processBreakInReportPDFUpload";	
	public static final String BREAK_IN_PDF_REPORT = "BreakInPDFReport";
	//Added By Praneeth -- end
	
	//Eligibility Report Service Constants
	//Demo Graphics Report Service Constants
	public static final String DEMO_GRAPHICS_SERVICE = "/demographicsreportservice";
	public static final String DEMO_GRAPHICS_SERVICE_REFERENCE_DATA = "/getDemographicsReferenceData";
	public static final String DEMO_GRAPHICS_SERVICE_REPORT_DATA = "/getDemographicsReportData";
	public static final String DEMO_GRAPHICS_SERVICE_PROCESS_EXCEL_ZIP_DOWNLOAD = "/processDemographicsServiceReportExcelUpload";
	//Added By Praneeth -- start
		public static final String DEMO_GRAPHICS_SERVICE_PROCESS_PDF_ZIP_DOWNLOAD = "/processDemographicsReportPDFUpload";	
		public static final String DEMO_GRAPHICS_PDF_REPORT = "DemographicsPDFReport";
		//Added By Praneeth -- end
	//Eligibility Report Service Constants
	public static final String Eligibility_SERVICE = "/eligibilityreportservice";
	public static final String Eligibility_SERVICE_REFERENCE_DATA = "/getEligibilityReferenceData";
	public static final String Eligibility_SERVICE_REPORT_DATA = "/getEligibilityReportData";
	public static final String Eligibility_SERVICE_PROCESS_EXCEL_ZIP_DOWNLOAD = "/processEligibilityServiceReportExcelUpload";
	//Added By Praneeth -- start
	public static final String ELIGIBILITY_SERVICE_PROCESS_PDF_ZIP_DOWNLOAD = "/processEligibilityReportPDFUpload";	
	public static final String ELIGIBILITY_PDF_REPORT = "EligibilityPDFReport";
	//Added By Praneeth -- end
		
	//Eligibility Report Service Constants
	public static final String DATA_ACA_PAYROLL_SERVICE = "/dataacapayrollservice";
	public static final String DATA_ACA_PAYROLL_SERVICE_REFERENCE_DATA = "/getdataacapayrollservicereferencedata";
	public static final String DATA_ACA_PAYROLL_SERVICE_COUNT = "/getdataacapayrollservicecount";
	public static final String DATA_ACA_PAYROLL_SERVICE_REPORT_DATA = "/getdataacapayrollservicereportdata";
	public static final String DATA_ACA_PAYROLL_SERVICE_PROCESS_EXCEL_ZIP_DOWNLOAD = "/processdataacapayrollserviceexcelupload";

	// Legal Entities Report Service Constants
	public static final String LEGAL_ENTITIES_SERVICE = "/legalentitiesreportservice";
	public static final String LEGAL_ENTITIES_SERVICE_REFERENCE_DATA = "/getlegalentitiesreferencedata";
	public static final String LEGAL_ENTITIES_SERVICE_REPORT_DATA = "/getlegalentitiesreportdata";
	public static final String LEGAL_ENTITIES_SERVICE_PROCESS_EXCEL_ZIP_DOWNLOAD = "/processlegalentitiesserviceexcelupload";
	
	
	// Legal Entities Report Service Constants
	public static final String INSURANCE_SERVICE = "/insurancereportservice";
	public static final String INSURANCE_SERVICE_REFERENCE_DATA = "/getinsurancereferencedata";
	public static final String INSURANCE_SERVICE_REPORT_DATA = "/getinsurancereportdata";
	public static final String INSURANCE_SERVICE_PROCESS_EXCEL_ZIP_DOWNLOAD = "/processinsuranceserviceexcelupload";
		
		
	//ACA Data Set Service Constants
	public static final String ACA_DATASET_SERVICE = "/acadatasetservice";
	public static final String ACA_DATASET_SERVICE_REFERENCE_DATA = "/getacadatasetservicereferencedata";
	public static final String ACA_DATASET_SERVICE_COUNT = "/getacadatasetservicecount";
	public static final String ACA_DATASET_SERVICE_REPORT_DATA = "/geacadatasetservicereportdata";
	public static final String ACA_DATASET_SERVICE_PROCESS_EXCEL_ZIP_DOWNLOAD = "/processacadatasetserviceexcelupload";
	
	//Original 1095 Report Constants
	public static final String ORIGINAL_1095_SERVICE = "/original1095service";
	public static final String ORIGINAL_1095_REFERENCE_DATA = "/getoriginal1095reportreferencedata";
	public static final String ORIGINAL_1095_REPORT_DATA = "/getoriginal1095reportdata";
	public static final String ORIGINAL_1095_EXCEL_ZIP_DOWNLOAD = "/processoriginal1095reportexcelupload";
}
