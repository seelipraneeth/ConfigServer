package com.reporting.webapi.response.vo;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "LegalEntitiesReportData")
public class LegalEntitiesReportDataVO implements Serializable {

	@XmlElementWrapper(name = "TaxYear")
	@XmlElement(name = "TaxYear")
	private String taxYear;
	
	@XmlElementWrapper(name = "ControlGroup")
	@XmlElement(name = "ControlGroup")
	private String controlGroup;

	@XmlElementWrapper(name = "EmployerEIN")
	@XmlElement(name = "EmployerEIN")
	private String employerEIN;

	@XmlElementWrapper(name = "EmployerName")
	@XmlElement(name = "EmployerName")
	private String employerName;

	@XmlElementWrapper(name = "AddressLine1")
	@XmlElement(name = "AddressLine1")
	private String addressLine1;

	@XmlElementWrapper(name = "AddressLine2")
	@XmlElement(name = "AddressLine2")
	private String addressLine2;

	@XmlElementWrapper(name = "City")
	@XmlElement(name = "City")
	private String city;

	@XmlElementWrapper(name = "State")
	@XmlElement(name = "State")
	private String state;

	@XmlElementWrapper(name = "ZipCode")
	@XmlElement(name = "ZipCode")
	private String zipCode;

	@XmlElementWrapper(name = "ContactFirstName")
	@XmlElement(name = "ContactFirstName")
	private String contactFirstName;

	@XmlElementWrapper(name = "ContactLastName")
	@XmlElement(name = "ContactLastName")
	private String contactLastName;

	@XmlElementWrapper(name = "ContactPhone")
	@XmlElement(name = "ContactPhone")
	private String contactPhone;

	@XmlElementWrapper(name = "AverageWeeklyHours")
	@XmlElement(name = "AverageWeeklyHours")
	private String averageWeeklyHours;

	@XmlElementWrapper(name = "TransitionRelief")
	@XmlElement(name = "TransitionRelief")
	private String transitionRelief;

	@XmlElementWrapper(name = "IsAuthoritative")
	@XmlElement(name = "IsAuthoritative")
	private String isAuthoritative;

	@XmlElementWrapper(name = "UnionRuleType")
	@XmlElement(name = "UnionRuleType")
	private String unionRuleType;

	@XmlElementWrapper(name = "NonUnionRuleType")
	@XmlElement(name = "NonUnionRuleType")
	private String nonUnionRuleType;

	public String getControlGroup() {
		return controlGroup;
	}

	public void setControlGroup(String controlGroup) {
		this.controlGroup = controlGroup;
	}

	public String getTaxYear() {
		return taxYear;
	}

	public void setTaxYear(String taxYear) {
		this.taxYear = taxYear;
	}

	public String getEmployerEIN() {
		return employerEIN;
	}

	public void setEmployerEIN(String employerEIN) {
		this.employerEIN = employerEIN;
	}

	public String getEmployerName() {
		return employerName;
	}

	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getContactFirstName() {
		return contactFirstName;
	}

	public void setContactFirstName(String contactFirstName) {
		this.contactFirstName = contactFirstName;
	}

	public String getContactLastName() {
		return contactLastName;
	}

	public void setContactLastName(String contactLastName) {
		this.contactLastName = contactLastName;
	}

	public String getContactPhone() {
		return contactPhone;
	}

	public void setContactPhone(String contactPhone) {
		this.contactPhone = contactPhone;
	}

	public String getAverageWeeklyHours() {
		return averageWeeklyHours;
	}

	public void setAverageWeeklyHours(String averageWeeklyHours) {
		this.averageWeeklyHours = averageWeeklyHours;
	}

	public String getTransitionRelief() {
		return transitionRelief;
	}

	public void setTransitionRelief(String transitionRelief) {
		this.transitionRelief = transitionRelief;
	}

	public String getIsAuthoritative() {
		return isAuthoritative;
	}

	public void setIsAuthoritative(String isAuthoritative) {
		this.isAuthoritative = isAuthoritative;
	}

	public String getUnionRuleType() {
		return unionRuleType;
	}

	public void setUnionRuleType(String unionRuleType) {
		this.unionRuleType = unionRuleType;
	}

	public String getNonUnionRuleType() {
		return nonUnionRuleType;
	}

	public void setNonUnionRuleType(String nonUnionRuleType) {
		this.nonUnionRuleType = nonUnionRuleType;
	}

}
