package com.reporting.webapi.response.vo;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;

public class Original1095ReportDataVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@XmlElement(name = "employeeName")
	private String employeeName;
	
	@XmlElement(name = "employeeFirstName")
	private String employeeFirstName;

	@XmlElement(name = "employeeMiddleName")
	private String employeeMiddleName;

	@XmlElement(name = "employeeLastName")
	private String employeeLastName;

	@XmlElement(name = "employeeSSN")
	private String employeeSSN;

	@XmlElement(name = "employeeAddressLine1")
	private String employeeAddressLine1;

	@XmlElement(name = "employeeAddressLine2")
	private String employeeAddressLine2;

	@XmlElement(name = "employeeCity")
	private String employeeCity;

	@XmlElement(name = "employeeState")
	private String employeeState;

	@XmlElement(name = "employeeCountry")
	private String employeeCountry;

	@XmlElement(name = "employeeZip")
	private String employeeZip;

	@XmlElement(name = "employerName")
	private String employerName;

	@XmlElement(name = "employerFEIN")
	private String employerFEIN;

	@XmlElement(name = "employerAddressLine1")
	private String employerAddressLine1;

	@XmlElement(name = "employerAddressLine2")
	private String employerAddressLine2;

	@XmlElement(name = "employerAddressLine3")
	private String employerAddressLine3;

	@XmlElement(name = "employerContactPhone")
	private String employerContactPhone;

	@XmlElement(name = "employerCity")
	private String employerCity;

	@XmlElement(name = "employerState")
	private String employerState;

	@XmlElement(name = "employerCountry")
	private String employerCountry;

	@XmlElement(name = "employerZip")
	private String employerZip;

	@XmlElement(name = "selfInsuranceCoverage")
	private String selfInsuranceCoverage;

	@XmlElement(name = "controlGroup")
	private String controlGroup;

	@XmlElement(name = "taxYear")
	private String taxYear;

	@XmlElement(name = "line14AllMonths")
	private String line14AllMonths;

	@XmlElement(name = "line14Jan")
	private String line14Jan;

	@XmlElement(name = "line14Feb")
	private String line14Feb;

	@XmlElement(name = "line14Mar")
	private String line14Mar;

	@XmlElement(name = "line14Apr")
	private String line14Apr;

	@XmlElement(name = "line14May")
	private String line14May;

	@XmlElement(name = "line14June")
	private String line14June;

	@XmlElement(name = "line14July")
	private String line14July;

	@XmlElement(name = "line14Aug")
	private String line14Aug;

	@XmlElement(name = "line14Sept")
	private String line14Sept;

	@XmlElement(name = "line14Oct")
	private String line14Oct;

	@XmlElement(name = "line14Nov")
	private String line14Nov;

	@XmlElement(name = "line14Dec")
	private String line14Dec;

	@XmlElement(name = "line15AllMonths")
	private String line15AllMonths;

	@XmlElement(name = "line15Jan")
	private String line15Jan;

	@XmlElement(name = "line15Feb")
	private String line15Feb;

	@XmlElement(name = "line15Mar")
	private String line15Mar;

	@XmlElement(name = "line15Apr")
	private String line15Apr;

	@XmlElement(name = "line15May")
	private String line15May;

	@XmlElement(name = "line15June")
	private String line15June;

	@XmlElement(name = "line15July")
	private String line15July;

	@XmlElement(name = "line15Aug")
	private String line15Aug;

	@XmlElement(name = "line15Sept")
	private String line15Sept;

	@XmlElement(name = "line15Oct")
	private String line15Oct;

	@XmlElement(name = "line15Nov")
	private String line15Nov;

	@XmlElement(name = "line15Dec")
	private String line15Dec;

	@XmlElement(name = "line16AllMonths")
	private String line16AllMonths;

	@XmlElement(name = "line16Jan")
	private String line16Jan;

	@XmlElement(name = "line16Feb")
	private String line16Feb;

	@XmlElement(name = "line16Mar")
	private String line16Mar;

	@XmlElement(name = "line16Apr")
	private String line16Apr;

	@XmlElement(name = "line16May")
	private String line16May;

	@XmlElement(name = "line16June")
	private String line16June;

	@XmlElement(name = "line16July")
	private String line16July;

	@XmlElement(name = "line16Aug")
	private String line16Aug;

	@XmlElement(name = "line16Sept")
	private String line16Sept;

	@XmlElement(name = "line16Oct")
	private String line16Oct;

	@XmlElement(name = "line16Nov")
	private String line16Nov;

	@XmlElement(name = "line16Dec")
	private String line16Dec;

	@XmlElement(name = "line17FirstName")
	private String line17FirstName;

	@XmlElement(name = "line17LastName")
	private String line17LastName;

	@XmlElement(name = "line17SSN")
	private String line17SSN;

	@XmlElement(name = "line17DateOfBirth")
	private String line17DateOfBirth;

	@XmlElement(name = "line17AllMonths")
	private String line17AllMonths;

	@XmlElement(name = "line17Jan")
	private String line17Jan;

	@XmlElement(name = "line17Feb")
	private String line17Feb;

	@XmlElement(name = "line17Mar")
	private String line17Mar;

	@XmlElement(name = "line17Apr")
	private String line17Apr;

	@XmlElement(name = "line17May")
	private String line17May;

	@XmlElement(name = "line17June")
	private String line17June;

	@XmlElement(name = "line17July")
	private String line17July;

	@XmlElement(name = "line17Aug")
	private String line17Aug;

	@XmlElement(name = "line17Sept")
	private String line17Sept;

	@XmlElement(name = "line17Oct")
	private String line17Oct;

	@XmlElement(name = "line17Nov")
	private String line17Nov;

	@XmlElement(name = "line17Dec")
	private String line17Dec;

	@XmlElement(name = "line18FirstName")
	private String line18FirstName;

	@XmlElement(name = "line18LastName")
	private String line18LastName;

	@XmlElement(name = "line18SSN")
	private String line18SSN;

	@XmlElement(name = "line18DateOfBirth")
	private String line18DateOfBirth;

	@XmlElement(name = "line18AllMonths")
	private String line18AllMonths;

	@XmlElement(name = "line18Jan")
	private String line18Jan;

	@XmlElement(name = "line18Feb")
	private String line18Feb;

	@XmlElement(name = "line18Mar")
	private String line18Mar;

	@XmlElement(name = "line18Apr")
	private String line18Apr;

	@XmlElement(name = "line18May")
	private String line18May;

	@XmlElement(name = "line18June")
	private String line18June;

	@XmlElement(name = "line18July")
	private String line18July;

	@XmlElement(name = "line18Aug")
	private String line18Aug;

	@XmlElement(name = "line18Sept")
	private String line18Sept;

	@XmlElement(name = "line18Oct")
	private String line18Oct;

	@XmlElement(name = "line18Nov")
	private String line18Nov;

	@XmlElement(name = "line18Dec")
	private String line18Dec;

	@XmlElement(name = "line19FirstName")
	private String line19FirstName;

	@XmlElement(name = "line19LastName")
	private String line19LastName;

	@XmlElement(name = "line19SSN")
	private String line19SSN;

	@XmlElement(name = "line19DateOfBirth")
	private String line19DateOfBirth;

	@XmlElement(name = "line19AllMonths")
	private String line19AllMonths;

	@XmlElement(name = "line19Jan")
	private String line19Jan;

	@XmlElement(name = "line19Feb")
	private String line19Feb;

	@XmlElement(name = "line19Mar")
	private String line19Mar;

	@XmlElement(name = "line19Apr")
	private String line19Apr;

	@XmlElement(name = "line19May")
	private String line19May;

	@XmlElement(name = "line19June")
	private String line19June;

	@XmlElement(name = "line19July")
	private String line19July;

	@XmlElement(name = "line19Aug")
	private String line19Aug;

	@XmlElement(name = "line19Sept")
	private String line19Sept;

	@XmlElement(name = "line19Oct")
	private String line19Oct;

	@XmlElement(name = "line19Nov")
	private String line19Nov;

	@XmlElement(name = "line19Dec")
	private String line19Dec;

	@XmlElement(name = "line20FirstName")
	private String line20FirstName;

	@XmlElement(name = "line20LastName")
	private String line20LastName;

	@XmlElement(name = "line20SSN")
	private String line20SSN;

	@XmlElement(name = "line20DateOfBirth")
	private String line20DateOfBirth;

	@XmlElement(name = "line20AllMonths")
	private String line20AllMonths;

	@XmlElement(name = "line20Jan")
	private String line20Jan;

	@XmlElement(name = "line20Feb")
	private String line20Feb;

	@XmlElement(name = "line20Mar")
	private String line20Mar;

	@XmlElement(name = "line20Apr")
	private String line20Apr;

	@XmlElement(name = "line20May")
	private String line20May;

	@XmlElement(name = "line20June")
	private String line20June;

	@XmlElement(name = "line20July")
	private String line20July;

	@XmlElement(name = "line20Aug")
	private String line20Aug;

	@XmlElement(name = "line20Sept")
	private String line20Sept;

	@XmlElement(name = "line20Oct")
	private String line20Oct;

	@XmlElement(name = "line20Nov")
	private String line20Nov;

	@XmlElement(name = "line20Dec")
	private String line20Dec;

	@XmlElement(name = "line21FirstName")
	private String line21FirstName;

	@XmlElement(name = "line21LastName")
	private String line21LastName;

	@XmlElement(name = "line21SSN")
	private String line21SSN;

	@XmlElement(name = "line21DateOfBirth")
	private String line21DateOfBirth;

	@XmlElement(name = "line21AllMonths")
	private String line21AllMonths;

	@XmlElement(name = "line21Jan")
	private String line21Jan;

	@XmlElement(name = "line21Feb")
	private String line21Feb;

	@XmlElement(name = "line21Mar")
	private String line21Mar;

	@XmlElement(name = "line21Apr")
	private String line21Apr;

	@XmlElement(name = "line21May")
	private String line21May;

	@XmlElement(name = "line21June")
	private String line21June;

	@XmlElement(name = "line21July")
	private String line21July;

	@XmlElement(name = "line21Aug")
	private String line21Aug;

	@XmlElement(name = "line21Sept")
	private String line21Sept;

	@XmlElement(name = "line21Oct")
	private String line21Oct;

	@XmlElement(name = "line21Nov")
	private String line21Nov;

	@XmlElement(name = "line21Dec")
	private String line21Dec;

	@XmlElement(name = "line22FirstName")
	private String line22FirstName;

	@XmlElement(name = "line22LastName")
	private String line22LastName;

	@XmlElement(name = "line22SSN")
	private String line22SSN;

	@XmlElement(name = "line22DateOfBirth")
	private String line22DateOfBirth;

	@XmlElement(name = "line22AllMonths")
	private String line22AllMonths;

	@XmlElement(name = "line22Jan")
	private String line22Jan;

	@XmlElement(name = "line22Feb")
	private String line22Feb;

	@XmlElement(name = "line22Mar")
	private String line22Mar;

	@XmlElement(name = "line22Apr")
	private String line22Apr;

	@XmlElement(name = "line22May")
	private String line22May;

	@XmlElement(name = "line22June")
	private String line22June;

	@XmlElement(name = "line22July")
	private String line22July;

	@XmlElement(name = "line22Aug")
	private String line22Aug;

	@XmlElement(name = "line22Sept")
	private String line22Sept;

	@XmlElement(name = "line22Oct")
	private String line22Oct;

	@XmlElement(name = "line22Nov")
	private String line22Nov;

	@XmlElement(name = "line22Dec")
	private String line22Dec;

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getEmployeeFirstName() {
		return employeeFirstName;
	}

	public void setEmployeeFirstName(String employeeFirstName) {
		this.employeeFirstName = employeeFirstName;
	}

	public String getEmployeeMiddleName() {
		return employeeMiddleName;
	}

	public void setEmployeeMiddleName(String employeeMiddleName) {
		this.employeeMiddleName = employeeMiddleName;
	}

	public String getEmployeeLastName() {
		return employeeLastName;
	}

	public void setEmployeeLastName(String employeeLastName) {
		this.employeeLastName = employeeLastName;
	}

	public String getEmployeeSSN() {
		return employeeSSN;
	}

	public void setEmployeeSSN(String employeeSSN) {
		this.employeeSSN = employeeSSN;
	}

	public String getEmployeeAddressLine1() {
		return employeeAddressLine1;
	}

	public void setEmployeeAddressLine1(String employeeAddressLine1) {
		this.employeeAddressLine1 = employeeAddressLine1;
	}

	public String getEmployeeAddressLine2() {
		return employeeAddressLine2;
	}

	public void setEmployeeAddressLine2(String employeeAddressLine2) {
		this.employeeAddressLine2 = employeeAddressLine2;
	}

	public String getEmployeeCity() {
		return employeeCity;
	}

	public void setEmployeeCity(String employeeCity) {
		this.employeeCity = employeeCity;
	}

	public String getEmployeeState() {
		return employeeState;
	}

	public void setEmployeeState(String employeeState) {
		this.employeeState = employeeState;
	}

	public String getEmployeeCountry() {
		return employeeCountry;
	}

	public void setEmployeeCountry(String employeeCountry) {
		this.employeeCountry = employeeCountry;
	}

	public String getEmployeeZip() {
		return employeeZip;
	}

	public void setEmployeeZip(String employeeZip) {
		this.employeeZip = employeeZip;
	}

	public String getEmployerName() {
		return employerName;
	}

	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}

	public String getEmployerFEIN() {
		return employerFEIN;
	}

	public void setEmployerFEIN(String employerFEIN) {
		this.employerFEIN = employerFEIN;
	}

	public String getEmployerAddressLine1() {
		return employerAddressLine1;
	}

	public void setEmployerAddressLine1(String employerAddressLine1) {
		this.employerAddressLine1 = employerAddressLine1;
	}

	public String getEmployerAddressLine2() {
		return employerAddressLine2;
	}

	public void setEmployerAddressLine2(String employerAddressLine2) {
		this.employerAddressLine2 = employerAddressLine2;
	}

	public String getEmployerAddressLine3() {
		return employerAddressLine3;
	}

	public void setEmployerAddressLine3(String employerAddressLine3) {
		this.employerAddressLine3 = employerAddressLine3;
	}

	public String getEmployerContactPhone() {
		return employerContactPhone;
	}

	public void setEmployerContactPhone(String employerContactPhone) {
		this.employerContactPhone = employerContactPhone;
	}

	public String getEmployerCity() {
		return employerCity;
	}

	public void setEmployerCity(String employerCity) {
		this.employerCity = employerCity;
	}

	public String getEmployerState() {
		return employerState;
	}

	public void setEmployerState(String employerState) {
		this.employerState = employerState;
	}

	public String getEmployerCountry() {
		return employerCountry;
	}

	public void setEmployerCountry(String employerCountry) {
		this.employerCountry = employerCountry;
	}

	public String getEmployerZip() {
		return employerZip;
	}

	public void setEmployerZip(String employerZip) {
		this.employerZip = employerZip;
	}

	public String getSelfInsuranceCoverage() {
		return selfInsuranceCoverage;
	}

	public void setSelfInsuranceCoverage(String selfInsuranceCoverage) {
		this.selfInsuranceCoverage = selfInsuranceCoverage;
	}

	public String getControlGroup() {
		return controlGroup;
	}

	public void setControlGroup(String controlGroup) {
		this.controlGroup = controlGroup;
	}

	public String getTaxYear() {
		return taxYear;
	}

	public void setTaxYear(String taxYear) {
		this.taxYear = taxYear;
	}

	public String getLine14AllMonths() {
		return line14AllMonths;
	}

	public void setLine14AllMonths(String line14AllMonths) {
		this.line14AllMonths = line14AllMonths;
	}

	public String getLine14Jan() {
		return line14Jan;
	}

	public void setLine14Jan(String line14Jan) {
		this.line14Jan = line14Jan;
	}

	public String getLine14Feb() {
		return line14Feb;
	}

	public void setLine14Feb(String line14Feb) {
		this.line14Feb = line14Feb;
	}

	public String getLine14Mar() {
		return line14Mar;
	}

	public void setLine14Mar(String line14Mar) {
		this.line14Mar = line14Mar;
	}

	public String getLine14Apr() {
		return line14Apr;
	}

	public void setLine14Apr(String line14Apr) {
		this.line14Apr = line14Apr;
	}

	public String getLine14May() {
		return line14May;
	}

	public void setLine14May(String line14May) {
		this.line14May = line14May;
	}

	public String getLine14June() {
		return line14June;
	}

	public void setLine14June(String line14June) {
		this.line14June = line14June;
	}

	public String getLine14July() {
		return line14July;
	}

	public void setLine14July(String line14July) {
		this.line14July = line14July;
	}

	public String getLine14Aug() {
		return line14Aug;
	}

	public void setLine14Aug(String line14Aug) {
		this.line14Aug = line14Aug;
	}

	public String getLine14Sept() {
		return line14Sept;
	}

	public void setLine14Sept(String line14Sept) {
		this.line14Sept = line14Sept;
	}

	public String getLine14Oct() {
		return line14Oct;
	}

	public void setLine14Oct(String line14Oct) {
		this.line14Oct = line14Oct;
	}

	public String getLine14Nov() {
		return line14Nov;
	}

	public void setLine14Nov(String line14Nov) {
		this.line14Nov = line14Nov;
	}

	public String getLine14Dec() {
		return line14Dec;
	}

	public void setLine14Dec(String line14Dec) {
		this.line14Dec = line14Dec;
	}

	public String getLine15AllMonths() {
		return line15AllMonths;
	}

	public void setLine15AllMonths(String line15AllMonths) {
		this.line15AllMonths = line15AllMonths;
	}

	public String getLine15Jan() {
		return line15Jan;
	}

	public void setLine15Jan(String line15Jan) {
		this.line15Jan = line15Jan;
	}

	public String getLine15Feb() {
		return line15Feb;
	}

	public void setLine15Feb(String line15Feb) {
		this.line15Feb = line15Feb;
	}

	public String getLine15Mar() {
		return line15Mar;
	}

	public void setLine15Mar(String line15Mar) {
		this.line15Mar = line15Mar;
	}

	public String getLine15Apr() {
		return line15Apr;
	}

	public void setLine15Apr(String line15Apr) {
		this.line15Apr = line15Apr;
	}

	public String getLine15May() {
		return line15May;
	}

	public void setLine15May(String line15May) {
		this.line15May = line15May;
	}

	public String getLine15June() {
		return line15June;
	}

	public void setLine15June(String line15June) {
		this.line15June = line15June;
	}

	public String getLine15July() {
		return line15July;
	}

	public void setLine15July(String line15July) {
		this.line15July = line15July;
	}

	public String getLine15Aug() {
		return line15Aug;
	}

	public void setLine15Aug(String line15Aug) {
		this.line15Aug = line15Aug;
	}

	public String getLine15Sept() {
		return line15Sept;
	}

	public void setLine15Sept(String line15Sept) {
		this.line15Sept = line15Sept;
	}

	public String getLine15Oct() {
		return line15Oct;
	}

	public void setLine15Oct(String line15Oct) {
		this.line15Oct = line15Oct;
	}

	public String getLine15Nov() {
		return line15Nov;
	}

	public void setLine15Nov(String line15Nov) {
		this.line15Nov = line15Nov;
	}

	public String getLine15Dec() {
		return line15Dec;
	}

	public void setLine15Dec(String line15Dec) {
		this.line15Dec = line15Dec;
	}

	public String getLine16AllMonths() {
		return line16AllMonths;
	}

	public void setLine16AllMonths(String line16AllMonths) {
		this.line16AllMonths = line16AllMonths;
	}

	public String getLine16Jan() {
		return line16Jan;
	}

	public void setLine16Jan(String line16Jan) {
		this.line16Jan = line16Jan;
	}

	public String getLine16Feb() {
		return line16Feb;
	}

	public void setLine16Feb(String line16Feb) {
		this.line16Feb = line16Feb;
	}

	public String getLine16Mar() {
		return line16Mar;
	}

	public void setLine16Mar(String line16Mar) {
		this.line16Mar = line16Mar;
	}

	public String getLine16Apr() {
		return line16Apr;
	}

	public void setLine16Apr(String line16Apr) {
		this.line16Apr = line16Apr;
	}

	public String getLine16May() {
		return line16May;
	}

	public void setLine16May(String line16May) {
		this.line16May = line16May;
	}

	public String getLine16June() {
		return line16June;
	}

	public void setLine16June(String line16June) {
		this.line16June = line16June;
	}

	public String getLine16July() {
		return line16July;
	}

	public void setLine16July(String line16July) {
		this.line16July = line16July;
	}

	public String getLine16Aug() {
		return line16Aug;
	}

	public void setLine16Aug(String line16Aug) {
		this.line16Aug = line16Aug;
	}

	public String getLine16Sept() {
		return line16Sept;
	}

	public void setLine16Sept(String line16Sept) {
		this.line16Sept = line16Sept;
	}

	public String getLine16Oct() {
		return line16Oct;
	}

	public void setLine16Oct(String line16Oct) {
		this.line16Oct = line16Oct;
	}

	public String getLine16Nov() {
		return line16Nov;
	}

	public void setLine16Nov(String line16Nov) {
		this.line16Nov = line16Nov;
	}

	public String getLine16Dec() {
		return line16Dec;
	}

	public void setLine16Dec(String line16Dec) {
		this.line16Dec = line16Dec;
	}

	public String getLine17FirstName() {
		return line17FirstName;
	}

	public void setLine17FirstName(String line17FirstName) {
		this.line17FirstName = line17FirstName;
	}

	public String getLine17LastName() {
		return line17LastName;
	}

	public void setLine17LastName(String line17LastName) {
		this.line17LastName = line17LastName;
	}

	public String getLine17SSN() {
		return line17SSN;
	}

	public void setLine17SSN(String line17ssn) {
		line17SSN = line17ssn;
	}

	public String getLine17DateOfBirth() {
		return line17DateOfBirth;
	}

	public void setLine17DateOfBirth(String line17DateOfBirth) {
		this.line17DateOfBirth = line17DateOfBirth;
	}

	public String getLine17AllMonths() {
		return line17AllMonths;
	}

	public void setLine17AllMonths(String line17AllMonths) {
		this.line17AllMonths = line17AllMonths;
	}

	public String getLine17Jan() {
		return line17Jan;
	}

	public void setLine17Jan(String line17Jan) {
		this.line17Jan = line17Jan;
	}

	public String getLine17Feb() {
		return line17Feb;
	}

	public void setLine17Feb(String line17Feb) {
		this.line17Feb = line17Feb;
	}

	public String getLine17Mar() {
		return line17Mar;
	}

	public void setLine17Mar(String line17Mar) {
		this.line17Mar = line17Mar;
	}

	public String getLine17Apr() {
		return line17Apr;
	}

	public void setLine17Apr(String line17Apr) {
		this.line17Apr = line17Apr;
	}

	public String getLine17May() {
		return line17May;
	}

	public void setLine17May(String line17May) {
		this.line17May = line17May;
	}

	public String getLine17June() {
		return line17June;
	}

	public void setLine17June(String line17June) {
		this.line17June = line17June;
	}

	public String getLine17July() {
		return line17July;
	}

	public void setLine17July(String line17July) {
		this.line17July = line17July;
	}

	public String getLine17Aug() {
		return line17Aug;
	}

	public void setLine17Aug(String line17Aug) {
		this.line17Aug = line17Aug;
	}

	public String getLine17Sept() {
		return line17Sept;
	}

	public void setLine17Sept(String line17Sept) {
		this.line17Sept = line17Sept;
	}

	public String getLine17Oct() {
		return line17Oct;
	}

	public void setLine17Oct(String line17Oct) {
		this.line17Oct = line17Oct;
	}

	public String getLine17Nov() {
		return line17Nov;
	}

	public void setLine17Nov(String line17Nov) {
		this.line17Nov = line17Nov;
	}

	public String getLine17Dec() {
		return line17Dec;
	}

	public void setLine17Dec(String line17Dec) {
		this.line17Dec = line17Dec;
	}

	public String getLine18FirstName() {
		return line18FirstName;
	}

	public void setLine18FirstName(String line18FirstName) {
		this.line18FirstName = line18FirstName;
	}

	public String getLine18LastName() {
		return line18LastName;
	}

	public void setLine18LastName(String line18LastName) {
		this.line18LastName = line18LastName;
	}

	public String getLine18SSN() {
		return line18SSN;
	}

	public void setLine18SSN(String line18ssn) {
		line18SSN = line18ssn;
	}

	public String getLine18DateOfBirth() {
		return line18DateOfBirth;
	}

	public void setLine18DateOfBirth(String line18DateOfBirth) {
		this.line18DateOfBirth = line18DateOfBirth;
	}

	public String getLine18AllMonths() {
		return line18AllMonths;
	}

	public void setLine18AllMonths(String line18AllMonths) {
		this.line18AllMonths = line18AllMonths;
	}

	public String getLine18Jan() {
		return line18Jan;
	}

	public void setLine18Jan(String line18Jan) {
		this.line18Jan = line18Jan;
	}

	public String getLine18Feb() {
		return line18Feb;
	}

	public void setLine18Feb(String line18Feb) {
		this.line18Feb = line18Feb;
	}

	public String getLine18Mar() {
		return line18Mar;
	}

	public void setLine18Mar(String line18Mar) {
		this.line18Mar = line18Mar;
	}

	public String getLine18Apr() {
		return line18Apr;
	}

	public void setLine18Apr(String line18Apr) {
		this.line18Apr = line18Apr;
	}

	public String getLine18May() {
		return line18May;
	}

	public void setLine18May(String line18May) {
		this.line18May = line18May;
	}

	public String getLine18June() {
		return line18June;
	}

	public void setLine18June(String line18June) {
		this.line18June = line18June;
	}

	public String getLine18July() {
		return line18July;
	}

	public void setLine18July(String line18July) {
		this.line18July = line18July;
	}

	public String getLine18Aug() {
		return line18Aug;
	}

	public void setLine18Aug(String line18Aug) {
		this.line18Aug = line18Aug;
	}

	public String getLine18Sept() {
		return line18Sept;
	}

	public void setLine18Sept(String line18Sept) {
		this.line18Sept = line18Sept;
	}

	public String getLine18Oct() {
		return line18Oct;
	}

	public void setLine18Oct(String line18Oct) {
		this.line18Oct = line18Oct;
	}

	public String getLine18Nov() {
		return line18Nov;
	}

	public void setLine18Nov(String line18Nov) {
		this.line18Nov = line18Nov;
	}

	public String getLine18Dec() {
		return line18Dec;
	}

	public void setLine18Dec(String line18Dec) {
		this.line18Dec = line18Dec;
	}

	public String getLine19FirstName() {
		return line19FirstName;
	}

	public void setLine19FirstName(String line19FirstName) {
		this.line19FirstName = line19FirstName;
	}

	public String getLine19LastName() {
		return line19LastName;
	}

	public void setLine19LastName(String line19LastName) {
		this.line19LastName = line19LastName;
	}

	public String getLine19SSN() {
		return line19SSN;
	}

	public void setLine19SSN(String line19ssn) {
		line19SSN = line19ssn;
	}

	public String getLine19DateOfBirth() {
		return line19DateOfBirth;
	}

	public void setLine19DateOfBirth(String line19DateOfBirth) {
		this.line19DateOfBirth = line19DateOfBirth;
	}

	public String getLine19AllMonths() {
		return line19AllMonths;
	}

	public void setLine19AllMonths(String line19AllMonths) {
		this.line19AllMonths = line19AllMonths;
	}

	public String getLine19Jan() {
		return line19Jan;
	}

	public void setLine19Jan(String line19Jan) {
		this.line19Jan = line19Jan;
	}

	public String getLine19Feb() {
		return line19Feb;
	}

	public void setLine19Feb(String line19Feb) {
		this.line19Feb = line19Feb;
	}

	public String getLine19Mar() {
		return line19Mar;
	}

	public void setLine19Mar(String line19Mar) {
		this.line19Mar = line19Mar;
	}

	public String getLine19Apr() {
		return line19Apr;
	}

	public void setLine19Apr(String line19Apr) {
		this.line19Apr = line19Apr;
	}

	public String getLine19May() {
		return line19May;
	}

	public void setLine19May(String line19May) {
		this.line19May = line19May;
	}

	public String getLine19June() {
		return line19June;
	}

	public void setLine19June(String line19June) {
		this.line19June = line19June;
	}

	public String getLine19July() {
		return line19July;
	}

	public void setLine19July(String line19July) {
		this.line19July = line19July;
	}

	public String getLine19Aug() {
		return line19Aug;
	}

	public void setLine19Aug(String line19Aug) {
		this.line19Aug = line19Aug;
	}

	public String getLine19Sept() {
		return line19Sept;
	}

	public void setLine19Sept(String line19Sept) {
		this.line19Sept = line19Sept;
	}

	public String getLine19Oct() {
		return line19Oct;
	}

	public void setLine19Oct(String line19Oct) {
		this.line19Oct = line19Oct;
	}

	public String getLine19Nov() {
		return line19Nov;
	}

	public void setLine19Nov(String line19Nov) {
		this.line19Nov = line19Nov;
	}

	public String getLine19Dec() {
		return line19Dec;
	}

	public void setLine19Dec(String line19Dec) {
		this.line19Dec = line19Dec;
	}

	public String getLine20FirstName() {
		return line20FirstName;
	}

	public void setLine20FirstName(String line20FirstName) {
		this.line20FirstName = line20FirstName;
	}

	public String getLine20LastName() {
		return line20LastName;
	}

	public void setLine20LastName(String line20LastName) {
		this.line20LastName = line20LastName;
	}

	public String getLine20SSN() {
		return line20SSN;
	}

	public void setLine20SSN(String line20ssn) {
		line20SSN = line20ssn;
	}

	public String getLine20DateOfBirth() {
		return line20DateOfBirth;
	}

	public void setLine20DateOfBirth(String line20DateOfBirth) {
		this.line20DateOfBirth = line20DateOfBirth;
	}

	public String getLine20AllMonths() {
		return line20AllMonths;
	}

	public void setLine20AllMonths(String line20AllMonths) {
		this.line20AllMonths = line20AllMonths;
	}

	public String getLine20Jan() {
		return line20Jan;
	}

	public void setLine20Jan(String line20Jan) {
		this.line20Jan = line20Jan;
	}

	public String getLine20Feb() {
		return line20Feb;
	}

	public void setLine20Feb(String line20Feb) {
		this.line20Feb = line20Feb;
	}

	public String getLine20Mar() {
		return line20Mar;
	}

	public void setLine20Mar(String line20Mar) {
		this.line20Mar = line20Mar;
	}

	public String getLine20Apr() {
		return line20Apr;
	}

	public void setLine20Apr(String line20Apr) {
		this.line20Apr = line20Apr;
	}

	public String getLine20May() {
		return line20May;
	}

	public void setLine20May(String line20May) {
		this.line20May = line20May;
	}

	public String getLine20June() {
		return line20June;
	}

	public void setLine20June(String line20June) {
		this.line20June = line20June;
	}

	public String getLine20July() {
		return line20July;
	}

	public void setLine20July(String line20July) {
		this.line20July = line20July;
	}

	public String getLine20Aug() {
		return line20Aug;
	}

	public void setLine20Aug(String line20Aug) {
		this.line20Aug = line20Aug;
	}

	public String getLine20Sept() {
		return line20Sept;
	}

	public void setLine20Sept(String line20Sept) {
		this.line20Sept = line20Sept;
	}

	public String getLine20Oct() {
		return line20Oct;
	}

	public void setLine20Oct(String line20Oct) {
		this.line20Oct = line20Oct;
	}

	public String getLine20Nov() {
		return line20Nov;
	}

	public void setLine20Nov(String line20Nov) {
		this.line20Nov = line20Nov;
	}

	public String getLine20Dec() {
		return line20Dec;
	}

	public void setLine20Dec(String line20Dec) {
		this.line20Dec = line20Dec;
	}

	public String getLine21FirstName() {
		return line21FirstName;
	}

	public void setLine21FirstName(String line21FirstName) {
		this.line21FirstName = line21FirstName;
	}

	public String getLine21LastName() {
		return line21LastName;
	}

	public void setLine21LastName(String line21LastName) {
		this.line21LastName = line21LastName;
	}

	public String getLine21SSN() {
		return line21SSN;
	}

	public void setLine21SSN(String line21ssn) {
		line21SSN = line21ssn;
	}

	public String getLine21DateOfBirth() {
		return line21DateOfBirth;
	}

	public void setLine21DateOfBirth(String line21DateOfBirth) {
		this.line21DateOfBirth = line21DateOfBirth;
	}

	public String getLine21AllMonths() {
		return line21AllMonths;
	}

	public void setLine21AllMonths(String line21AllMonths) {
		this.line21AllMonths = line21AllMonths;
	}

	public String getLine21Jan() {
		return line21Jan;
	}

	public void setLine21Jan(String line21Jan) {
		this.line21Jan = line21Jan;
	}

	public String getLine21Feb() {
		return line21Feb;
	}

	public void setLine21Feb(String line21Feb) {
		this.line21Feb = line21Feb;
	}

	public String getLine21Mar() {
		return line21Mar;
	}

	public void setLine21Mar(String line21Mar) {
		this.line21Mar = line21Mar;
	}

	public String getLine21Apr() {
		return line21Apr;
	}

	public void setLine21Apr(String line21Apr) {
		this.line21Apr = line21Apr;
	}

	public String getLine21May() {
		return line21May;
	}

	public void setLine21May(String line21May) {
		this.line21May = line21May;
	}

	public String getLine21June() {
		return line21June;
	}

	public void setLine21June(String line21June) {
		this.line21June = line21June;
	}

	public String getLine21July() {
		return line21July;
	}

	public void setLine21July(String line21July) {
		this.line21July = line21July;
	}

	public String getLine21Aug() {
		return line21Aug;
	}

	public void setLine21Aug(String line21Aug) {
		this.line21Aug = line21Aug;
	}

	public String getLine21Sept() {
		return line21Sept;
	}

	public void setLine21Sept(String line21Sept) {
		this.line21Sept = line21Sept;
	}

	public String getLine21Oct() {
		return line21Oct;
	}

	public void setLine21Oct(String line21Oct) {
		this.line21Oct = line21Oct;
	}

	public String getLine21Nov() {
		return line21Nov;
	}

	public void setLine21Nov(String line21Nov) {
		this.line21Nov = line21Nov;
	}

	public String getLine21Dec() {
		return line21Dec;
	}

	public void setLine21Dec(String line21Dec) {
		this.line21Dec = line21Dec;
	}

	public String getLine22FirstName() {
		return line22FirstName;
	}

	public void setLine22FirstName(String line22FirstName) {
		this.line22FirstName = line22FirstName;
	}

	public String getLine22LastName() {
		return line22LastName;
	}

	public void setLine22LastName(String line22LastName) {
		this.line22LastName = line22LastName;
	}

	public String getLine22SSN() {
		return line22SSN;
	}

	public void setLine22SSN(String line22ssn) {
		line22SSN = line22ssn;
	}

	public String getLine22DateOfBirth() {
		return line22DateOfBirth;
	}

	public void setLine22DateOfBirth(String line22DateOfBirth) {
		this.line22DateOfBirth = line22DateOfBirth;
	}

	public String getLine22AllMonths() {
		return line22AllMonths;
	}

	public void setLine22AllMonths(String line22AllMonths) {
		this.line22AllMonths = line22AllMonths;
	}

	public String getLine22Jan() {
		return line22Jan;
	}

	public void setLine22Jan(String line22Jan) {
		this.line22Jan = line22Jan;
	}

	public String getLine22Feb() {
		return line22Feb;
	}

	public void setLine22Feb(String line22Feb) {
		this.line22Feb = line22Feb;
	}

	public String getLine22Mar() {
		return line22Mar;
	}

	public void setLine22Mar(String line22Mar) {
		this.line22Mar = line22Mar;
	}

	public String getLine22Apr() {
		return line22Apr;
	}

	public void setLine22Apr(String line22Apr) {
		this.line22Apr = line22Apr;
	}

	public String getLine22May() {
		return line22May;
	}

	public void setLine22May(String line22May) {
		this.line22May = line22May;
	}

	public String getLine22June() {
		return line22June;
	}

	public void setLine22June(String line22June) {
		this.line22June = line22June;
	}

	public String getLine22July() {
		return line22July;
	}

	public void setLine22July(String line22July) {
		this.line22July = line22July;
	}

	public String getLine22Aug() {
		return line22Aug;
	}

	public void setLine22Aug(String line22Aug) {
		this.line22Aug = line22Aug;
	}

	public String getLine22Sept() {
		return line22Sept;
	}

	public void setLine22Sept(String line22Sept) {
		this.line22Sept = line22Sept;
	}

	public String getLine22Oct() {
		return line22Oct;
	}

	public void setLine22Oct(String line22Oct) {
		this.line22Oct = line22Oct;
	}

	public String getLine22Nov() {
		return line22Nov;
	}

	public void setLine22Nov(String line22Nov) {
		this.line22Nov = line22Nov;
	}

	public String getLine22Dec() {
		return line22Dec;
	}

	public void setLine22Dec(String line22Dec) {
		this.line22Dec = line22Dec;
	}

}
