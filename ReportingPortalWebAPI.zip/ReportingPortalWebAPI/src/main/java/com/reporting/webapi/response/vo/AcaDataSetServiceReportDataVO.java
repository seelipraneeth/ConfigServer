package com.reporting.webapi.response.vo;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;

public class AcaDataSetServiceReportDataVO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@XmlElement(name = "controlGroupName")
	private String controlGroupName;

	@XmlElement(name = "employerName")
	private String employerName;
	
	@XmlElement(name = "employerFederalTaxID")
	private String employerFederalTaxID;
	
	@XmlElement(name = "ssn")
	private String ssn;
	
	@XmlElement(name = "employeeName")
	private String employeeName;
	
	@XmlElement(name = "employeeFirstName")
	private String employeeFirstName;
	
	@XmlElement(name = "employeeLastName")
	private String employeeLastName;
	
	@XmlElement(name = "sourceCode")
	private String sourceCode;
	
	@XmlElement(name = "hoursPaid")
	private String hoursPaid;
	
	@XmlElement(name = "firstPayPeriodStartDate")
	private String firstPayPeriodStartDate;
	
	@XmlElement(name = "employmentStatus")
	private String employmentStatus;
	
	@XmlElement(name = "acaEmploymentStatus")
	private String acaEmploymentStatus;
	
	@XmlElement(name = "benefitsEnrollmentStatus")
	private String benefitsEnrollmentStatus;
	
	@XmlElement(name = "unionStatus")
	private String unionStatus;
	
	@XmlElement(name = "hrsFilename")
	private String hrsFilename;
	
	@XmlElement(name = "insFilename")
	private String insFilename;

	public String getControlGroupName() {
		return controlGroupName;
	}

	public void setControlGroupName(String controlGroupName) {
		this.controlGroupName = controlGroupName;
	}

	public String getEmployerName() {
		return employerName;
	}

	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}

	public String getEmployerFederalTaxID() {
		return employerFederalTaxID;
	}

	public void setEmployerFederalTaxID(String employerFederalTaxID) {
		this.employerFederalTaxID = employerFederalTaxID;
	}

	public String getSsn() {
		return ssn;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public String getEmployeeFirstName() {
		return employeeFirstName;
	}

	public void setEmployeeFirstName(String employeeFirstName) {
		this.employeeFirstName = employeeFirstName;
	}

	public String getEmployeeLastName() {
		return employeeLastName;
	}

	public void setEmployeeLastName(String employeeLastName) {
		this.employeeLastName = employeeLastName;
	}

	public String getSourceCode() {
		return sourceCode;
	}

	public void setSourceCode(String sourceCode) {
		this.sourceCode = sourceCode;
	}

	public String getHoursPaid() {
		return hoursPaid;
	}

	public void setHoursPaid(String hoursPaid) {
		this.hoursPaid = hoursPaid;
	}

	public String getFirstPayPeriodStartDate() {
		return firstPayPeriodStartDate;
	}

	public void setFirstPayPeriodStartDate(String firstPayPeriodStartDate) {
		this.firstPayPeriodStartDate = firstPayPeriodStartDate;
	}

	public String getEmploymentStatus() {
		return employmentStatus;
	}

	public void setEmploymentStatus(String employmentStatus) {
		this.employmentStatus = employmentStatus;
	}

	public String getAcaEmploymentStatus() {
		return acaEmploymentStatus;
	}

	public void setAcaEmploymentStatus(String acaEmploymentStatus) {
		this.acaEmploymentStatus = acaEmploymentStatus;
	}

	public String getBenefitsEnrollmentStatus() {
		return benefitsEnrollmentStatus;
	}

	public void setBenefitsEnrollmentStatus(String benefitsEnrollmentStatus) {
		this.benefitsEnrollmentStatus = benefitsEnrollmentStatus;
	}

	public String getUnionStatus() {
		return unionStatus;
	}

	public void setUnionStatus(String unionStatus) {
		this.unionStatus = unionStatus;
	}

	public String getHrsFilename() {
		return hrsFilename;
	}

	public void setHrsFilename(String hrsFilename) {
		this.hrsFilename = hrsFilename;
	}

	public String getInsFilename() {
		return insFilename;
	}

	public void setInsFilename(String insFilename) {
		this.insFilename = insFilename;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	
	
}
