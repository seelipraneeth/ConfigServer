package com.reporting.webapi.uploadpdf.builder;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.itextpdf.text.Document;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.tool.xml.XMLWorkerHelper;
import com.reporting.webapi.response.vo.DemoGraphicsReportDataVO;
import com.reporting.webapi.util.CommonUtil;
import com.reporting.webapi.util.FolderZipUtil;

@Component
public class DemographicsReportPDFBuilder {

	private final Logger logger = Logger
			.getLogger(DemographicsReportPDFBuilder.class);

	public static final String HTML_PDF_TEMPLATE = "/htmlToPDF_template/DemographicsHTMLTemplateForPDF.html";

	@Autowired
	private CommonUtil commonUtil;

	@Autowired
	private FolderZipUtil folderZipUtil;

	public String processPDFContent(
			Map<String, List<DemoGraphicsReportDataVO>> reportsMapByControlGroup,
			String[] argParams) throws UnsupportedEncodingException {

		Document document = null;
		PdfWriter writer = null;
		Set<String> keySetValues = reportsMapByControlGroup.keySet();

		String forderNameTimeStampString = new SimpleDateFormat("yyyyMMddHHmmsss").format(new Date());
		String path = this.getClass().getClassLoader().getResource("").getPath();
		String fullPath = URLDecoder.decode(path, "UTF-8");

		String pathArr[] = fullPath.split("/WEB-INF/classes/");
		String reportsPath = pathArr[0] + "/reportsData/DemographicsPDFReport/"+ forderNameTimeStampString;

		File reportsDirectory = new File(reportsPath);
		if (!reportsDirectory.exists()) {
			try {
				reportsDirectory.mkdirs();
			} catch (SecurityException se) {
				logger.error("DemographicsReportPDFBuilder#processPDFContent :: Error while creating the required Directory : ",se);
			}
		}

		// Read Template
		String htmlTemplateContent = "";
		try {
			htmlTemplateContent = commonUtil.readFileContent(HTML_PDF_TEMPLATE);
		} catch (IOException ioe) {
			logger.error("DemographicsReportPDFBuilder#processPDFContent :: Error while reading the template file : ",ioe);
		}		
		
		String workYears = argParams[0].replaceAll(":", ", ");
		argParams[0]=argParams[0].replaceAll(":", "_");
		
		for (String reportMapKey : keySetValues) {

			// Retrieving the ReportList specific to the ControlGroup matching
			// reportMapKey
			List<DemoGraphicsReportDataVO> reportsList = reportsMapByControlGroup.get(reportMapKey);
			
			int reportsCount = reportsList.size();

			// Set the Control Group Name to controlGroup param in argParams
			argParams[1] = reportMapKey;

			// insert values in template
			String htmlContent = "";
			htmlContent += htmlTemplateContent;		
			htmlContent = htmlContent.replaceAll("%%WORK_YEAR%%", workYears);
			htmlContent = htmlContent.replaceAll("%%CONTROL_GROUP%%",reportMapKey);
			htmlContent = htmlContent.replaceAll("%%REPORT_COUNT%%",String.valueOf(reportsCount));
			htmlContent = htmlContent.replaceAll("%%REPORT_SERACH_CRITERIA%%",reportMapKey);
			
			// initialize document
			document = new Document(PageSize.A4);
			String fileName = "";

			try {
				fileName = commonUtil.buildUploadPDFFileName(argParams);
				logger.info("DemographicsReportPDFBuilder#processPDFContent :: FileName Built with argument params : "
						+ fileName);
				// initialize pdfwriter
				writer = PdfWriter.getInstance(document, new FileOutputStream(
						reportsPath + "/" + fileName));

				logger.info("DemographicsReportPDFBuilder#processPDFContent :: 'Document', 'PdfWriter' have been initialized ");

				document.open();
				ByteArrayInputStream bis = new ByteArrayInputStream(
						htmlContent.getBytes());
				XMLWorkerHelper.getInstance().parseXHtml(writer, document, bis);

			} catch (FileNotFoundException fe) {
				logger.error(
						"DemographicsReportPDFBuilder#processPDFContent :: Error while Building the pdf Report file : ",
						fe);
			} catch (Exception e) {
				logger.error(
						"DemographicsReportPDFBuilder#processPDFContent :: Error while Building the pdf Report file : ",
						e);
			} finally {
				document.close();
			}

		}

		// Process ZIP the generated reports - with the Directory Name generated
		// for Reports
		List<String> fileList = new ArrayList<String>();
		String sourceFolderPath = pathArr[0] + "/reportsData/DemographicsPDFReport/" + forderNameTimeStampString;
		String outputZipFileName = sourceFolderPath + ".zip";
		fileList = commonUtil.generateFileList(reportsDirectory, fileList, sourceFolderPath);
		folderZipUtil.zipIt(outputZipFileName, sourceFolderPath, fileList, forderNameTimeStampString);
		return reportsPath;
	}

	public Map<String, List<DemoGraphicsReportDataVO>> processReportsMapByControlGroup(
			List<?> reportsList, List<String> controlGroupList) {
		Map<String, List<DemoGraphicsReportDataVO>> reportsMapByControlGroup = new HashMap<String, List<DemoGraphicsReportDataVO>>();
		if (CollectionUtils.isNotEmpty(controlGroupList)) {
			for (String controlGroupName : controlGroupList) {
				List<DemoGraphicsReportDataVO> reportList = new ArrayList<DemoGraphicsReportDataVO>();
				for (Object objRef : reportsList) {
					DemoGraphicsReportDataVO demoGraphicsReportDataVO = (DemoGraphicsReportDataVO) objRef;
					if(demoGraphicsReportDataVO.getControlGroup().equalsIgnoreCase(controlGroupName))
						reportList.add(demoGraphicsReportDataVO);
				}
				reportsMapByControlGroup.put(controlGroupName, reportList);
			}
		}
		return reportsMapByControlGroup;
	}
}
