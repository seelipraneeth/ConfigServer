package com.reporting.webapi.dao;

import java.util.List;

import com.reporting.webapi.bean.AcaDataSetReferenceData;
import com.reporting.webapi.response.vo.AcaDataSetServiceDataCountVO;
import com.reporting.webapi.response.vo.AcaDataSetServiceReportDataVO;

public interface IAcaDataSetServiceDao {

	public AcaDataSetReferenceData getAcaDataSetServiceReferenceData();
	
	public List<AcaDataSetServiceDataCountVO> getAcaDataSetServiceDataCount(String controlGroup, String employerName, String sourceCode, String employeeName, String hoursPaid);
	
	public List<AcaDataSetServiceReportDataVO> getAcaDataSetServiceReportData(String controlGroup, String employerName, String sourceCode, String employeeName, String hoursPaid);
}
