package com.reporting.webapi.adapter.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.reporting.webapi.adapter.ILegalEntitiesReportAdapter;
import com.reporting.webapi.bean.LegalEntitiesServiceReferanceDataBean;
import com.reporting.webapi.dao.ILegalEntitiesReportDao;
import com.reporting.webapi.response.vo.LegalEntitiesReportDataVO;

@Service
public class LegalEntitiesReportAdapterImpl implements ILegalEntitiesReportAdapter {

	private final Logger logger = Logger.getLogger(LegalEntitiesReportAdapterImpl.class);

	@Autowired
	private ILegalEntitiesReportDao legalEntitiesReportDao;
	
	@Override
	public LegalEntitiesServiceReferanceDataBean getLegalEntitiesServiceReferenceData() throws Exception {
		if(logger.isDebugEnabled()){
			logger.debug("START :: LegalEntitiesReportAdapterImpl : getLegalEntitiesServiceReferenceData : Method to getLegalEntitiesServiceReferenceData");
		}
		LegalEntitiesServiceReferanceDataBean legalEntitiesServiceReferanceDataBean = legalEntitiesReportDao.getLegalEntitiesServiceReferenceData();
		if(logger.isDebugEnabled()){
			logger.debug("END :: LegalEntitiesReportAdapterImpl : getLegalEntitiesServiceReferenceData : Method to getLegalEntitiesServiceReferenceData");
		}
		return legalEntitiesServiceReferanceDataBean;
	}
	
	
	@Override
	public List<LegalEntitiesReportDataVO> getLegalEntitiesReportData(String taxYear,String controlGroup) throws Exception {
		if(logger.isDebugEnabled()){
			logger.debug("START :: LegalEntitiesReportAdapterImpl : getLegalEntitiesReportData : Method to getLegalEntitiesReportData");
		}
		List<LegalEntitiesReportDataVO> legalEntitiesReportDataVO = legalEntitiesReportDao.getLegalEntitiesReportData(taxYear,controlGroup);
		if(logger.isDebugEnabled()){
			logger.debug("END :: LegalEntitiesReportAdapterImpl : getLegalEntitiesReportData : Method to getLegalEntitiesReportData");
		}
		return legalEntitiesReportDataVO;
	}
	
	
}
