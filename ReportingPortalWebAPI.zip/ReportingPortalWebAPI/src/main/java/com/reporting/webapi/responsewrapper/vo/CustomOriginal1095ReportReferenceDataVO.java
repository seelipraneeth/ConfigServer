package com.reporting.webapi.responsewrapper.vo;

import java.io.Serializable;

import com.reporting.webapi.response.vo.Original1095ReportReferenceDataVO;

public class CustomOriginal1095ReportReferenceDataVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Original1095ReportReferenceDataVO original1095ReportReferenceDataVO;

	public Original1095ReportReferenceDataVO getOriginal1095ReportReferenceDataVO() {
		return original1095ReportReferenceDataVO;
	}

	public void setOriginal1095ReportReferenceDataVO(Original1095ReportReferenceDataVO original1095ReportReferenceDataVO) {
		this.original1095ReportReferenceDataVO = original1095ReportReferenceDataVO;
	}
	
	
}
