package com.reporting.webapi.responsewrapper.vo;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.reporting.webapi.response.vo.AcaDataSetReferenceDataVO;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class CustomAcaDataSetServiceReferenceDataVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private AcaDataSetReferenceDataVO acaDataSetReferenceDataVO;

	public AcaDataSetReferenceDataVO getAcaDataSetReferenceDataVO() {
		return acaDataSetReferenceDataVO;
	}

	public void setAcaDataSetReferenceDataVO(AcaDataSetReferenceDataVO acaDataSetReferenceDataVO) {
		this.acaDataSetReferenceDataVO = acaDataSetReferenceDataVO;
	}
	
	
	
}
