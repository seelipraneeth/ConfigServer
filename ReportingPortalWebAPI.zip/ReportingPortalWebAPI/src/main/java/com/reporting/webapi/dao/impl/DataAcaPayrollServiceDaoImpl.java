package com.reporting.webapi.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import com.reporting.webapi.bean.DataAcaPayrollReferenceData;
import com.reporting.webapi.dao.IDataAcaPayrollServiceDao;
import com.reporting.webapi.response.vo.DataAcaPayrollServiceDataCountVO;
import com.reporting.webapi.response.vo.DataAcaPayrollServiceReportDataVO;

@Repository
public class DataAcaPayrollServiceDaoImpl implements IDataAcaPayrollServiceDao{

	private final Logger logger = Logger.getLogger(DataAcaPayrollServiceDaoImpl.class);
	
	@Resource(name = "sessionFactory")
	private SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	@Override
	public DataAcaPayrollReferenceData getDataAcaPayrollServiceReferenceData() {
		if(logger.isDebugEnabled()){
			logger.debug("START :: DataAcaPayrollServiceDaoImpl : getDataAcaPayrollServiceReferenceData : Method to getDataAcaPayrollServiceReferenceData");
		}
		Session session = sessionFactory.openSession();
		DataAcaPayrollReferenceData dataAcaPayrollReferenceData = new DataAcaPayrollReferenceData();
		
		try {
			Query taxYearQuery = session.getNamedQuery("PRC_DataAcaPayroll_GetTaxYear");
			dataAcaPayrollReferenceData.setTaxYearList(taxYearQuery.list());
			
			Query controlGroupQuery = session.getNamedQuery("PRC_DataAcaPayroll_GetControlGroup");
			dataAcaPayrollReferenceData.setControlGroupList(controlGroupQuery.list());
			
			Query sourceNameQuery = session.getNamedQuery("PRC_DataAcaPayroll_GetSourceName");
			dataAcaPayrollReferenceData.setSourceNameList(sourceNameQuery.list());
			
			Query prodCoNameQuery = session.getNamedQuery("PRC_DataAcaPayroll_GetProdCoName");
			dataAcaPayrollReferenceData.setProdCoNameList(prodCoNameQuery.list());
			
			Query prodShowQuery = session.getNamedQuery("PRC_DataAcaPayroll_GetProdShowName");
			dataAcaPayrollReferenceData.setProdShowNameList(prodShowQuery.list());
			
		} catch(Exception e) {
			logger.error("Error while fetching data getDataAcaPayrollServiceReferenceData : " + e.getMessage());
		}
		if(logger.isDebugEnabled()){
			logger.debug("END :: DataAcaPayrollServiceDaoImpl : getDataAcaPayrollServiceReferenceData : Method to getDataAcaPayrollServiceReferenceData");
		}
		return dataAcaPayrollReferenceData;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<DataAcaPayrollServiceDataCountVO> getDataAcaPayrollServiceDataCount(String taxYear, String controlGroup,
			String sourceName, String prodCoName, String prodShowName) {
		if (logger.isDebugEnabled()) {
			logger.debug(
					"START :: DataAcaPayrollServiceDaoImpl : getDataAcaPayrollServiceDataCount : Method to getDataAcaPayrollServiceDataCount");
		}
		Session session = sessionFactory.openSession();
		List<DataAcaPayrollServiceDataCountVO> list = null;
		List<DataAcaPayrollServiceDataCountVO> listVO = null;
		DataAcaPayrollServiceDataCountVO dataAcaPayrollServiceDataCountVO = null;
		try {
			Query query = session.getNamedQuery("PRC_DataAcaPayroll_DataCount");
			query.setParameter("taxYear", taxYear);
			query.setParameter("controlGroup", controlGroup);
			query.setParameter("sourceName", sourceName);
			query.setParameter("prodCoName", prodCoName);
			query.setParameter("prodShowName", prodShowName);
			list = query.list();

			if (list != null && list.size() > 0) {
				listVO = new ArrayList<DataAcaPayrollServiceDataCountVO>();
				for (Object dataAcaPayrollCount : list) {
					dataAcaPayrollServiceDataCountVO = new DataAcaPayrollServiceDataCountVO();
					if (null != dataAcaPayrollCount) {
						dataAcaPayrollServiceDataCountVO.setDataAcaPayrollCount(dataAcaPayrollCount.toString());
					}
					listVO.add(dataAcaPayrollServiceDataCountVO);
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching data getDataAcaPayrollServiceDataCount : " + e.getMessage());
		}
		if (logger.isDebugEnabled()) {
			logger.debug(
					"END :: DataAcaPayrollServiceDaoImpl : getDataAcaPayrollServiceDataCount : Method to getDataAcaPayrollServiceDataCount");
		}
		return listVO;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<DataAcaPayrollServiceReportDataVO> getDataAcaPayrollServiceReportData(String taxYear,
			String controlGroup, String sourceName, String prodCoName, String prodShowName) {
		if (logger.isDebugEnabled()) {
			logger.debug(
					"START :: DataAcaPayrollServiceDaoImpl : getDataAcaPayrollServiceReportData : Method to getDataAcaPayrollServiceReportData");
		}
		Session session = sessionFactory.openSession();
		List<DataAcaPayrollServiceReportDataVO> list = null;
		List<DataAcaPayrollServiceReportDataVO> listVO = null;
		DataAcaPayrollServiceReportDataVO dataAcaPayrollServiceReportData = null;
		try {
			Query query = session.getNamedQuery("PRC_DataAcaPayroll_ReportData");
			query.setParameter("taxYear", taxYear);
			query.setParameter("controlGroup", controlGroup);
			query.setParameter("sourceName", sourceName);
			query.setParameter("prodCoName", prodCoName);
			query.setParameter("prodShowName", prodShowName);
			list = query.list();
			
			if (list != null && list.size() > 0) {
				listVO = new ArrayList<DataAcaPayrollServiceReportDataVO>();
				for(Object obj : list) {
					dataAcaPayrollServiceReportData = new DataAcaPayrollServiceReportDataVO();
					
					Object[] column = (Object[]) obj;
					if (null != column[0]) {
						dataAcaPayrollServiceReportData.setSsn((column[0].toString()));
					}
					if (null != column[1]) {
						dataAcaPayrollServiceReportData.setFirstName((column[1].toString()));
					}
					if (null != column[2]) {
						dataAcaPayrollServiceReportData.setLastName((column[2].toString()));
					}
					if (null != column[3]) {
						dataAcaPayrollServiceReportData.setAddress((column[3].toString()));
					}
					if (null != column[4]) {
						dataAcaPayrollServiceReportData.setCity((column[4].toString()));
					}
					if (null != column[5]) {
						dataAcaPayrollServiceReportData.setState((column[5].toString()));
					}
					if (null != column[6]) {
						dataAcaPayrollServiceReportData.setBirthDate((column[6].toString()));
					}
					if (null != column[7]) {
						dataAcaPayrollServiceReportData.setFirstWorkedDate((column[7].toString()));
					}
					if (null != column[8]) {
						dataAcaPayrollServiceReportData.setLastWorkedDate((column[8].toString()));
					}
					if (null != column[9]) {
						dataAcaPayrollServiceReportData.setTerminationDate((column[9].toString()));
					}
					if (null != column[10]) {
						dataAcaPayrollServiceReportData.setPeriodEndingDate((column[10].toString()));
					}
					if (null != column[11]) {
						dataAcaPayrollServiceReportData.setHoursWorked((column[11].toString()));
					}
					if (null != column[12]) {
						dataAcaPayrollServiceReportData.setUnion((column[12].toString()));
					}
					if (null != column[13]) {
						dataAcaPayrollServiceReportData.setEmploymentStatus((column[13].toString()));
					}
					if (null != column[14]) {
						dataAcaPayrollServiceReportData.setControlGroup((column[14].toString()));
					}
					listVO.add(dataAcaPayrollServiceReportData);
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching data getDataAcaPayrollServiceReportData : " + e.getMessage());
		}
		if (logger.isDebugEnabled()) {
			logger.debug(
					"END :: DataAcaPayrollServiceDaoImpl : getDataAcaPayrollServiceReportData : Method to getDataAcaPayrollServiceReportData");
		}
		return listVO;
	}
	
	
}
