package com.reporting.webapi.uploadpdf.builder;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.itextpdf.text.Document;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.tool.xml.XMLWorkerHelper;
import com.reporting.webapi.response.vo.FTECountByWorkMonthVO;
import com.reporting.webapi.util.CommonUtil;
import com.reporting.webapi.util.FolderZipUtil;


@Component
public class ERCoverageReportPDFBuilder {

	private final Logger logger = Logger.getLogger(ERCoverageReportPDFBuilder.class);
	
	public static final String HTML_PDF_TEMPLATE = "/htmlToPDF_template/HTMLTemplateForPDF.html";

	@Autowired
	private CommonUtil commonUtil;
	
	@Autowired
	private FolderZipUtil folderZipUtil;
	
	public String processPDFContent(Map<String, List<FTECountByWorkMonthVO>> reportsMapByControlGroup, String[] argParams) throws UnsupportedEncodingException {
		
		Document document = null;
		PdfWriter writer = null;
		Set<String> keySetValues = reportsMapByControlGroup.keySet();
		
		String forderNameTimeStampString = new SimpleDateFormat("yyyyMMddHHmmsss").format(new Date());
		String path = this.getClass().getClassLoader().getResource("").getPath();
		String fullPath = URLDecoder.decode(path, "UTF-8");
		
		String pathArr[] = fullPath.split("/WEB-INF/classes/");
		String reportsPath = pathArr[0]+"/reportsData/ERCoveragePDFReports/"+forderNameTimeStampString;
		
		File reportsDirectory = new File(reportsPath);
		if(!reportsDirectory.exists()){
			try{
				reportsDirectory.mkdirs();
			} 
			catch(SecurityException se){
				logger.error(" processPDFContent :: Error while creating the required Directory : ", se);
			}      
		}
		
		//Read Template
		String htmlTemplateContent="";
		try {
			htmlTemplateContent = commonUtil.readFileContent(HTML_PDF_TEMPLATE);
		} catch (IOException ioe) {
			logger.error(" processExcelContent :: Error while reading the template file : ", ioe);
		}
		
		for(String reportMapKey : keySetValues) {

			// Retrieving the ReportList specific to the ControlGroup matching reportMapKey
			List<FTECountByWorkMonthVO> reportsList = reportsMapByControlGroup.get(reportMapKey);

			// Set the Control Group Name to controlGroup param in argParams
			argParams[1] = reportMapKey;
			
			// insert values in template
			String htmlContent="";
			htmlContent+=htmlTemplateContent;	
			htmlContent=htmlContent.replaceAll("%%TAX_YEAR%%", argParams[0]);
			htmlContent=htmlContent.replaceAll("%%NEXT_TAX_YEAR%%", (Integer.parseInt(argParams[0])+1)+"");
			htmlContent=htmlContent.replaceAll("%%PREVIOUS_TAX_YEAR%%", (Integer.parseInt(argParams[0])-1)+"");
			htmlContent=htmlContent.replaceAll("%%CONTROL_GROUP%%", reportMapKey );
			
			int nbMonths = 0;
			String monthlyCounts="";
			int totalCountAllMonths=0;
			
	        for(Object reportObj : reportsList) {
	        	FTECountByWorkMonthVO reportRowBean = (FTECountByWorkMonthVO)reportObj;
	        	int fullTimeCount =Integer.parseInt(reportRowBean.getFullTimeCount());
	        	int partTimeCount =Integer.parseInt(reportRowBean.getPartTimeCount());
	        	int totalCount =fullTimeCount+partTimeCount;
	        	totalCountAllMonths+=totalCount;
	        	nbMonths++;
	        	
	        	monthlyCounts+="<tr><td align=\"center\">"+reportRowBean.getWorkMonth()+"</td>";
	        	monthlyCounts+="<td align=\"center\">"+fullTimeCount+"</td>";
	        	monthlyCounts+="<td align=\"center\">"+partTimeCount+"</td>";
	        	monthlyCounts+="<td align=\"center\">"+totalCount+"</td></tr>";
	        	
	        }
			
	        float totalEmp = totalCountAllMonths/Float.valueOf(nbMonths);
	        
	        DecimalFormat decimalFormat = new DecimalFormat("##.##");
	        
	        String strTotalEmp = decimalFormat.format(totalEmp);
	        
	        int totalEmpRounded = Math.round(totalEmp);
	        
	        htmlContent=htmlContent.replaceAll("%%NB_EMP_TOTAL_ROUNDED%%", String.valueOf(totalEmpRounded));
	        htmlContent=htmlContent.replaceAll("%%NB_ANNUAL_EMP_TOTAL%%", String.valueOf(totalCountAllMonths));
	        htmlContent=htmlContent.replaceAll("%%NB_MONTHS%%", String.valueOf(nbMonths));
	        htmlContent=htmlContent.replaceAll("%%NB_EMP_TOTAL%%", strTotalEmp);
	        htmlContent=htmlContent.replaceAll("%%EMP_MONTHLY_COUNT_RECORDS%%", monthlyCounts);
	        
			// initialize document
			document = new Document(PageSize.A4);
			String fileName="";
			
			try{
	        	fileName = commonUtil.buildUploadPDFFileName(argParams);
	        	System.out.println("FileName Built with aegument params : " + fileName);
	        	logger.info("ERCoverageReportPDFBuilder :: FileName Built with aegument params : " + fileName);
	        	
			// initialize pdfwriter
			writer = PdfWriter.getInstance(document, new FileOutputStream(reportsPath+"/"+fileName));

			logger.info(" processPDFContent :: 'Document', 'PdfWriter' have been initialized ");	
			
			document.open();
	        ByteArrayInputStream bis =new ByteArrayInputStream(htmlContent.getBytes());  
	        XMLWorkerHelper.getInstance().parseXHtml(writer, document,bis);
            
        } catch(FileNotFoundException fe) {
        	logger.error(" ERCoverageReportExcelBuilder :: Error while Building the Excel Report file : ", fe);
        } catch(Exception e) {
        	logger.error(" ERCoverageReportExcelBuilder :: Error while Building the Excel Report file : ", e);
        	}finally {
	        	document.close();
	        }
		
		}
		
		// Process ZIP the generated reports - with the Directory Name generated for Reports
				List<String> fileList = new ArrayList<String>(); 
				String sourceFolderPath = pathArr[0]+"/reportsData/ERCoveragePDFReports/"+forderNameTimeStampString;
				String outputZipFileName = sourceFolderPath + ".zip";
						
				fileList = commonUtil.generateFileList(reportsDirectory, fileList, sourceFolderPath);
				folderZipUtil.zipIt(outputZipFileName, sourceFolderPath, fileList,forderNameTimeStampString);
				
				return reportsPath;
	}
	
	public Map<String, List<FTECountByWorkMonthVO>> processReportsMapByControlGroup(List<?> reportsList, List<String> controlGroupList) {
		Map<String, List<FTECountByWorkMonthVO>> reportsMapByControlGroup = new HashMap<String, List<FTECountByWorkMonthVO>>();
		for(String controlGroupName : controlGroupList) {
			List<FTECountByWorkMonthVO> reportList = new ArrayList<FTECountByWorkMonthVO>();
			for(Object objRef : reportsList) {
				FTECountByWorkMonthVO fteCountByWorkMonthVOReportObj = (FTECountByWorkMonthVO)objRef;
				/*
				if(controlGroupName.equalsIgnoreCase(fteCountByWorkMonthVOReportObj.getCONTROL_GROUP())) {
					reportList.add(nhnftReportObj);
				}
				*/
				reportList.add(fteCountByWorkMonthVOReportObj);
			}
			reportsMapByControlGroup.put(controlGroupName, reportList);
		}
		return reportsMapByControlGroup;
	}
}
