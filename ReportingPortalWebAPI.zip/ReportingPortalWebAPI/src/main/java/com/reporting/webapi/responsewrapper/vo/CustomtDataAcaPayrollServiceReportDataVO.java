package com.reporting.webapi.responsewrapper.vo;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.reporting.webapi.response.vo.DataAcaPayrollServiceReportDataVO;

@XmlRootElement(name = "customtDataAcaPayrollServiceReportData")
@XmlAccessorType(XmlAccessType.FIELD)
public class CustomtDataAcaPayrollServiceReportDataVO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private List<DataAcaPayrollServiceReportDataVO> dataAcaPayrollServiceReportData;

	public List<DataAcaPayrollServiceReportDataVO> getDataAcaPayrollServiceReportData() {
		return dataAcaPayrollServiceReportData;
	}

	public void setDataAcaPayrollServiceReportData(
			List<DataAcaPayrollServiceReportDataVO> dataAcaPayrollServiceReportData) {
		this.dataAcaPayrollServiceReportData = dataAcaPayrollServiceReportData;
	}
	
	
}
