package com.reporting.webapi.util;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.reporting.webapi.response.vo.BreakInReportDataVO;
import com.reporting.webapi.response.vo.DemoGraphicsReportDataVO;
import com.reporting.webapi.response.vo.EligibilityReportDataVO;
import com.reporting.webapi.response.vo.FTECountByWorkMonthVO;
import com.reporting.webapi.response.vo.OnGoingReportsByWeekCountVO;
import com.reporting.webapi.response.vo.ReportsByACAEligibleCountVO;
import com.reporting.webapi.response.vo.ReportsByWeeksCountVO;
import com.reporting.webapi.response.vo.ReportsForPayrollDataActivityVO;
import com.reporting.webapi.uploadpdf.builder.BreakInReportPDFBuilder;
import com.reporting.webapi.uploadpdf.builder.DemographicsReportPDFBuilder;
import com.reporting.webapi.uploadpdf.builder.ERCoverageReportPDFBuilder;
import com.reporting.webapi.uploadpdf.builder.EligibilityReportPDFBuilder;
import com.reporting.webapi.uploadpdf.builder.NewHiresFullTimeReportPDFBuilder;
import com.reporting.webapi.uploadpdf.builder.NewHiresNonFullTimeReportPDFBuilder;
import com.reporting.webapi.uploadpdf.builder.OnGoingReportPDFBuilder;
import com.reporting.webapi.uploadpdf.builder.PayrollDataActivityReportPDFBuilder;

@Component
public class ReportsPDFBuilderUtil {

	private final Logger logger = Logger.getLogger(ReportsPDFBuilderUtil.class);
	
	@Autowired
	private CommonUtil commonUtil;
	
	@Autowired
	private ERCoverageReportPDFBuilder erCoverageReportPDFBuilder;

	@Autowired
	private EligibilityReportPDFBuilder eligibilityReportPDFBuilder;

	@Autowired
	private DemographicsReportPDFBuilder demographicsReportPDFBuilder;

	@Autowired
	private BreakInReportPDFBuilder breakInReportPDFBuilder;

	@Autowired
	private NewHiresFullTimeReportPDFBuilder newHiresFullTimeReportPDFBuilder;

	@Autowired
	private NewHiresNonFullTimeReportPDFBuilder newHiresNonFullTimeReportPDFBuilder;

	@Autowired
	private OnGoingReportPDFBuilder onGoingReportPDFBuilder;

	@Autowired
	private PayrollDataActivityReportPDFBuilder payrollDataActivityReportPDFBuilder;

	public String buildPDFDocument(Map<String,List<?>> reportsDataMap, List<String> controlGroupList,String...argParams) throws Exception {

		Set<String> reportsListKeys = reportsDataMap.keySet();
		String generatedDocumentPath = null;

		if(CollectionUtils.isNotEmpty(reportsListKeys)){
			for(String reportKey : reportsListKeys) {
				switch(reportKey) {

				case "ERCoveragePDFReport" : 
					if(null != argParams[1]) {
						String controlGroupValue = argParams[1];                                             
						List<String> selectedControlGroupList = commonUtil.getSelectedControlGroupList(controlGroupValue);
						Map<String, List<FTECountByWorkMonthVO>> reportsMapByControlGroup = erCoverageReportPDFBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), selectedControlGroupList);
						generatedDocumentPath = erCoverageReportPDFBuilder.processPDFContent(reportsMapByControlGroup,argParams);
					} else {
						Map<String, List<FTECountByWorkMonthVO>> reportsMapByControlGroup = erCoverageReportPDFBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), controlGroupList);
						generatedDocumentPath = erCoverageReportPDFBuilder.processPDFContent(reportsMapByControlGroup,argParams);
					}
					break;
				case "EligibilityPDFReport":
					if(null != argParams[1]) {
						String controlGroupValue = argParams[1];                                             
						List<String> selectedControlGroupList = commonUtil.getSelectedControlGroupList(controlGroupValue);
						Map<String, List<EligibilityReportDataVO>> reportsMapByControlGroup = eligibilityReportPDFBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), selectedControlGroupList);
						generatedDocumentPath = eligibilityReportPDFBuilder.processPDFContent(reportsMapByControlGroup,argParams);
					} else {
						Map<String, List<EligibilityReportDataVO>> reportsMapByControlGroup = eligibilityReportPDFBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), controlGroupList);
						generatedDocumentPath = eligibilityReportPDFBuilder.processPDFContent(reportsMapByControlGroup,argParams);
					}
					break;
				case "DemographicsPDFReport":
					if(null != argParams[1]) {
						String controlGroupValue = argParams[1];                                             
						List<String> selectedControlGroupList = commonUtil.getSelectedControlGroupList(controlGroupValue);
						Map<String, List<DemoGraphicsReportDataVO>> reportsMapByControlGroup = demographicsReportPDFBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), selectedControlGroupList);
						generatedDocumentPath = demographicsReportPDFBuilder.processPDFContent(reportsMapByControlGroup,argParams);
					} else {
						Map<String, List<DemoGraphicsReportDataVO>> reportsMapByControlGroup = demographicsReportPDFBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), controlGroupList);
						generatedDocumentPath = demographicsReportPDFBuilder.processPDFContent(reportsMapByControlGroup,argParams);
					}
					break;
				case "BreakInPDFReport":
					if(null != argParams[1]) {
						String controlGroupValue = argParams[1];                                             
						List<String> selectedControlGroupList = commonUtil.getSelectedControlGroupList(controlGroupValue);
						Map<String, List<BreakInReportDataVO>> reportsMapByControlGroup = breakInReportPDFBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), selectedControlGroupList);
						generatedDocumentPath = breakInReportPDFBuilder.processPDFContent(reportsMapByControlGroup,argParams);
					} else {
						Map<String, List<BreakInReportDataVO>> reportsMapByControlGroup = breakInReportPDFBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), controlGroupList);
						generatedDocumentPath = breakInReportPDFBuilder.processPDFContent(reportsMapByControlGroup,argParams);
					}
					break;
				case "NewHiresFullTimePDFReport":
					if(null != argParams[2]) {
						String controlGroupValue = argParams[2];                                             
						List<String> selectedControlGroupList = commonUtil.getSelectedControlGroupList(controlGroupValue);
						Map<String, List<ReportsByACAEligibleCountVO>> reportsMapByControlGroup = newHiresFullTimeReportPDFBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), selectedControlGroupList);
						generatedDocumentPath = newHiresFullTimeReportPDFBuilder.processPDFContent(reportsMapByControlGroup,argParams);
					} else {
						Map<String, List<ReportsByACAEligibleCountVO>> reportsMapByControlGroup = newHiresFullTimeReportPDFBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), controlGroupList);
						generatedDocumentPath = newHiresFullTimeReportPDFBuilder.processPDFContent(reportsMapByControlGroup,argParams);
					}
					break;
				case "NewHiresNonFullTimePDFReport":
					if(null != argParams[2]) {
						String controlGroupValue = argParams[2];                                             
						List<String> selectedControlGroupList = commonUtil.getSelectedControlGroupList(controlGroupValue);
						Map<String, List<ReportsByWeeksCountVO>> reportsMapByControlGroup = newHiresNonFullTimeReportPDFBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), selectedControlGroupList);
						generatedDocumentPath = newHiresNonFullTimeReportPDFBuilder.processPDFContent(reportsMapByControlGroup,argParams);
					} else {
						Map<String, List<ReportsByWeeksCountVO>> reportsMapByControlGroup = newHiresNonFullTimeReportPDFBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), controlGroupList);
						generatedDocumentPath = newHiresNonFullTimeReportPDFBuilder.processPDFContent(reportsMapByControlGroup,argParams);
					}
					break;
				case "OnGoingPDFReport":
					if(null != argParams[3]) {
						String controlGroupValue = argParams[3];                                             
						List<String> selectedControlGroupList = commonUtil.getSelectedControlGroupList(controlGroupValue);
						Map<String, List<OnGoingReportsByWeekCountVO>> reportsMapByControlGroup = onGoingReportPDFBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), selectedControlGroupList);
						generatedDocumentPath = onGoingReportPDFBuilder.processPDFContent(reportsMapByControlGroup,argParams);
					} else {
						Map<String, List<OnGoingReportsByWeekCountVO>> reportsMapByControlGroup = onGoingReportPDFBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), controlGroupList);
						generatedDocumentPath = onGoingReportPDFBuilder.processPDFContent(reportsMapByControlGroup,argParams);
					}
					break;             			
				case "PayrollDataActivityPDFReport":
					if(null != argParams[1]) {
						String controlGroupValue = argParams[1];                                             
						List<String> selectedControlGroupList = commonUtil.getSelectedControlGroupList(controlGroupValue);
						Map<String, List<ReportsForPayrollDataActivityVO>> reportsMapByControlGroup = payrollDataActivityReportPDFBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), selectedControlGroupList);
						generatedDocumentPath = payrollDataActivityReportPDFBuilder.processPDFContent(reportsMapByControlGroup,argParams);
					} else {
						Map<String, List<ReportsForPayrollDataActivityVO>> reportsMapByControlGroup = payrollDataActivityReportPDFBuilder.processReportsMapByControlGroup(reportsDataMap.get(reportKey), controlGroupList);
						generatedDocumentPath = payrollDataActivityReportPDFBuilder.processPDFContent(reportsMapByControlGroup,argParams);
					}
					break;

				default :
					logger.info("ReportsPDFBuilder is invoked but the requested Report to be generated is not yet configured in the Reporting Portal");
				}
			}
		}
		return generatedDocumentPath;
	}
}
